<?php

namespace Digueloulou12\Koth\Task;

use pocketmine\block\BlockFactory;
use Digueloulou12\Koth\API\KothAPI;
use Digueloulou12\Koth\Utils\Utils;
use pocketmine\player\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class KothTask extends Task
{
    public static ?Player $player = null;
    public static int $time = 0;

    public function onRun(): void
    {
        if (self::$player !== null) {
            $player = self::$player;
            if ($player->isOnline()) {
                if (KothAPI::isInArea($player)) {
                    if (self::$time !== 45) {
                        foreach (Server::getInstance()->getOnlinePlayers() as $players){
                        		$players->sendTip(str_replace(["{actus}", "{max}", "{king}"], [self::$time , 45, $player->getName()], "§e- §fKoth §7[{actus}/{max}] §9{king} §e-"));
                        }
                        self::$time++;
                        $id2 = BlockFactory::getInstance()->get(236, 1);    
                        $id = BlockFactory::getInstance()->get(35, 1);    
                        
                		$player->getPosition()->getWorld()->setBlockAt(-141, 144, -153 ,$id);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -153 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -153 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -153 ,$id); 
                		$player->getPosition()->getWorld()->setBlockAt(-141, 144, -152 ,$id);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -152 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -152 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -152 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-141, 144, -151 ,$id);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -151 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -151 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -151 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-141, 144, -150 ,$id);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -150 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -150 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -150 ,$id); 
                        
                		$player->getPosition()->getWorld()->setBlockAt(-141, 144, -154 ,$id2);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -154 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -154 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -154 ,$id2);

                        $player->getPosition()->getWorld()->setBlockAt(-142, 144, -153 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-142, 144, -152 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-142, 144, -151 ,$id2);  
                        $player->getPosition()->getWorld()->setBlockAt(-142, 144, -150 ,$id2);                         

                        $player->getPosition()->getWorld()->setBlockAt(-137, 144, -153 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-137, 144, -152 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-137, 144, -151 ,$id2);  
                        $player->getPosition()->getWorld()->setBlockAt(-137, 144, -150 ,$id2);   
                        
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -149 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -149 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-141, 144, -149 ,$id2);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -149 ,$id2); 
                       
                        
                    } else {
                        KothAPI::finishKoth();
                        
                        $id2 = BlockFactory::getInstance()->get(236, 14);    
                        $id = BlockFactory::getInstance()->get(35, 14);    
                        
                		$player->getPosition()->getWorld()->setBlockAt(-141, 144, -153 ,$id);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -153 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -153 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -153 ,$id); 
                		$player->getPosition()->getWorld()->setBlockAt(-141, 144, -152 ,$id);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -152 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -152 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -152 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-141, 144, -151 ,$id);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -151 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -151 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -151 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-141, 144, -150 ,$id);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -150 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -150 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -150 ,$id); 
                        
                		$player->getPosition()->getWorld()->setBlockAt(-141, 144, -154 ,$id2);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -154 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -154 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -154 ,$id2);

                        $player->getPosition()->getWorld()->setBlockAt(-142, 144, -153 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-142, 144, -152 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-142, 144, -151 ,$id2);  
                        $player->getPosition()->getWorld()->setBlockAt(-142, 144, -150 ,$id2);                         

                        $player->getPosition()->getWorld()->setBlockAt(-137, 144, -153 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-137, 144, -152 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-137, 144, -151 ,$id2);  
                        $player->getPosition()->getWorld()->setBlockAt(-137, 144, -150 ,$id2);   
                        
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -149 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -149 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-141, 144, -149 ,$id2);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -149 ,$id2); 
                    }
                } else {
                    KothAPI::leaveKoth();
                    
                        $id2 = BlockFactory::getInstance()->get(236, 14);    
                        $id = BlockFactory::getInstance()->get(35, 14);    
                        
                		$player->getPosition()->getWorld()->setBlockAt(-141, 144, -153 ,$id);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -153 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -153 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -153 ,$id); 
                		$player->getPosition()->getWorld()->setBlockAt(-141, 144, -152 ,$id);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -152 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -152 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -152 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-141, 144, -151 ,$id);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -151 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -151 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -151 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-141, 144, -150 ,$id);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -150 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -150 ,$id); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -150 ,$id); 
                        
                		$player->getPosition()->getWorld()->setBlockAt(-141, 144, -154 ,$id2);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -154 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -154 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -154 ,$id2);

                        $player->getPosition()->getWorld()->setBlockAt(-142, 144, -153 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-142, 144, -152 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-142, 144, -151 ,$id2);  
                        $player->getPosition()->getWorld()->setBlockAt(-142, 144, -150 ,$id2);                         

                        $player->getPosition()->getWorld()->setBlockAt(-137, 144, -153 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-137, 144, -152 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-137, 144, -151 ,$id2);  
                        $player->getPosition()->getWorld()->setBlockAt(-137, 144, -150 ,$id2);   
                        
                        $player->getPosition()->getWorld()->setBlockAt(-139, 144, -149 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-138, 144, -149 ,$id2); 
                        $player->getPosition()->getWorld()->setBlockAt(-141, 144, -149 ,$id2);  
                        $player->getPosition()->getWorld()->setBlockAt(-140, 144, -149 ,$id2); 
                    
                }
            } else KothAPI::leaveKoth();
        } else KothAPI::searchPlayer();
    }
}