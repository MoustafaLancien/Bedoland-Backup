<?php
/**
 * ██╗░░██╗██╗██████╗░░█████╗░████████╗███████╗░█████╗░███╗░░░███╗
 * ██║░░██║██║██╔══██╗██╔══██╗╚══██╔══╝██╔════╝██╔══██╗████╗░████║
 * ███████║██║██████╔╝██║░░██║░░░██║░░░█████╗░░███████║██╔████╔██║
 * ██╔══██║██║██╔══██╗██║░░██║░░░██║░░░██╔══╝░░██╔══██║██║╚██╔╝██║
 * ██║░░██║██║██║░░██║╚█████╔╝░░░██║░░░███████╗██║░░██║██║░╚═╝░██║
 * ╚═╝░░╚═╝╚═╝╚═╝░░╚═╝░╚════╝░░░░╚═╝░░░╚══════╝╚═╝░░╚═╝╚═╝░░░░░╚═╝
 * Nexus-HiroTeam By WillyDuGang
 *
 * GitHub: https://github.com/HiroshimaTeam
 */

namespace HiroTeam\Nexus\entity;

use HiroTeam\Nexus\NexusMain;
use HiroTeam\Nexus\sound\BlastSound;
use HiroTeam\Nexus\utils\ItemUtils;
use pocketmine\data\bedrock\EntityLegacyIds;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Living;
use pocketmine\entity\Location;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\player\Player;
use pocketmine\world\particle\HugeExplodeSeedParticle;
use pocketmine\world\sound\ExplodeSound;

class NexusEntity extends Living
{

    public const NETWORK_ID = EntityLegacyIds::ENDER_CRYSTAL;

    public $height = 2;
    public $width = 0.98;

    public function __construct(Location $location, ?CompoundTag $nbt = null)
    {
        parent::__construct($location, $nbt);
        $this->updateNameTag();
    }

    private function updateNameTag()
    {
        $this->setNameTag($this->getHealth() . ' §c❤');
        $this->setNameTagAlwaysVisible(true);
    }

    public static function getNetworkTypeId(): string
    {
        return EntityIds::ENDER_CRYSTAL;
    }

    public function spawnToAll(): void
    {
        parent::spawnToAll();
        $this->updateNameTag();
    }

    public function getMaxHealth(): int
    {
        return NexusMain::getSelf()->getConfig()->get('hp');
    }

    public function getName(): string
    {
        return 'NexusEntity';
    }

    public function attack(EntityDamageEvent $source): void
    {
        if (!($source instanceof EntityDamageByEntityEvent)) return;
        $damager = $source->getDamager();
        if (!($damager instanceof Player)) return;
        $updatedHp = $this->getHealth() - 1;
        $position = $this->getPosition();
        $world = $position->getWorld();
        $vector = new Vector3($position->x, $position->y, $position->z);
        if ($updatedHp > 0) {
            $this->setHealth($updatedHp);
            $this->updateNameTag();
            $world->addSound($vector, new BlastSound());
            return;
        }
        $world->addParticle($vector, new HugeExplodeSeedParticle());
        $world->addSound($vector, new ExplodeSound());
        $this->dropItem();
        $this->close();
    }

    private function dropItem()
    {
        $config = NexusMain::getSelf()->getConfig();
        $items = ItemUtils::itemDataDecode($config->get('items'));
        $radius = $config->get('radius');
        $level = $this->getWorld();
        $position = $this->getPosition();
        $centerVector = new Vector3($position->x, $position->y, $position->z);
        foreach ($items as $item) {
            $level->dropItem(
                $centerVector,
                $item,
                (new Vector3(
                    mt_rand(-$radius, $radius),
                    $config->get('height'),
                    mt_rand(-$radius, $radius)
                ))->normalize()
            );
        }
    }

    protected function getInitialSizeInfo(): EntitySizeInfo
    {
        return new EntitySizeInfo(1.8, 0.6, 1.62);
    }
}