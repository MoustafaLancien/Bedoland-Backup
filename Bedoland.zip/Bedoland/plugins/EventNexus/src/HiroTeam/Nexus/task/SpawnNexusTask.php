<?php
/**
 * ██╗░░██╗██╗██████╗░░█████╗░████████╗███████╗░█████╗░███╗░░░███╗
 * ██║░░██║██║██╔══██╗██╔══██╗╚══██╔══╝██╔════╝██╔══██╗████╗░████║
 * ███████║██║██████╔╝██║░░██║░░░██║░░░█████╗░░███████║██╔████╔██║
 * ██╔══██║██║██╔══██╗██║░░██║░░░██║░░░██╔══╝░░██╔══██║██║╚██╔╝██║
 * ██║░░██║██║██║░░██║╚█████╔╝░░░██║░░░███████╗██║░░██║██║░╚═╝░██║
 * ╚═╝░░╚═╝╚═╝╚═╝░░╚═╝░╚════╝░░░░╚═╝░░░╚══════╝╚═╝░░╚═╝╚═╝░░░░░╚═╝
 * Nexus-HiroTeam By WillyDuGang
 *
 * GitHub: https://github.com/HiroshimaTeam
 */

namespace HiroTeam\Nexus\task;

use HiroTeam\Nexus\NexusMain;
use pocketmine\scheduler\Task;

class SpawnNexusTask extends Task
{
    /**
     * @var NexusMain
     */
    private NexusMain $main;

    public function __construct(NexusMain $main)
    {
        $this->main = $main;
    }

    public function onRun(): void
    {
        $date = new \DateTime("now");
        $day = date('l',$date->getTimestamp());
        foreach ($this->main->getConfig()->get("timeToSpawn") as $time) {
            $time = explode(":", $time);
            if ($time[0] === $date->format("H") && $time[1] === $date->format("i") && $time[2] === $day) {
                $this->main->spawnNexus();
            }
        }
    }
}