<?php
/**
 * ██╗░░██╗██╗██████╗░░█████╗░████████╗███████╗░█████╗░███╗░░░███╗
 * ██║░░██║██║██╔══██╗██╔══██╗╚══██╔══╝██╔════╝██╔══██╗████╗░████║
 * ███████║██║██████╔╝██║░░██║░░░██║░░░█████╗░░███████║██╔████╔██║
 * ██╔══██║██║██╔══██╗██║░░██║░░░██║░░░██╔══╝░░██╔══██║██║╚██╔╝██║
 * ██║░░██║██║██║░░██║╚█████╔╝░░░██║░░░███████╗██║░░██║██║░╚═╝░██║
 * ╚═╝░░╚═╝╚═╝╚═╝░░╚═╝░╚════╝░░░░╚═╝░░░╚══════╝╚═╝░░╚═╝╚═╝░░░░░╚═╝
 * Duel-HiroTeam By WillyDuGang
 *
 * GitHub: https://github.com/HiroshimaTeam
 */

namespace HiroTeam\Nexus\utils;

use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;

class ItemUtils
{
    /**
     * @param $items array|string
     *
     * @return Item[]
     */
    public static function itemDataDecode($items): array
    {
        if (!is_array($items)) {
            $items = [$items];
        }
        return array_map(function (string $itemData) {
            $idMetaAmountEnchantLevel = explode(':', $itemData);
            $id = array_shift($idMetaAmountEnchantLevel);
            $meta = array_shift($idMetaAmountEnchantLevel);
            $amount = array_shift($idMetaAmountEnchantLevel);
            $item = ItemFactory::getInstance()->get($id, $meta, $amount);
            while (count($idMetaAmountEnchantLevel) >= 2) {
                $item->addEnchantment(
                    new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(array_shift($idMetaAmountEnchantLevel)), array_shift($idMetaAmountEnchantLevel))
                );
            }
            return $item;
        }, $items);
    }
}