<?php
/**
 * ██╗░░██╗██╗██████╗░░█████╗░████████╗███████╗░█████╗░███╗░░░███╗
 * ██║░░██║██║██╔══██╗██╔══██╗╚══██╔══╝██╔════╝██╔══██╗████╗░████║
 * ███████║██║██████╔╝██║░░██║░░░██║░░░█████╗░░███████║██╔████╔██║
 * ██╔══██║██║██╔══██╗██║░░██║░░░██║░░░██╔══╝░░██╔══██║██║╚██╔╝██║
 * ██║░░██║██║██║░░██║╚█████╔╝░░░██║░░░███████╗██║░░██║██║░╚═╝░██║
 * ╚═╝░░╚═╝╚═╝╚═╝░░╚═╝░╚════╝░░░░╚═╝░░░╚══════╝╚═╝░░╚═╝╚═╝░░░░░╚═╝
 * Nexus-HiroTeam By WillyDuGang
 *
 * GitHub: https://github.com/HiroshimaTeam
 */

namespace HiroTeam\Nexus;

use HiroTeam\Nexus\entity\NexusEntity;
use HiroTeam\Nexus\task\SpawnNexusTask;
use HiroTeam\Nexus\utils\MessageReplacer;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\data\bedrock\EntityLegacyIds;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\Location;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\plugin\PluginBase;
use pocketmine\world\World;
use pocketmine\Server;
use pocketmine\world\Position;

class NexusMain extends PluginBase
{

    private static NexusMain $self;

    /**
     * @return NexusMain
     */
    public static function getSelf(): NexusMain
    {
        return self::$self;
    }

    public function onEnable(): void
    {
        date_default_timezone_set("Europe/Paris");
        self::$self = $this;
        $this->saveDefaultConfig();
        EntityFactory::getInstance()->register(NexusEntity::class, function (World $world, CompoundTag $nbt): NexusEntity {
            return new NexusEntity(EntityDataHelper::parseLocation($nbt, $world), $nbt);
        }, ['Nexus'], EntityLegacyIds::ENDER_CRYSTAL);
        $this->getScheduler()->scheduleDelayedRepeatingTask(new SpawnNexusTask($this), 1200, 1200);
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
    {
        
        if ($command->getName() === 'nexus') {
           if(count($args) < 1) {
            $sender->sendMessage("§cindiquez start ou stop");
            return true;
        	}
            switch($args[0]){
            		case "start":
							$this->spawnNexus();
                   		break;
            			case "stop":
                      $this->getServer()->broadcastMessage("§l§f[§dNEXUS§f] §rL'event nexus est terminé §d!");
                      foreach (Server::getInstance()->getWorldManager()->getWorlds() as $worlds) {
                		foreach ($worlds->getEntities() as $entities) {
                    		if ($entities instanceof NexusEntity) { 
                        		$entities->flagForDespawn();
                    			}
                			}
           				 }
        }
        return true;
      }
    }      

    public function spawnNexus()
    {
        $allPositions = $this->getConfig()->get('positions');
        $pos = explode(':', $allPositions[mt_rand(0, count($allPositions) - 1)]);
        $x = (int)$pos[0];
        $y = (int)$pos[1];
        $z = (int)$pos[2];
        $level = $this->getServer()->getWorldManager()->getWorldByName("bedoland");
        $nexus = new NexusEntity(new Location($x, $y, $z, $level, 0, 0));
        $nexus->spawnToAll();
        $position = [
            'x' => $x,
            'y' => $y,
            'z' => $z,
            'world' => $pos[3],
        ];
        $replacer = new MessageReplacer();
        $this->getServer()->broadcastMessage($replacer->replace(
            $this->getConfig()->get('SPAWN_BROADCAST_MESSAGE'), $position
        ));
    }
}