# MarketPlugin
MarketPlugin allows you to add a market for players, it allows them to sell items to each other without scams. Plugin made for PocketMine 4.0.0 servers.
