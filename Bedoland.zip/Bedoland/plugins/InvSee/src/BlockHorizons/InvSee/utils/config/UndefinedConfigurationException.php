<?php

declare(strict_types=1);

namespace BlockHorizons\InvSee\utils\config;

final class UndefinedConfigurationException extends ConfigurationException{
}