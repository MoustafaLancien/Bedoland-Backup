<?php

declare(strict_types=1);

namespace BlockHorizons\InvSee\listeners;

use pocketmine\inventory\InventoryListener;

interface InvSeeListener extends InventoryListener{
}