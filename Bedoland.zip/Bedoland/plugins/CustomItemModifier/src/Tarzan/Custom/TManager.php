<?php


namespace Tarzan\Custom;


use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\EffectManager;
use pocketmine\entity\effect\StringToEffectParser;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\Entity;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\inventory\CreativeInventory;
use pocketmine\item\Armor;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIdentifier;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use Tarzan\Custom\Armor\TArmor;
use Tarzan\Custom\Item\SimpleItem;
use Tarzan\Custom\Item\TAxe;
use Tarzan\Custom\Item\THoe;
use Tarzan\Custom\Item\TPickaxe;
use Tarzan\Custom\Item\TShovel;
use Tarzan\Custom\Item\TSword;
use Tarzan\Main;

class TManager
{
    /**
     * @var Config
     */
    private Config $config;
    /**
     * @var Main
     */
    private Main $plugin;

    /**
     * TManager constructor.
     * @param Main $pl
     */
    public function __construct(Main $pl)
    {
        $this->plugin = $pl;
        $this->config = new Config($pl->getDataFolder() . "config.yml", Config::YAML);

    }

    /**
     *
     */
    public function init()
    {
        $this->ArmorRegister();
        $this->AxeRegister();
        $this->SwordRegister();
        $this->ShovelRegister();
        $this->PickaxeRegister();
        $this->HoeRegister();
        $this->SimpleItemRegister();
       //$this->FoodItemRegister();
        CreativeInventory::reset();
    }

    public function ArmorRegister()
    {
        if ($this->existClass("armor")) {
            foreach ($this->getClassALL("armor") as $name) {
                $item = $this->getSubClassALL("armor", $name);
                $armor = new TArmor(new ItemIdentifier((int)$item["id"], (int)$item["meta"]), $name, (int)$item["dura"], (int)$item["def"]);
                ItemFactory::getInstance()->register($armor, true);
            }
        }
    }

    public function SwordRegister()
    {
        if ($this->existClass("sword")) {
            foreach ($this->getClassALL("sword") as $name) {
                $item = $this->getSubClassALL("sword", $name);
                ItemFactory::getInstance()->register(new TSword((int)$item["id"], (int)$item["meta"], $name, (int)$item["dura"], (int)$item["attackdamage"]), true);
            }
        }
    }

    public function ShovelRegister()
    {
        if ($this->existClass("shovel")) {
            foreach ($this->getClassALL("shovel") as $name) {
                $item = $this->getSubClassALL("shovel", $name);
                ItemFactory::getInstance()->register(new TShovel((int)$item["id"], (int)$item["meta"], $name, (int)$item["dura"]), true);
            }
        }
    }

    public function PickaxeRegister()
    {
        if ($this->existClass("pickaxe")) {
            foreach ($this->getClassALL("pickaxe") as $name) {
                $item = $this->getSubClassALL("pickaxe", $name);
                ItemFactory::getInstance()->register(new TPickaxe((int)$item["id"], (int)$item["meta"], $name, (int)$item["dura"]), true);
            }
        }
    }

    public function AxeRegister()
    {
        if ($this->existClass("axe")) {
            foreach ($this->getClassALL("axe") as $name) {
                $item = $this->getSubClassALL("axe", $name);
                ItemFactory::getInstance()->register(new TAxe((int)$item["id"], (int)$item["meta"], $name, (int)$item["dura"]), true);
            }
        }
    }

    public function HoeRegister()
    {
        if ($this->existClass("hoe")) {
            foreach ($this->getClassALL("hoe") as $name) {
                $item = $this->getSubClassALL("hoe", $name);
                ItemFactory::getInstance()->register(new THoe((int)$item["id"], (int)$item["meta"], $name, (int)$item["dura"]), true);
            }
        }
    }

    public function SimpleItemRegister()
    {
        if ($this->existClass("simpleitem")) {
            foreach ($this->getClassALL("simpleitem") as $name) {
                $item = $this->getSubClassALL("simpleItem", $name);
                ItemFactory::getInstance()->register(new SimpleItem((int)$item["id"], (int)$item["meta"], $name,(int)isset($item["count"]) ? $item["count"] : 64), true);
            }
        }
    }

/*
    public function FoodItemRegister()
    {
        if ($this->existClass("fooditem")) {
            foreach ($this->getClassALL("fooditem") as $name) {
                $item = $this->getSubClassALL("fooditem", $name);
                if ($item["enable_effects"]) {
                    var_dump($item["effects"]);
                    ItemFactory::registerItem(new FoodEffectItem((int)$item["id"], (int)$item["meta"], $name, (int)$item["saturation"], (int)$item["food"], (array)$item["effects"]), true);
                } else {
                    ItemFactory::registerItem(new fooditem((int)$item["id"], (int)$item["meta"], $name, (int)$item["saturation"], (int)$item["food"]), true);
                }
                $this->plugin->getLogger()->info("Resiter §6$name");
            }
        }
    }
*/
    /**
     * @param InventoryTransactionEvent $event
     */
    public function onChangeArmor(InventoryTransactionEvent $event)
    {
        $player = $event->getTransaction()->getSource();
        foreach ($event->getTransaction()->getActions() as $action){
            $this->removeEffect($action->getSourceItem(), $player);
            $this->addEffect($action->getTargetItem(), $player);
        }
    }

    /**
     * @param Item $item
     * @param Entity $entity
     */
    public function removeEffect(Item $item, Entity $entity)
    {
        if ($entity instanceof Player) {
            if ($this->getSubClassExist("armoreffect", $item->getId())) {
                foreach ($this->getSubClassALL("armoreffect", $item->getId()) as $effect => $array) {
                    $e = new EffectManager($entity);
                    $name = new StringToEffectParser();
                    $e->add(new EffectInstance($name->parse($effect)));
                }
            }
        }
    }

    /**
     * @param Item $item
     * @param Entity $entity
     */
    public function addEffect(Item $item, Entity $entity)
    {
        if ($entity instanceof Player) {
            if ($this->getSubClassExist("armoreffect", $item->getId())) {
                foreach ($this->getSubClassALL("armoreffect", $item->getId()) as $effect => $array) {
                    $e = new EffectManager($entity);
                    $e->add(new EffectInstance(VanillaEffects::getAll()["$effect"], $array["duration"], $array["amplifier"]));
                }
            }
        }
    }

    /**
     * @param string $class
     * @return array
     */
    public function getClassALL(string $class): array
    {
        return array_keys($this->config->get($class));
    }

    public function existClass(string $class): bool
    {
        return $this->config->exists($class);
    }

    /**
     * @param string $class
     * @param string $subclass
     * @return mixed
     */
    public function getSubClassALL(string $class, string $subclass): mixed
    {
        return $this->config->get($class, [])[$subclass];
    }

    /**
     * @param string $class
     * @param string $subclass
     * @return bool
     */
    public function getSubClassExist(string $class, string $subclass): bool
    {
        return isset($this->config->get($class)[$subclass]);
    }

}
