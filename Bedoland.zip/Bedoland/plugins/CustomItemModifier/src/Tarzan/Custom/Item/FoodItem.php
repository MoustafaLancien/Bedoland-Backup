<?php


namespace Tarzan\Custom\Item;


use pocketmine\item\Food;
use pocketmine\item\ItemIdentifier;

class FoodItem extends Food
{
    private $saturation;
    private $food;

    public function __construct(int $id, int $meta, string $name, int $saturation, int $food)
    {
        $this->saturation = $saturation;
        $this->food = $food;
        parent::__construct(new ItemIdentifier($id, $meta), $name);
    }
    public function getFoodRestore(): int
    {
       return $this->saturation;
    }

    public function getSaturationRestore(): float
    {
        return $this->food;
    }
}