<?php


namespace Tarzan\Custom\Item;


use pocketmine\block\Block;
use pocketmine\entity\Entity;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\Shovel;
use pocketmine\item\ToolTier;
use pocketmine\utils\TextFormat;

class TShovel extends Shovel
{
    private $maxdura;

    public function __construct(int $id, int $meta, string $name, int $maxdura)
    {
        $this->maxdura = $maxdura;
        parent::__construct(new ItemIdentifier($id, $meta), $name, ToolTier::DIAMOND());
    }

    /**
     * @return int
     */
    public function getMaxDurability(): int
    {
        return $this->maxdura;
    }

    public function onDestroyBlock(Block $block) : bool{
        $this->applyDamage(1);
        return false;
    }

    public function onAttackEntity(Entity $victim) : bool{
        return $this->applyDamage(2);
    }


    public function applyDamage(int $amount): bool
    {
        parent::applyDamage($amount);
        $durability = $this->getMaxDurability() - $this->getDamage();
        $txt = TextFormat::GRAY .$durability . "/" . TextFormat::DARK_GRAY .$this->getMaxDurability();
        $this->setLore([$txt]);
        return true;
    }

}