<?php


namespace Tarzan\Custom\Armor;


use pocketmine\inventory\ArmorInventory;
use pocketmine\item\Armor;
use pocketmine\item\ArmorTypeInfo;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemIds;
use pocketmine\utils\TextFormat;

class TArmor extends Armor
{
    private ItemIdentifier $identifier;

    public function __construct(ItemIdentifier $identifier, string $name, protected int $dura, protected int $def)
    {
        $this->identifier = $identifier;
        parent::__construct($this->identifier, $name, new ArmorTypeInfo($def, $dura, match ($identifier->getId()){
            ItemIds::LEATHER_CHESTPLATE, ItemIds::CHAINMAIL_CHESTPLATE, ItemIds::IRON_CHESTPLATE, ItemIds::GOLD_CHESTPLATE, ItemIds::DIAMOND_CHESTPLATE, 749 => ArmorInventory::SLOT_CHEST,
            ItemIds::LEATHER_LEGGINGS, ItemIds::CHAINMAIL_LEGGINGS, ItemIds::IRON_LEGGINGS, ItemIds::GOLD_LEGGINGS, ItemIds::DIAMOND_LEGGINGS, 750 => ArmorInventory::SLOT_LEGS,
            ItemIds::LEATHER_BOOTS, ItemIds::CHAINMAIL_BOOTS, ItemIds::IRON_BOOTS, ItemIds::GOLD_BOOTS, ItemIds::DIAMOND_BOOTS, 751 => ArmorInventory::SLOT_FEET,
            default => ArmorInventory::SLOT_HEAD,
        }));
    }

    public function getMaxDurability(): int
    {
        return $this->dura;
    }

    public function getDefensePoints(): int
    {
        return $this->def;
    }

    public function getDamage(): int
    {
        return $this->damage;
    }

    public function applyDamage(int $amount): bool
    {
        parent::applyDamage($amount);
        $durability = $this->getMaxDurability() - $this->getDamage();
        $txt = TextFormat::RED .$durability . "/" . TextFormat::RED .$this->getMaxDurability();
        $this->setLore([$txt]);
        return true;
    }
}