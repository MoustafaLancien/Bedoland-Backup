<?php


namespace Tarzan\Event;

use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\Listener;
use Tarzan\Custom\TManager;
use Tarzan\Main;

class PlayerArmor implements Listener
{
    public function onPlayerArmorChange(InventoryTransactionEvent $event){
        $events = new TManager(Main::getInstance());
        $events->onChangeArmor($event);
    }
}