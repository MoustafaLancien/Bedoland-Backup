<?php


namespace Tarzan;


use pocketmine\plugin\PluginBase;
use Tarzan\Custom\TManager;
use Tarzan\Event\PlayerArmor;

class Main extends PluginBase
{
    public static $main;

    protected function onLoad(): void
    {
        $t = new TManager($this);
        $t->init();
        parent::onLoad();
    }

    protected function onEnable(): void
    {
        self::$main = $this;
        $this->getServer()->getPluginManager()->registerEvents(new PlayerArmor(), $this);
        @mkdir($this->getDataFolder());
        $this->saveDefaultConfig();
        parent::onEnable();
    }

    public static function getInstance(): Main
    {
        return self::$main;
    }

}