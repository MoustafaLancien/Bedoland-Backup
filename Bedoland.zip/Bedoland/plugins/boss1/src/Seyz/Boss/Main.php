<?php

namespace Seyz\Boss;

use onebone\economyapi\EconomyAPI;
use Seyz\Boss\spawnboss;
use pocketmine\Server;
use pocketmine\item\ItemFactory;
use pocketmine\{entity\Entity,
    entity\EntityDataHelper,
    entity\EntityFactory,
    event\entity\EntityDeathEvent,
    event\Listener,
    nbt\tag\CompoundTag,
    plugin\PluginBase,
    utils\TextFormat as C,
    world\World};

class Main extends PluginBase implements Listener
{
    
    static $instance;

    public static function getInstance(): Main
    {
        return self::$instance;
    }

    public function onLoad(): void
    {
        self::$instance = $this;
    }

    public function onEnable(): void
    {
        $this->getLogger()->info(C::YELLOW . "Loading " . $this->getName() . "...");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        if (!$this->initResources()) {
            $this->getServer()->getPluginManager()->disablePlugin($this->getServer()->getPluginManager()->getPlugin($this->getName()));
            return;
        }

        $this->saveConfig();
        $this->getServer()->getCommandMap()->register("", new spawnboss());
        $this->getScheduler()->scheduleRepeatingTask(new BossSpawnTask(), 20);
        $this->getLogger()->info(C::YELLOW . "Registering BossEntity...");
        EntityFactory::getInstance()->register(BossEntity::class, function(World $world, CompoundTag $nbt) : BossEntity{
            return new BossEntity(EntityDataHelper::parseLocation($nbt, $world), BossEntity::parseSkinNBT($nbt), $nbt);
        }, ['Bosss']);
        $this->getLogger()->info(C::GREEN . "BossEntity successfully registered.");
        $this->getLogger()->info(C::GREEN . "Successfully enabled " . $this->getName() . ".");
    }

    public function initResources(): bool
    {
        if (!is_dir($this->getDataFolder())) {
            $this->getLogger()->info(C::RED . "Cannot get data folder, creating one...");
            @mkdir($this->getDataFolder());
            $this->getLogger()->info(C::GREEN . "Data folder successfully created.");
        }

        @$this->saveResource("skin.png");
        if (!file_exists($this->getDataFolder() . "skin.png")) {
            $this->getLogger()->error("Cannot get base skin (skin.png)");
            return false;
        }

        @$this->saveResource("geometry.json");
        if (!file_exists($this->getDataFolder() . "geometry.json")) {
            $this->getLogger()->error("Cannot get base skin (geometry.json)");
            return false;
        }

        return true;
    }

    public function onEntityDeath(EntityDeathEvent $ev)
    {
        $ent = $ev->getEntity();
        $cause = $ent->getLastDamageCause();
        if ($ent instanceof BossEntity) {
            	$damager = $cause->getDamager();
                Server::getInstance()->broadcastMessage("§l§f[§c!!!§f] §r§6" . $damager->getName() . "§f a vaincu le boss§f !");
                $damager->sendMessage("§l§f[§c!!!§f] §r§aVous avez gagné 150  pour avoir vaincu le boss !");
                economyAPI::getInstance()->addMoney($damager, 150);
                $num = rand(1,3);
                Server::getInstance()->broadcastMessage($num);
                if($num == 1){
          			#$player->getInventory()->addItem(ItemFactory::getInstance()->get(263, 1, 1));
                    $damager->getInventory()->addItem(ItemFactory::getInstance()->get(263, 1, 1));
          			$damager->sendTip("bravo");
                        }
        		else if($num == 2){
            		$damager->getInventory()->addItem(ItemFactory::getInstance()->get(378, 0, 1));
           			$damager->sendTip("bravo");
                        }
        		else if($num == 3){ 
                    $damager->getInventory()->addItem(ItemFactory::getInstance()->get(369, 0, 1));
            		$damager->sendTip("bravo");		
          }
        }
    }
}