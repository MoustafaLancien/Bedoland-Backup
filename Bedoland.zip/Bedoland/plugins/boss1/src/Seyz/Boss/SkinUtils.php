<?php

namespace Seyz\Boss;

use pocketmine\nbt\tag\NamedTag;
use pocketmine\nbt\tag\ByteArrayTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\utils\BinaryStream;


class SkinUtils{

	static function getSkinBytes(string $skin){

        $path = Main::getInstance()->getDataFolder() . $skin;
        $img = @imagecreatefrompng($path);
        $bytes = "";

        $L = (int) @getimagesize($path)[0];
        $l = (int) @getimagesize($path)[1];

        Main::getInstance()->getLogger()->info("§llongueur : " . $l);
        Main::getInstance()->getLogger()->info("§llargeur : " . $L);


        for ($y = 0; $y < $l; $y++) {

            for ($x = 0; $x < $L; $x++) {

                $rgba = @imagecolorat($img, $x, $y);
                $a = ((~((int)($rgba >> 24))) << 1) & 0xff;
                $r = ($rgba >> 16) & 0xff;
                $g = ($rgba >> 8) & 0xff;
                $b = $rgba & 0xff;
                $bytes .= chr($r) . chr($g) . chr($b) . chr($a);

            }

        }

        @imagedestroy($img);

        return $bytes;
	}

    public static function getSkinTag(){

        $skin = str_repeat("\x00", 8192);

        $nbt = new CompoundTag();
        $nbt->setTag("Name",new StringTag("Standard_Custom"));
        $nbt->getByteArray("Data", $skin);
        return $nbt;
    }

}