<?php

namespace Seyz\Boss;

use pocketmine\{entity\Location, world\format\Chunk, world\World};
use pocketmine\entity\Skin;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\scheduler\Task;

class BossSpawnTask extends Task
{

    private $seconds = [];

    public function onRun(): void
    {
        $config = Main::getInstance()->getConfig();
        $server = Main::getInstance()->getServer();
        $worldManager = $server->getWorldManager();
        foreach ($config->get('boss') as $bossIndex => $bossData) {
            if(!isset($this->seconds[$bossIndex])){
                $this->seconds[$bossIndex] = 1;
            }
            $timeToSpawn = $bossData['respawn-time'] * 60;
            if (!($this->seconds[$bossIndex] % $timeToSpawn)) {
                foreach ($bossData['pos'] as $positionIndex => $xyzWorld) {
                    $xyzWorld = explode(':', $xyzWorld);
                    $worldManager->loadWorld($xyzWorld[3]);
                    $world = $worldManager->getWorldByName($xyzWorld[3]);
                    if (!$world) continue;
                    $vector = new Vector3((float)$xyzWorld[0], (float)$xyzWorld[1], (float)$xyzWorld[2]);
                    if (is_null($this->getChunkAtPosition($vector, $world)) || !$this->getChunkAtPosition($vector, $world)->isPopulated()) continue;
                    $targetBossId = $bossIndex . $positionIndex;
                    foreach ($world->getEntities() as $entity) {
                        if ($entity instanceof BossEntity) {
                            $id = $entity->getBossId();
                            if ($id === $targetBossId) {
                                break 2;
                            }
                        }
                    }
                    $this->spawnBoss($bossData, new Location($vector->getX(), $vector->getY(), $vector->getZ(), $world, 0, 0), $targetBossId);
                }
                $this->seconds[$bossIndex] = 1;
            } else {
                $this->seconds[$bossIndex]++;
            }
        }
    }

    public function getChunkAtPosition(Vector3 $pos, World $world): ?Chunk
    {
        return $world->getChunk($pos->getFloorX() >> 4, $pos->getFloorZ() >> 4);
    }

    private function spawnBoss(array $bossData, Location $location, string $bossId)
    {
        $nbt = new CompoundTag();
        $nbt->setTag("Name", new StringTag("Standard_Custom"));
        $skin = str_repeat("\x00", 8192);
        $nbt->getByteArray("Data", $skin);
        $nbt->setInt("health", $bossData["health"]);
        $nbt->setFloat("speed", $bossData["speed"]);
        $nbt->setInt("attack", $bossData["attack"]);
        $nbt->setFloat("scale", $bossData["scale"]);
        $nbt->setIntArray("drops1", BossEntity::getArrayDropsFromString($bossData["drops1"]));
        $nbt->setIntArray("drops2", BossEntity::getArrayDropsFromString($bossData["drops2"]));
        $nbt->setIntArray("drops3", BossEntity::getArrayDropsFromString($bossData["drops3"]));
        $nbt->setString("name", $bossData["name"]);
        $skin = new Skin("boss", SkinUtils::getSkinBytes($bossData["skin"]), "", "geometry.serpent", file_get_contents(Main::getInstance()->getDataFolder() . $bossData["geometry"]));
        $boss = new BossEntity($location, $skin, $nbt, $bossId);
        $boss->setSkin($skin);
        $boss->spawnToAll();
    }

}