<?php

namespace Seyz\Boss;

use pocketmine\{item\ItemFactory,
    player\Player,
    Server,
    event\entity\EntityDamageByEntityEvent,
    event\entity\EntityDamageEvent};
use pocketmine\entity\{Location, Skin, Human};
use pocketmine\block\{
	Flowable
};
use pocketmine\nbt\tag\CompoundTag;

class BossEntity extends Human
{

	const FIND = 15;
	const LOSE = 15;

    private $target = "";
	private $speed;
	private $attack;
 //   protected float $scale;
	private $name;
	private $drops = [];
	private $attackTick = 20;
	private $findTargetTick = 100;
    /**
     * @var CompoundTag|null
     */
    private ?CompoundTag $namedtag;
    private float $yaw;
    private string $bossId;

    public function __construct(Location $location, Skin $skin, ?CompoundTag $nbt = null, ?string $bossId = null){
        $this->skin = $skin;
        parent::__construct($location,$skin,$nbt);
        if(!$bossId){
            $this->flagForDespawn();
            return;
        }
        $this->setNameTagVisible();
        $this->namedtag = $nbt;

        $health = $nbt->getInt("health");
		$this->setMaxHealth($health);
		$this->setHealth($health);
		$this->speed = $nbt->getFloat("speed");
		$this->attack = $nbt->getInt("attack");
		$this->scale = $nbt->getFloat("scale");
		$this->name = $nbt->getString("name") ?? "Boss";
        $this->drops1 = $nbt->getIntArray("drops1");
        $this->drops2 = $nbt->getIntArray("drops2");
        $this->drops3 = $nbt->getIntArray("drops3");

		$this->setScale($this->getBScale());
        $this->bossId = $bossId;
    }

	public function entityBaseTick(int $tickDiff = 1) : bool
	{
		if($this->closed)
		{
			$this->flagForDespawn();
			return false;
		}

		if($this->isAlive())
		{
			$this->setNameTag($this->name . "\n" . $this->getHealth() . "/" . $this->getMaxHealth());
			$this->setScale($this->getBScale());

			if(is_null($this->getTargetAsPlayer()) || $this->getTargetAsPlayer()->getPosition()->distance($this->getPosition()) >= self::LOSE)
				{
					$this->target = "";
			}

			if(--$this->findTargetTick === 0)
			{
				if(is_null($this->getTargetAsPlayer()))
				{
					$this->target = $this->findTarget();
				}
				if(!is_null($this->getTargetAsPlayer()) && !$this->isTargetAlive())
				{
					$this->target = "";
				}
				$this->findTargetTick = 40;
			}

			if($this->onGround && !is_null($this->getTargetAsPlayer())) {
					$target = $this->getTargetAsPlayer();
					$x = $target->getPosition()->getX() - $this->getPosition()->getX();
					$y = $target->getPosition()->getY() - $this->getPosition()->getY();
					$z = $target->getPosition()->getZ() - $this->getPosition()->getZ();

					if($x ** 2 + $z ** 2 < 0.7)
					{
						$this->motion->x = 0;
						$this->motion->z = 0;
					}
					else
					{
						$diff = abs($x) + abs($z);
						$this->motion->x = $this->getSpeed() * 0.15 * ($x / $diff);
						$this->motion->z = $this->getSpeed() * 0.15 * ($z / $diff);
					}

					$this->yaw = rad2deg(atan2(-$x, $z));
					$this->pitch = rad2deg(atan(-$y));
					if($this->needToJump())
					{
						$this->customJump();
					}
					$this->move($this->motion->x, $this->motion->y, $this->motion->z);
			}

			if(--$this->attackTick <= 0)
			{
				if(!is_null($this->getTargetAsPlayer()))
				{
					$target = $this->getTargetAsPlayer();
					if($target->getPosition()->distance($this->getPosition()->asVector3()) <= mt_rand(3,4.5))
					{
						$this->attackTarget();
						$this->attackTick = mt_rand(15,20);
					}
				}
			}
		}

		return parent::entityBaseTick($tickDiff);
	}

	public function isTargetAlive() : bool
	{
		$target = $this->getTargetAsPlayer();
		if(is_null($target))
		{
			return false;
		}

		return $target->isAlive();
	}

	public function getCollidedBlock($y = 0)
	{
		$dir = $this->getDirectionVector();
		return $this->getWorld()->getBlock($this->getPosition()->add($dir->getX() * $this->getScale(), $y + 1, $dir->getZ() * $this->getScale())->round());
	}

	public function customJump()
	{
		$motionY = $this->gravity * 16;
		$this->move($this->motion->x * 1.40, $motionY, $this->motion->z * 1.40);
	}

	public function needToJump() : bool
	{
		return $this->isCollidedHorizontally || ($this->getCollidedBlock()->getId() !== 0 && $this->getCollidedBlock(1)->getId() !== 0 && !$this->getCollidedBlock() instanceof Flowable);
	}

	public function attackTarget()
	{
		$target = $this->getTargetAsPlayer();
		$ev = new EntityDamageByEntityEvent($this, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->getAttackDamage());
		//$this->broadcastEntityEvent(4);
		$target->attack($ev);
	}

	public function findTarget() : string
    {
        foreach ($this->getWorld()->getPlayers() as $player) {
            if ($player->getPosition()->distance($this->getPosition()->asVector3()) <= self::FIND && !$player->isCreative() && !$player->isSpectator()) {
                return $player->getName();
            }
        }
        return "";
    }

    static function getArrayDropsFromString(string $str = null)
    {
    	if(is_null($str) || empty($str)) return [];

    	$return = [];
    	foreach (explode(",", $str) as $rowItem)
    	{
    		if(strpos($rowItem, ":") !== false)
    		{
    			$jveuxtetaperptn = explode(":", $rowItem);

    			if(count($jveuxtetaperptn) <= 2)
    			{
    				$id = $jveuxtetaperptn[0];
    				$meta = $jveuxtetaperptn[1];
    				$amount = 1;
    			}
    			else
    			{
    				$id = $jveuxtetaperptn[0];
    				$meta = $jveuxtetaperptn[1];
    				$amount = $jveuxtetaperptn[2];
    			}
    		}
    		else 
    		{
    			$id = $rowItem;
    			$meta = 0;
    			$amount = 1;
    		}
    		$return[] = ItemFactory::getInstance()->get($id, $meta, $amount);

    	}
    	return $return;
    }

	public function getTargetAsPlayer()
    {
		return Server::getInstance()->getPlayerExact($this->target);
	}

	public function getAttackDamage()
	{
		return $this->namedtag->getInt("attack");
	}

	public function setAttackDamage(int $a)
	{
		$this->namedtag->setInt("attack", $a);
	}

	public function getSpeed()
	{
		return $this->speed;
	}

	public function setSpeed(float $s)
	{
		$this->namedtag->setFloat("speed",$s);
	}

	public function getBScale()
	{
		return $this->scale;
	}

	public function getBDrops1() : array
	{
		return $this->drops;
	}
    
    	public function getBDrops2() : array
	{
		return $this->drops2;
	}
    
    	public function getBDrops3() : array
	{
		return $this->drops3;
	}

    /**
     * @return string
     */
    public function getBossId(): string
    {
        return $this->bossId;
    }
}