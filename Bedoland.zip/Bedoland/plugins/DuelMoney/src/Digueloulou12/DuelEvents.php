<?php

namespace Digueloulou12;


use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\Listener;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\inventory\InventoryOpenEvent;
use Corentin503\API\CooldownAPI;

class DuelEvents implements Listener
{
    public function onQuit(PlayerQuitEvent $event)
    {
        $player = $event->getPlayer();
        if (!empty(DuelAPI::$players[$player->getName()])) {
            DuelAPI::stopGame();
        }
    }

    public function onDamage(EntityDamageByEntityEvent $event)
    {
        $player = $event->getEntity();
        if (!($player instanceof Player)) return;

        if (!empty(DuelAPI::$god[$player->getName()])) {
            $event->cancel();
        }
    }

    public function onDamage2(EntityDamageEvent $event)
    {
        $victim = $event->getEntity();
        if (!($victim instanceof Player)) return;

        $cause = $victim->getLastDamageCause();

        $damager = null;
        if ($cause instanceof EntityDamageByEntityEvent) $damager = $cause->getDamager(); else if ($event->getCause() === EntityDamageEvent::CAUSE_PROJECTILE) $damager = $event->getEntity()->getOwningEntity();

        if (!($damager instanceof Player)) return;

        if ($event->getFinalDamage() >= $victim->getHealth()) {
            if (!empty(DuelAPI::$players[$victim->getName()])) {
                $event->cancel();
                DuelAPI::finishGame($damager);
            }
        }
    }
    
    
   public function onInventory(PlayerDropItemEvent $event)
    { 
       $player = $event->getPlayer();
       if (!isset(DuelAPI::$Induel[$player->getName()]) || DuelAPI::$Induel[$player->getName()] - time() <= 0) {
            $test = "1";
           	return;
       } else {
               $player->sendMessage("§cNe jettez pas vos items !");
               $event->cancel();
           }
       }

    
        public function openInv(InventoryOpenEvent $event)
    {
            
       $player = $event->getPlayer();
       if (!isset(DuelAPI::$Induel[$player->getName()]) || DuelAPI::$Induel[$player->getName()] - time() <= 0) {
         $test = "1";
         return;
       } else {
          $event->cancel();
            }
        }       


    public function commandProcess(PlayerCommandPreprocessEvent $event)
    {
        $message = $event->getMessage();
        $msg = explode(' ', trim($message));
        $m = substr("$message", 0, 1);
        $whitespace_check = substr($message, 1, 1);
        $slash_check = substr($msg[0], -1, 1);
        $quote_mark_check = substr($message, 1, 1) . substr($message, -1, 1);
        if ($m == '/') {
            if ($whitespace_check === ' ' or $whitespace_check === '\\' or $slash_check === '\\' or $quote_mark_check === '""') {
                $event->cancel();
            }
        }
        
        
        $player = $event->getPlayer();
        if (!isset(DuelAPI::$Induel[$player->getName()]) || DuelAPI::$Induel[$player->getName()] - time() <= 0) {
            $test = "1";
            return;
        } else {
            if ($m == '/') {
                if (!Server::getInstance()->isOp($player->getName())) {
                 $event->cancel();
                   $player->sendMessage("§cVous etes en duel !!");
                } else $player->sendMessage("§cVous etes en duel mais op dcp vous etes autorisé à faire des commandes mdr ahahaha jsp pk je fais ça dans le code !");
            }
        }
    }
     
}