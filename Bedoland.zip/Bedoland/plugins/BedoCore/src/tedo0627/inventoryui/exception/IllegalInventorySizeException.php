<?php

namespace tedo0627\inventoryui\exception;

use RuntimeException;

class IllegalInventorySizeException extends RuntimeException {}