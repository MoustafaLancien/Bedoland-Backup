<?php

namespace Corentin503\Entitys;

use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Location;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;

class Boss extends Entity
{
    private $speed = 1.6;

    private $damage = 7;

    private ?Entity $target = null;

    public static function getNetworkTypeId(): string
    {
        return "minecraft:boss";
    }

    public function __construct(Location $location, ?CompoundTag $nbt = null)
    {
        parent::__construct($location);
        $this->setMaxHealth(300);
        $this->setHealth(300);
        $this->setScale(2.3);
    }

    protected function getInitialSizeInfo(): EntitySizeInfo
    {
        return new EntitySizeInfo(3, 5);
    }

    public function entityBaseTick(int $tickDiff = 15) : bool
    {
        var_dump($this->target);
        if (!is_null($this->target)) {
            var_dump($this->isTargetAlive());
            if ($this->isTargetAlive()) {
                $x = $this->target->getPosition()->getX() - $this->getPosition()->getX();
                $y = $this->target->getPosition()->getY() - $this->getPosition()->getY();
                $z = $this->target->getPosition()->getZ() - $this->getPosition()->getZ();

                $diff = abs($x) + abs($z);
                $d = $x ** 2 + $z ** 2;
                var_dump($d);
                var_dump($diff);
                if ($d < 3) {
                    $this->attackTarget();
                } elseif ($diff > 0) {

                    $this->motion->x = $this->speed * 0.15 * ($x / $diff);
                    $this->motion->z = $this->speed * 0.15 * ($z / $diff);
                    $this->setRotation(-atan2($x / $diff, $z / $diff) * 180 / M_PI, $y == 0 ? 0 : rad2deg(-atan2($y, sqrt($x ** 2 + $z ** 2))));
                }
            }
        } else {
            if (!is_null($this->findTarget())) {
                $this->target = $this->findTarget();
            }
        }
        return parent::entityBaseTick($tickDiff);
    }

    public function isTargetAlive() : bool
    {
        $target = $this->target;
        if(is_null($target)) {
            return false;
        }
        return $target->isAlive();
    }

    public function attackTarget()
    {
        $target = $this->target;
        $ev = new EntityDamageByEntityEvent($this, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->damage);
        $target->attack($ev);
    }

    public function findTarget() : ?Player
    {
        foreach ($this->getViewers() as $entity) {
            if ($entity instanceof Player) {
                if ($entity->getPosition()->distance($this->getPosition()->asVector3()) >= 15) {
                    $this->target = null;
                } else return $entity;
            }
        }
        return null;
    }
}