<?php

namespace Corentin503\Entitys\Box;

use Corentin503\Forms\BoxsForms;
use Corentin503\Forms\TagsForms;
use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Location;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;

class BoxTag extends Entity
{
    protected $alwaysShowNameTag = true;

    public function __construct(Location $location, ?CompoundTag $nbt = null)
    {
        parent::__construct($location, $nbt);
        $this->setNameTagAlwaysVisible(true);
        $this->setNameTag("§f===============\n§l§7>>§r Box §8Tags §l§7<<\n§r§f===============");        
    }

    public function attack(EntityDamageEvent $source): void
    {
        if ($this->noDamageTicks > 0) return;
        if (!($source instanceof EntityDamageByEntityEvent)) return;
        $player = $source->getDamager();
        if (!($player instanceof Player)) return;

        TagsForms::BoxUi($player);
    }

    public function onInteract(Player $player, Vector3 $clickPos): bool
    {
        TagsForms::BoxUi($player);
        return true;
    }

    protected function getInitialSizeInfo(): EntitySizeInfo
    {
        return new EntitySizeInfo(1, 1.5);
    }

    public static function getNetworkTypeId(): string
    {
        return "minecraft:boxtag";
    }
}