<?php

namespace Corentin503\Entitys;

use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
class Chicha extends Entity
{
    public static function getNetworkTypeId(): string
    {
        return "minecraft:chicha";
    }

    protected function getInitialSizeInfo(): EntitySizeInfo
    {
        return new EntitySizeInfo(1, 1);
    }
}