<?php

namespace Corentin503\Items;

use pocketmine\block\Block;
use pocketmine\block\BlockLegacyIds;
use pocketmine\entity\projectile\Throwable;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\ProjectileHitEvent;
use pocketmine\math\RayTraceResult;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\world\particle\EndermanTeleportParticle;
use pocketmine\world\sound\EndermanTeleportSound;

class ProjectileEnderPearl extends Throwable
{

    public static function getNetworkTypeId(): string
    {
        return EntityIds::ENDER_PEARL;
    }


    protected function calculateInterceptWithBlock(Block $block, Vector3 $start, Vector3 $end): ?RayTraceResult
    {
        if ($block->getId() == BlockLegacyIds::STONE_PRESSURE_PLATE) {
            $this->flagForDespawn();
            $this->teleportOwner($block->getPosition());
        }
        return parent::calculateInterceptWithBlock($block, $start, $end);
    }

    private function teleportOwner(Vector3 $vector3)
    {
        $owner = $this->getOwningEntity();
        if($owner !== null){
            $this->getWorld()->addParticle($origin = $owner->getPosition(), new EndermanTeleportParticle());
            $this->getWorld()->addSound($origin, new EndermanTeleportSound());
            $owner->teleport($vector3);
            $this->getWorld()->addSound($vector3, new EndermanTeleportSound());

            $owner->attack(new EntityDamageEvent($owner, EntityDamageEvent::CAUSE_FALL, 5));
        }
    }
    protected function onHit(ProjectileHitEvent $event) : void{
        $this->teleportOwner($event->getRayTraceResult()->getHitVector());
    }

}