<?php

namespace Corentin503\items;

use pocketmine\item\Armor;
use pocketmine\item\ItemIds;
use pocketmine\item\ArmorTypeInfo;
use pocketmine\item\ItemIdentifier;
use pocketmine\inventory\ArmorInventory;
use pocketmine\item\ItemFactory;

class TurtleHelmet extends Armor
{

    public function __construct()
    {
        parent::__construct(new ItemIdentifier(ItemIds::TURTLE_HELMET, 0), "Turtle Helmet", new ArmorTypeInfo(1, 276, ArmorInventory::SLOT_HEAD));
    }
    public static function init(): void
    {
        ItemFactory::getInstance()->register(new TurtleHelmet(new ItemIdentifier(ItemIds::TURTLE_HELMET, 0), "Trident"));
    }
}