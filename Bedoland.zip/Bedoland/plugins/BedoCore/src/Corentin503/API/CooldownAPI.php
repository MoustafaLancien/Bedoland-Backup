<?php

namespace Corentin503\API;

class CooldownAPI
{
    public static array $cooldown_bow = [];

    public static array $cooldown_chat = [];

    public static array $cooldown_bump = [];

    public static array $cooldown_dash = [];

    public static array $cooldown_citrouille = [];
    
    public static array $cooldown_shuffle = [];

    public static array $cooldown_regeneration = [];

    public static array $cooldown_jump = [];

    public static array $cooldown_bedo = [];

    public static array $cooldown_force = [];

    public static array $cooldown_speed = [];
 
    public static array $cooldown_lean = [];    
    
    public static array $cooldown_joint = [];  

    public static array $cooldown_perle = [];  

    public static array $cooldown_chicha = [];
    
    public static array $cooldown_loupe = [];

    public static array $cooldown_sticktp = [];
    
    public static array $cooldown_repair = [];
    
    public static array $cooldown_repairall = [];

    public static array $combat = [];

    public static int $time_clearlagg = 180;
}