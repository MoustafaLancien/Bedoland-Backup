<?php

namespace Corentin503\API;

use pocketmine\block\Block;
use pocketmine\world\World;

class ElevatorAPI
{
    public static function isElevatorBlock(int $x, int $y, int $z, World $level): ?Block
    {
        $elevator = $level->getBlockAt($x, $y, $z);
        $id = 152;
        $damage = 0;

        if ($elevator->getId() !== $id ) return null;

        return $elevator;
    }
}