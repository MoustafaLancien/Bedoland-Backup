<?php

namespace Corentin503\API;

use Corentin503\Main;
use pocketmine\utils\Config;

class MoneyAPI
{
    public static Config $data;

    public static function getData(): Config
    {
        return self::$data;
    }

    public static function getMoney(string $player): int
    {
        return self::getData()->get($player);
    }

    public static function setMoney(string $player, int $money)
    {
        self::getData()->set($player, $money);
        self::getData()->save();
    }

    public static function addMoney(string $player, int $money)
    {
        self::getData()->set($player, self::getMoney($player) + $money);
        self::getData()->save();
    }

    public static function removeMoney(string $player, int $money)
    {
        self::getData()->set($player, self::getMoney($player) - $money);
        self::getData()->save();
    }
}