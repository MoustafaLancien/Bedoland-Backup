<?php

namespace Corentin503\API;

use Corentin503\Main;
use pocketmine\utils\Config;

class AtmAPI
{
    public static Config $atm_data;

    public static function setDataFile(): void
    {
        self::$atm_data = new Config(Main::getInstance()->getDataFolder() . "AtmData.json", Config::JSON);
    }

    public static function getDataFile(): Config
    {
        return self::$atm_data;
    }
}