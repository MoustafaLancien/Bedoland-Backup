<?php

namespace Corentin503\Forms;

use Corentin503\API\MoneyAPI;
use onebone\economyapi\EconomyAPI;
use TheStepKla\FormAPI\CustomForm;
use TheStepKla\FormAPI\SimpleForm;
use TheStepKla\FormAPI\Form;
use TheStepKla\FormAPI\ModalForm;
use TheStepKla\FormAPI\FormAPI;
use pocketmine\block\Anvil;
use pocketmine\item\Item;
use pocketmine\item\Tool;
use pocketmine\item\Armor;
use pocketmine\item\ItemFactory;
use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;

class AnvilForms
{
    public static function openForm(Player $player)
    {


        $form = new SimpleForm(function (Player $player, $data) {
            if ($data === null) {
                return;
            }
            switch ($data) {
                case 0:
                    self::openRepair($player);
                    break;
                case 1:
                    self::openRename($player);
                    break;


            }
        }
        );
        $form->setTitle("§4§l« §r§aBedo§7Repair §4§l»");
        $form->setContent("§eRéparer/Renommer\n");
        $form->addButton("§aRéparer", 0, "textures/ui/hammer_r");
        $form->addButton("§eRenommer", 0, "textures/ui/mashup_PaintBrush");
        $form->addButton("§c§lRETOUR", 0, "textures/ui/cancel");
        $form->sendToPlayer($player);
    }

    public static function openRepair(Player $player)
    {
        $form = new SimpleForm(function (Player $player, $data) {
            if ($data === null) {
                return;
            }
            switch ($data) {
                case 0:

                    if (EconomyAPI::getInstance()->myMoney($player) >= 15) { // a convertir vers BedrockEconomy le mymoney
                        $item = $player->getInventory()->getItemInHand();
                        if ($item instanceof Armor or $item instanceof Tool) {
                            $id = $item->getId();
                            $meta = $item->getDamage();
                            $player->getInventory()->removeItem(ItemFactory::getInstance()->get($id, $meta, 1));
                            $newitem = ItemFactory::getInstance()->get($id, 0, 1);
                            if ($item->hasCustomName()) {
                                $newitem->setCustomName($item->getCustomName());
                            }
                            if ($item->hasEnchantments()) {
                                foreach ($item->getEnchantments() as $enchants) {
                                    $newitem->addEnchantment($enchants);
                                }
                            }
                            $player->getInventory()->setItemInHand($newitem);
                            $player->sendMessage("§aVotre objet a bien été réparé !");
                            EconomyAPI::getInstance()->reduceMoney($player, 15); // a convertir vers BedrockEconomy
                            return true;
                        } else {
                            $player->sendMessage("§cTennez un item dans votre main !");
                            return false;
                        }
                        return true;
                    } else {
                        $player->sendMessage("§cVous n'avez pas assez d'argent !");
                    }
                    break;
                case 1:
                    self::openForm($player);
                    break;
            }


        }
        );
        $mymoney1 = EconomyAPI::getInstance()->myMoney($player);  // a convertir vers BedrockEconomy
        $form->setTitle("§4§l« §r§aBedo§7Repair §4§l»");
        $form->setContent("§ePrix: §a15/item" . "\n" . "§eVotre argent: §a" . $mymoney1 . " ");
        $form->addButton("§a§lREPARER", 0, "textures/ui/hammer_r");
        $form->addButton("§c§lRETOUR", 0, "textures/blocks/barrier");
        $form->sendToPlayer($player);
    }

    public static function openRename(Player $sender)
    {
        $form = new CustomForm(function (Player $sender, ?array $data) {
            if (!isset($data)) return;
            $item = $sender->getInventory()->getItemInHand();
            if ($item->getId() == 0) {
                $sender->sendMessage("§cTenez un objet dans votre main !");
                return;
            }
            if (EconomyAPI::getInstance()->myMoney($sender) >= 50) { // a convertir vers BedrockEconomy pour get money du player
                EconomyAPI::getInstance()->reduceMoney($sender, 50); // a convertir vers BedrockEconomy
                $item->setCustomName($data[1]);
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage("§aVotre objet a bien été renommé !");
            } else {
                $sender->sendMessage("§cVous n'avez pas assez d'argent !");
            }


        });
        $mymoney = EconomyAPI::getInstance()->myMoney($sender); // a convertir vers BedrockEconomy pour get money du player

        $form->setTitle("§eRenommer l'item (50$) : " . $sender->getInventory()->getItemInHand()->getName());
        $form->addLabel("§eVotre argent: §a" . $mymoney . "\n" . "§eRenommer l'item : ");
        $form->addInput(TextFormat::GRAY . "Nouveau nom:", "...");
        $form->sendToPlayer($sender);
    }
}