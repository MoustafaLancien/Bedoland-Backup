<?php

namespace Corentin503\Forms;

use Corentin503\Main;
use pocketmine\block\Door;
use pocketmine\block\FenceGate;
use pocketmine\block\Trapdoor;
use pocketmine\block\VanillaBlocks;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;
use TheStepKla\FormAPI\CustomForm;

class CrochetageForms
{
    public static function test1(Player $player, FenceGate|Trapdoor|Door $block)
    {
        $random = random_int(1, 100);
        $form = new CustomForm(function (Player $player, $data) use ($block, $random) {
            if (is_null($data)) return;

            if ((int)$data[1] === $random) {
                self::test2($player, $block);
            } else $player->sendMessage("§cVous avez louper le test !");
        });

        $form->setTitle("Crochetage");
        $form->addLabel("Stage: 1/3 \nNuméro: §a{$random}§f");
        $form->addSlider("Résoudre:", 1, 100);
        $form->sendToPlayer($player);
    }

    public static function test2(Player $player, FenceGate|Trapdoor|Door $block)
    {
        $random = random_int(1, 100);
        $form = new CustomForm(function (Player $player, $data) use ($block, $random) {
            if (is_null($data)) return;

            if ((int)$data[1] === $random) {
                self::test3($player, $block);
            } else $player->sendMessage("§cVous avez louper le test !");
        });

        $form->setTitle("Crochetage");
        $form->addLabel("Stage: 2/3 \nNuméro: §a{$random}§f");
        $form->addSlider("Résoudre:", 1, 100);
        $form->sendToPlayer($player);
    }

    public static function test3(Player $player, FenceGate|Trapdoor|Door $block)
    {
        $random = random_int(1, 100);
        $form = new CustomForm(function (Player $player, $data) use ($block, $random) {
            if (is_null($data)) return;

            if ((int)$data[1] === $random) {
                
                
                $block->getPosition()->getWorld()->setBlock($block->getPosition()->asVector3(), VanillaBlocks::AIR());
                $player->sendMessage("§aVous avez réussi !");
                
                $index = $player->getInventory()->getHeldItemIndex();
            	$item = $player->getInventory()->getItem($index);
                
                $player->getInventory()->setItem($index, $item->setDamage($player->getInventory()->getItemInHand()->getDamage() + 1));
                
                if ($block instanceof Door){
                    $posX = $block->getPosition()->getX();
                	$posY = $block->getPosition()->getY();
                	$posZ = $block->getPosition()->getZ();
                    $blockAtpos = $block->getPosition()->getWorld()->getBlockAt($posX, $posY - 1, $posZ);  
                    $idd = $blockAtpos->getId();    
                    if ($idd === 64 or $idd === 71){
                    $blockAtpos->getPosition()->getWorld()->setBlock($blockAtpos->getPosition()->asVector3(), VanillaBlocks::AIR());    
                    }
                }  
                
            } else $player->sendMessage("§cVous avez louper le test !");
        });
// 
        $form->setTitle("Crochetage");
        $form->addLabel("Stage: 3/3 \nNuméro: §a{$random}§f");
        $form->addSlider("Résoudre:", 1, 100);
        $form->sendToPlayer($player);
    }
}