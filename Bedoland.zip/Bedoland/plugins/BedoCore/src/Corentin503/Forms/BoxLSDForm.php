<?php

namespace Corentin503\Forms;

use Corentin503\API\MoneyAPI;
use TheStepKla\FormAPI\CustomForm;
use TheStepKla\FormAPI\SimpleForm;
use TheStepKla\FormAPI\Form;
use TheStepKla\FormAPI\ModalForm;
use TheStepKla\FormAPI\FormAPI;
use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use pocketmine\item\ItemFactory;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\ItemIds;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\lang\Language;


class BoxLSDForm
{				

    public static function openForm(Player $player)
    {


        $form = new SimpleForm(function (Player $player, $data) {
            if ($data === null) {
                return;
            }
            switch ($data) {
                case 0:
                    self::openBox($player);
                    break;
                case 1:
                    $a = "b";
                    break;


            }
        }
        );
        $form->setTitle("§4§l« §r§aBoxLSD §4§l»");
        $form->setContent("§eVoici les loots: \n");
        $form->addButton("§c§lOUVRIR", 0, "textures/ui/interact"); 
        
        $form->addButton("kétamine x6 26%", 0, "textures/items/dye_powder_red");
        $form->addButton("Block kéta 24%", 0, "textures/blocks/purpur_block");
        $form->addButton("poudre LSD x6 22%", 0, "textures/items/dye_powder_light_blue");
        $form->addButton("LSD x3 20%", 0, "textures/items/dye_powder_blue");
        $form->addButton("Block de LSD  18%", 0, "textures/blocks/lapis_block");
        
        $form->addButton("Casque kéta P4 19%", 0, "textures/items/iron_helmet");
        $form->addButton("Plastron kéta P4 15%", 0, "textures/items/iron_chestplate");
        $form->addButton("Jambieres kéta P4  16%", 0, "textures/items/iron_leggings");
        $form->addButton("Bottes kéta P4  18%", 0, "textures/items/iron_boots");
        $form->addButton("Epée Kéta T4 14%", 0, "textures/items/iron_sword");
        $form->addButton("Pioche kéta 9%", 0, "textures/items/iron_pickaxe");
        
        $form->addButton("Casque LSD 3%", 0, "textures/items/gold_helmet");
        $form->addButton("Plastron LSD 3%", 0, "textures/items/gold_chestplate");
        $form->addButton("Jambieres LSD 3%", 0, "textures/items/gold_leggings");
        $form->addButton("Bottes LSD 3%", 0, "textures/items/gold_boots");
        $form->addButton("Epée LSD 3%", 0, "textures/items/gold_sword");
        $form->addButton("Pioche LSD 3%", 0, "textures/items/gold_pickaxe");
        
        
        
        
        $form->sendToPlayer($player);
    }
    
     public static function openBox(Player $player)
    {
         if ($player->getInventory()->contains(ItemFactory::getInstance()->get(399, 0, 1)->setLore(["Box lsd"]))) {
                       
                       if(!$player->getInventory()->canAddItem(ItemFactory::getInstance()->get(0, 0))){
                           $player->sendActionBarMessage("§cVous n’avez pas assez de place dans votre inventaire !");
                           return;
                       }
             
             		   $player->getInventory()->removeItem(ItemFactory::getInstance()->get(399, 0, 1)->setLore(["Box lsd"]));
                       $player->getServer()->broadcastMessage("Le joueur §1{$player->getName()} §fvient d'ouvrir une §9Box lsd §f!");
                       
                       $rdm = mt_rand(1, 219);
             
                       
                       if($rdm <= 22){ #poudre lsd x6
                           $newItem = ItemFactory::getInstance()->get(351, 12, 6); 
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 42){
                           $newItem = ItemFactory::getInstance()->get(351, 4, 3); #lsd x3
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 60){
                            #block lsd
                           $newItem = ItemFactory::getInstance()->get(VanillaBlocks::LAPIS_LAZULI()->getId(), 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 84){
                            #block de keta
                           $newItem = ItemFactory::getInstance()->get(VanillaBlocks::PURPUR()->getId(), 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 110){  #keta x6
                            $newItem = ItemFactory::getInstance()->get(351, 1, 6);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 129){ #casque keta p4
                           $newItem = ItemFactory::getInstance()->get(306, 0, 1);
                           $newItem->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4));
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                        elseif($rdm <= 144){ #chestplate keta p4
                           $newItem = ItemFactory::getInstance()->get(307, 0, 1);
                           $newItem->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4));
                           $player->getInventory()->addItem($newItem);
                       }
                       
                       elseif($rdm <= 160){  #jambieres keta p4
                           $newItem = ItemFactory::getInstance()->get(308, 0, 1);
                           $newItem->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4));
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       elseif($rdm <= 178){  #bottes keta p4
                           $newItem = ItemFactory::getInstance()->get(309, 0, 1);
                           $newItem->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4));
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
             			elseif($rdm <= 192){  #epee keta t4
                           $newItem = ItemFactory::getInstance()->get(267, 0, 1);
                            $newItem->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 4));
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
             			elseif($rdm <= 201){  #pioche keta
                           $newItem = ItemFactory::getInstance()->get(257, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
             			elseif($rdm <= 204){  #lsd helmet
                           $newItem = ItemFactory::getInstance()->get(314, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
             			elseif($rdm <= 207){  #lsd chestplate
                           $newItem = ItemFactory::getInstance()->get(315, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
             			elseif($rdm <= 210){  #lsd jambieres
                           $newItem = ItemFactory::getInstance()->get(316, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
             			elseif($rdm <= 213){  #lsd boots
                           $newItem = ItemFactory::getInstance()->get(317, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
             			elseif($rdm <= 216){  #lsd sword
                           $newItem = ItemFactory::getInstance()->get(283, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
             			else {  #lsd pickaxe
                           $newItem = ItemFactory::getInstance()->get(287, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }   
                   } else $player->sendMessage("§cVous n'avez pas de clé lsd !");
               }
			}
         