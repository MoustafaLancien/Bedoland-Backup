<?php

namespace Corentin503\Forms;

use pocketmine\block\VanillaBlocks;
use TheStepKla\FormAPI\CustomForm;
use TheStepKla\FormAPI\SimpleForm;
use TheStepKla\FormAPI\Form;
use TheStepKla\FormAPI\ModalForm;
use TheStepKla\FormAPI\FormAPI;
use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\lang\Language;


class BoxVoteForm
{

    public static function openForm(Player $player)
    {


        $form = new SimpleForm(function (Player $player, $data) {
            if ($data === null) {
                return;
            }
            switch ($data) {
                case 0:
                    self::openBox($player);
                    break;
                case 1:
                    $a = "b";
                    break;


            }
        }
        );
        $form->setTitle("§4§l« §r§aBoxVote §4§l»");
        $form->setContent("§eVoici les loots: \n");
        $form->addButton("§c§lOUVRIR", 0, "textures/ui/interact");

        $form->addButton("Ascenseur 11%", 0, "textures/blocks/redstone_block");
        $form->addButton("Redbull 10%", 0, "textures/items/feather");

        $form->addButton("Casque en d P3 9%", 0, "textures/items/diamond_helmet");
        $form->addButton("Bottes en d P3 9%", 0, "textures/items/diamond_boots");

        $form->addButton("Jambières en d P3 8%", 0, "textures/items/diamond_leggings");
        $form->addButton("hanglider", 0, "textures/items/slimeball");

        $form->addButton("Plastron en d P3 7%", 0, "textures/items/diamond_chestplate");
        $form->addButton("Perle x3 7%", 0, "textures/items/ender_pearl");

        $form->addButton("Epée diams T3 6%", 0, "textures/items/diamond_sword");

        $form->addButton("Bâton de saut 5%", 0, "textures/items/brick");
        $form->addButton("Bâton citrouille 5%", 0, "textures/items/charcoal");
        $form->addButton("Bâton de regen 5%", 0, "textures/items/netherbrick");
        $form->addButton("Plume x3 5%", 0, "textures/items/blaze_powder");
        $form->addButton("Casque en Ecstasy 5%", 0, "textures/items/chainmail_helmet");
        $form->addButton("Bottes en Ecstasy 5%", 0, "textures/items/chainmail_boots");

        $form->addButton("Baton de speed 4%", 0, "textures/items/sugar");
        $form->addButton("Boule de tp 4%", 0, "textures/items/egg");
        $form->addButton("Bâton tp 4%", 0, "textures/items/flint");
        $form->addButton("Bâton d'aveuglement 4%", 0, "textures/items/magma_cream");
        $form->addButton("Epée en Ecstasy 4%", 0, "textures/items/stone_sword");
        $form->addButton("Jambières en Ecstasy 4%", 0, "textures/items/chainmail_leggings");

        $form->addButton("Radar 3%", 0, "textures/items/compass");
        $form->addButton("Casque mineur 3%", 0, "textures/items/turtle_helmet");
        $form->addButton("Plastron en Ecstasy 3%", 0, "textures/items/chainmail_chestplate");

        $form->addButton("Bâton de force 2%", 0, "textures/items/blaze_rod");

        $form->addButton("Bâton bedo 1%", 0, "textures/items/ghast_tear");
        $form->addButton("Clé tags 1%", 0, "textures/items/rabbit_foot");








        $form->sendToPlayer($player);
    }

    public static function openBox(Player $player)
    {
        if ($player->getInventory()->contains(ItemFactory::getInstance()->get(399, 0, 1)->setLore(["Box vote"]))) {

            if(!$player->getInventory()->canAddItem(ItemFactory::getInstance()->get(0, 0))){
                $player->sendActionBarMessage("§cVous n’avez pas assez de place dans votre inventaire !");
                return;
            }
            
            $player->getInventory()->removeItem(ItemFactory::getInstance()->get(399, 0, 1)->setLore(["Box vote"]));
            $player->getServer()->broadcastMessage("Le joueur §1{$player->getName()} §fvient d'ouvrir une §9Box Vote §f!");

            $rdm = mt_rand(1, 140);

            if($rdm <= 9){ #casque d p3
                $newItem = ItemFactory::getInstance()->get(310, 0, 1);
                $newItem->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3));
                $player->getInventory()->addItem($newItem);
                return;
            }

            elseif($rdm <= 16){ #plastron d P3
                $newItem = ItemFactory::getInstance()->get(311, 0, 1);
                $newItem->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3));
                $player->getInventory()->addItem($newItem);
                return;
            }

            elseif($rdm <= 24){ #jambieres d P3
                $newItem = ItemFactory::getInstance()->get(312, 0, 1);
                $newItem->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3));
                $player->getInventory()->addItem($newItem);
                return;
            }

            elseif($rdm <= 33){ #bottes d p3
                $newItem = ItemFactory::getInstance()->get(313, 0, 1); #bottes bedo
                $player->getInventory()->addItem($newItem);
                return;
            }

            elseif($rdm <= 34){ #tag
                $player->getServer()->getCommandMap()->dispatch(new ConsoleCommandSender(Server::getInstance(), new Language("eng")), 'key '. $player->getName(). ' tag 1');
                return;
            }

            elseif($rdm <= 41){ #perle
                $newItem = ItemFactory::getInstance()->get(368, 0, 3);
                $player->getInventory()->addItem($newItem);
                return;
            }

            elseif($rdm <= 43){ #baton force
                $newItem = ItemFactory::getInstance()->get(369, 1, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }

            elseif($rdm <= 47){  #aveuglement
                $newItem = ItemFactory::getInstance()->get(378, 0, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }

            elseif($rdm <= 52){ #plume de saut
                $newItem = ItemFactory::getInstance()->get(377, 0, 3);
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 56){ #boule de tp
                $newItem = ItemFactory::getInstance()->get(344, 0, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 62){ #baton d'aveuglement
                $newItem = ItemFactory::getInstance()->get(336, 0, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 67){ #baton regen
                $newItem = ItemFactory::getInstance()->get(405, 0, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 72){ #baton citrouile
                $newItem = ItemFactory::getInstance()->get(263, 1, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 76){ #baton vitesse
                $newItem = ItemFactory::getInstance()->get(353, 0, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 87){ #ascenseur
                $newItem = ItemFactory::getInstance()->get(VanillaBlocks::REDSTONE()->getId(), 0, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 97){ #redbull
                $newItem = ItemFactory::getInstance()->get(288, 0, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 99){ #baton de tp
                $newItem = ItemFactory::getInstance()->get(318, 0, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 102){ #radar
                $newItem = ItemFactory::getInstance()->get(345, 0, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 103){ #baton bedo
                $newItem = ItemFactory::getInstance()->get(345, 0, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 109){ #epee diamand t3
                $newItem = ItemFactory::getInstance()->get(ItemIds::DIAMOND_SWORD, 0, 1);
                $newItem->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 3));
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 114){ #caque ecsta 5
                $newItem = ItemFactory::getInstance()->get(302, 1, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 117){ #plastron ecsta 3
                $newItem = ItemFactory::getInstance()->get(303, 1, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 121){ #jambieres ecsta 4
                $newItem = ItemFactory::getInstance()->get(304, 1, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 125){ #boots ecsta 5
                $newItem = ItemFactory::getInstance()->get(305, 1, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 129){ #epee ecsta
                $newItem = ItemFactory::getInstance()->get(272, 1, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }
            elseif($rdm <= 137){ #hanglider 8
                $newItem = ItemFactory::getInstance()->get(341, 1, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }
            else{ #casque mineur 3
                $newItem = ItemFactory::getInstance()->get(469, 0, 1);
                $player->getInventory()->addItem($newItem);
                return;
            }

        } else $player->sendMessage("§cVous n'avez pas de clé vote !");
    }
}
