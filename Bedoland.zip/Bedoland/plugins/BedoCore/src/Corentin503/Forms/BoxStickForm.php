<?php

namespace Corentin503\Forms;

use Corentin503\API\MoneyAPI;
use TheStepKla\FormAPI\CustomForm;
use TheStepKla\FormAPI\SimpleForm;
use TheStepKla\FormAPI\Form;
use TheStepKla\FormAPI\ModalForm;
use TheStepKla\FormAPI\FormAPI;
use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\lang\Language;


class BoxStickForm
{				

    public static function openForm(Player $player)
    {


        $form = new SimpleForm(function (Player $player, $data) {
            if ($data === null) {
                return;
            }
            switch ($data) {
                case 0:
                    self::openBox($player);
                    break;
                case 1:
                    $a = "b";
                    break;


            }
        }
        );
        $form->setTitle("§4§l« §r§aBoxStick §4§l»");
        $form->setContent("§eVoici les loots: \n");
        $form->addButton("§c§lOUVRIR", 0, "textures/ui/interact");
        $form->addButton("Redbull x8 25%", 0, "textures/items/feather");
        $form->addButton("Plume x5 17%", 0, "textures/items/blaze_powder");
        
        $form->addButton("Bâton de saut 15%", 0, "textures/items/brick");
        $form->addButton("Bâton de regen 15%", 0, "textures/items/netherbrick");
        $form->addButton("Baton de speed 15%", 0, "textures/items/sugar");
        
        $form->addButton("Bâton d'aveuglement 12%", 0, "textures/items/magma_cream");
         $form->addButton("Bâton citrouille 11%", 0, "textures/items/charcoal");
        $form->addButton("Baton de force 10%", 0, "textures/items/blaze_rod");
       
        $form->addButton("Bâton tp 10%", 0, "textures/items/flint");
        $form->addButton("Bâton bedo 7%", 0, "textures/items/ghast_tear");
        $form->sendToPlayer($player);
    }
    
     public static function openBox(Player $player)
    {
         if ($player->getInventory()->contains(ItemFactory::getInstance()->get(399, 0, 1)->setLore(["Box stick"]))) {
                
                       
                       if(!$player->getInventory()->canAddItem(ItemFactory::getInstance()->get(0, 0))){
                           $player->sendActionBarMessage("§cVous n’avez pas asser de place dans votre inventaire !");
                           return;
                       }
             
             		   $player->getInventory()->removeItem(ItemFactory::getInstance()->get(399, 0, 1)->setLore(["Box stick"]));
                       $player->getServer()->broadcastMessage("Le joueur §1{$player->getName()} §fvient d'ouvrir une §9Box Stick §f!");
                       
                       $rdm = mt_rand(1, 136);
                       
                       if($rdm <= 25){
                           $newItem = ItemFactory::getInstance()->get(288, 0, 5); #redbull
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 40){
                           $newItem = ItemFactory::getInstance()->get(405, 0, 1); #baton de regen
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 55){
                           $newItem = ItemFactory::getInstance()->get(336, 0, 1); #baton de saut
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 70){
                           $newItem = ItemFactory::getInstance()->get(353, 0, 1); #baton de vitesse
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 80){  #baton de force
                            $newItem = ItemFactory::getInstance()->get(369, 0, 1);#force
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 87){ #baton bedo
                           $newItem = ItemFactory::getInstance()->get(370, 0, 1); 
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                        elseif($rdm <= 98){ #baton citrouille
                           $newItem = ItemFactory::getInstance()->get(263, 1, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 109){  #aveuglement
                           $newItem = ItemFactory::getInstance()->get(378, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       elseif($rdm <= 119){  #baton de tp
                           $newItem = ItemFactory::getInstance()->get(318, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       else { #plume
						   $newItem = ItemFactory::getInstance()->get(377, 0, 5);
                           $newItem->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PUNCH(), 1));
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                   } else $player->sendMessage("§cVous n'avez pas de clé stick !");
               }
			}
         