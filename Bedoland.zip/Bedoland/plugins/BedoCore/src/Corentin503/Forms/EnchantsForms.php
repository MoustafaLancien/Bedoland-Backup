<?php

namespace Corentin503\Forms;

use Corentin503\API\MoneyAPI;
use onebone\economyapi\EconomyAPI;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\Item;
use pocketmine\player\Player;
use TheStepKla\FormAPI\CustomForm;
use TheStepKla\FormAPI\SimpleForm;
use pocketmine\item\Tool;
use pocketmine\item\Armor;

class EnchantsForms
{
    public static function formP(Player $player)
    {
        $form = new SimpleForm(function (Player $player, $data) {
            if (is_null($data)) return;

            switch ($data) {
                case 0:
                    self::enchants($player, VanillaEnchantments::UNBREAKING(), "Solidité", 25, $player->getInventory()->getItemInHand());
                    break;
                case 1:
                    self::enchants($player, VanillaEnchantments::SHARPNESS(), "Tranchant", 50, $player->getInventory()->getItemInHand());
                    break;
                case 2:
                    self::enchants($player, VanillaEnchantments::PROTECTION(), "Protection", 40, $player->getInventory()->getItemInHand());
                    break;
                case 3:
                    self::enchants($player, VanillaEnchantments::EFFICIENCY(), "Efficacité", 80, $player->getInventory()->getItemInHand());
                    break;
                case 4:
                    self::enchants($player, VanillaEnchantments::PUNCH(), "Punch", 150, $player->getInventory()->getItemInHand());
                    break;
            }
        });

        $form->setTitle("§2Enchantements");
        $form->addButton("§bSolidité\n §625 / niveau");
        $form->addButton("§bTranchant\n §650 / niveau");
        $form->addButton("§bProtection\n §640 / niveau");
        $form->addButton("§bEfficacité\n §680 / niveau");
        $form->addButton("§bPunch\n §6150 / niveau");
        $form->sendToPlayer($player);
    }

    public static function enchants(Player $player, Enchantment $enchantment, string $string, int $price, Item $item)
    {
        $form = new CustomForm(function (Player $player, $data) use ($enchantment, $price, $item) {
            if (is_null($data)) return;

            $selec = (int)$data[1];
            $item = $player->getInventory()->getItemInHand();
            if ($item instanceof Armor or $item instanceof Tool) {
            if (EconomyAPI::getInstance()->MyMoney($player) >= $price * $selec) {
                EconomyAPI::getInstance()->reduceMoney($player, $price * $selec);
                $item->addEnchantment(new EnchantmentInstance($enchantment, $selec));
                $player->getInventory()->setItemInHand($item);
                $player->sendMessage("§aVous avez bien enchanté votre item avec {$enchantment->getName()->getText()} niveau {$selec}");
            } else $player->sendMessage("§cVous n'avez pas assez d'argent !");
          } else $player->sendMessage("§cTennez un item en main !");     
        });

        $form->setTitle("§2{$string}");
        $form->addLabel("§6{$price} / niveau");
        $form->addSlider("Niveau:", 1, $enchantment->getMaxLevel());
        $form->sendToPlayer($player);
    }
}