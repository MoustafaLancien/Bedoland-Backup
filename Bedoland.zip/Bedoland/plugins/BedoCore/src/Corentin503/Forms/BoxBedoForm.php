<?php

namespace Corentin503\Forms;

use Corentin503\API\MoneyAPI;
use TheStepKla\FormAPI\CustomForm;
use TheStepKla\FormAPI\SimpleForm;
use TheStepKla\FormAPI\Form;
use TheStepKla\FormAPI\ModalForm;
use TheStepKla\FormAPI\FormAPI;
use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\lang\Language;


class BoxBedoForm
{				

    public static function openForm(Player $player)
    {


        $form = new SimpleForm(function (Player $player, $data) {
            if ($data === null) {
                return;
            }
            switch ($data) {
                case 0:
                    self::openBox($player);
                    break;
                case 1:
                    $a = "b";
                    break;


            }
        }
        );
        $form->setTitle("§4§l« §r§aBoxBedo §4§l»");
        $form->setContent("§eVoici les loots: \n");
        $form->addButton("§c§lOUVRIR", 0, "textures/ui/interact");
        $form->addButton("Perle x8 16%", 0, "textures/items/ender_pearl");
        $form->addButton("Plume x8 16%", 0, "textures/items/blaze_powder");
        $form->addButton("Bâton de saut 15%", 0, "textures/items/brick");
        $form->addButton("Bâton d'aveuglement 14%", 0, "textures/items/magma_cream");
        $form->addButton("Bâton de regen 14%", 0, "textures/items/netherbrick");
        $form->addButton("Baton de speed 14%", 0, "textures/items/sugar");
        $form->addButton("Boule de tp 14%", 0, "textures/items/egg");
        $form->addButton("Bâton citrouille 13%", 0, "textures/items/charcoal");
        $form->addButton("Radar 11%", 0, "textures/items/compass");
        $form->addButton("Clé tags 10%", 0, "textures/items/nether_star");        
        $form->addButton("Arc punch 9%", 0, "textures/items/bow_pulling_2");
        $form->addButton("Bâton de force 8%", 0, "textures/items/blaze_rod");
        $form->addButton("Casque LSD P4 8%", 0, "textures/items/gold_helmet");
        $form->addButton("Bâton tp 8%", 0, "textures/items/flint");
        $form->addButton("Bottes LSD P4 7%", 0, "textures/items/gold_boots");
        $form->addButton("Casque mineur 7%", 0, "textures/items/turtle_helmet");
        $form->addButton("Jambières LSD P4 6%", 0, "textures/items/gold_leggings");
        $form->addButton("Epée LSD T5 6%", 0, "textures/items/gold_sword");
        $form->addButton("Plastron LSD P4 5%", 0, "textures/items/gold_chestplate");
        $form->addButton("Bâton bedo 5%", 0, "textures/items/ghast_tear");
        $form->addButton("Epée en Bedo 2%", 0, "textures/items/wood_sword");
        $form->addButton("Casque en Bedo 2%", 0, "textures/items/leather_helmet");
        $form->addButton("Plastron en Bedo 2%", 0, "textures/items/leather_chestplate");
        $form->addButton("Jambières en Bedo 2%", 0, "textures/items/leather_leggings");
        $form->addButton("Bottes en Bedo 2%", 0, "textures/items/leather_boots");
        $form->sendToPlayer($player);
    }
    
     public static function openBox(Player $player)
    {
         if ($player->getInventory()->contains(ItemFactory::getInstance()->get(399, 0, 1)->setLore(["Box bedo"]))) {
                
                       
                       if(!$player->getInventory()->canAddItem(ItemFactory::getInstance()->get(0, 0))){
                           $player->sendActionBarMessage("§cVous n’avez pas assez de place dans votre inventaire !");
                           return;
                       }
             
             		   $player->getInventory()->removeItem(ItemFactory::getInstance()->get(399, 0, 1)->setLore(["Box bedo"]));
                       $player->getServer()->broadcastMessage("Le joueur §1{$player->getName()} §fvient d'ouvrir une §9Box Bedo §f!");
                       
                       $rdm = mt_rand(1, 218);
                       
                       if($rdm <= 2){
                           $newItem = ItemFactory::getInstance()->get(298, 0, 1); #casque bedo
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 4){
                           $newItem = ItemFactory::getInstance()->get(299, 0, 1); #plastron bedo
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 6){
                           $newItem = ItemFactory::getInstance()->get(300, 0, 1); #jambieres bedo
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 8){
                           $newItem = ItemFactory::getInstance()->get(301, 0, 1); #bottes bedo
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 18){
                           $player->getServer()->getCommandMap()->dispatch(new ConsoleCommandSender(Server::getInstance(), new Language("eng")), 'key '. $player->getName(). ' tag 1');
                           return;
                       }
                       
                       elseif($rdm <= 26){ #baton tp
                           $newItem = ItemFactory::getInstance()->get(318, 0, 1); 
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                        elseif($rdm <= 39){ #baton citrouille
                           $newItem = ItemFactory::getInstance()->get(263, 1, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 41){  #epee bedo
                           $newItem = ItemFactory::getInstance()->get(268, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       
                       elseif($rdm <= 50){ #arc punch
						   $newItem = ItemFactory::getInstance()->get(ItemIds::BOW, 0, 1);
                           $newItem->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PUNCH(), 1));
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       elseif($rdm <= 66){ #perle
                           $newItem = ItemFactory::getInstance()->get(368, 0, 8);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
             		   elseif($rdm <= 80){ #baton d'aveuglement
                           $newItem = ItemFactory::getInstance()->get(378, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       elseif($rdm <= 91){ #radar
                           $newItem = ItemFactory::getInstance()->get(345, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       elseif($rdm <= 107){ #plume
                           $newItem = ItemFactory::getInstance()->get(377, 0, 8);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       elseif($rdm <= 121){ #boule de tp
                           $newItem = ItemFactory::getInstance()->get(344, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       elseif($rdm <= 129){ #baton force
                           $newItem = ItemFactory::getInstance()->get(369, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       elseif($rdm <= 144){ #baton de saut
                           $newItem = ItemFactory::getInstance()->get(336, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       } 
                        elseif($rdm <= 158){ #baton de regen
                           $newItem = ItemFactory::getInstance()->get(405, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                        elseif($rdm <= 172){ #speed
                           $newItem = ItemFactory::getInstance()->get(353, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }         
             			elseif($rdm <= 180){ #casque P4 lsd
                           $newItem = ItemFactory::getInstance()->get(ItemIds::GOLDEN_HELMET, 0, 1);
                           $newItem->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4));
                           $player->getInventory()->addItem($newItem);
                           return;
                       }
                       elseif($rdm <= 185){ #plastron p4 lsd
                           $newItem = ItemFactory::getInstance()->get(ItemIds::GOLDEN_CHESTPLATE, 0, 1);
                           $newItem->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4));
                           $player->getInventory()->addItem($newItem);
                           return;
                       }         
						elseif($rdm <= 191){ #jambiere p4 lsd
                           $newItem = ItemFactory::getInstance()->get(ItemIds::GOLDEN_LEGGINGS, 0, 1);
                           $newItem->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4));
                           $player->getInventory()->addItem($newItem);
                           return;
                       }         
                       elseif($rdm <= 198){ #bottes ps4 lsd
                           $newItem = ItemFactory::getInstance()->get(ItemIds::GOLDEN_BOOTS, 0, 1);
                           $newItem->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4));
                           $player->getInventory()->addItem($newItem);
                           return;
                       }         
                       elseif($rdm <= 205){ #sword
                           $newItem = ItemFactory::getInstance()->get(ItemIds::GOLDEN_SWORD, 0, 1);
                           $newItem->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 5));
                           $player->getInventory()->addItem($newItem);
                           return;
                       }         
                       elseif($rdm <= 211){ #baton bedo
                           $newItem = ItemFactory::getInstance()->get(370, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }         
                       else{ #casque mineur
                           $newItem = ItemFactory::getInstance()->get(469, 0, 1);
                           $player->getInventory()->addItem($newItem);
                           return;
                       }         
                       
                   } else $player->sendMessage("§cVous n'avez pas de clé bedo !");
               }
			}
         