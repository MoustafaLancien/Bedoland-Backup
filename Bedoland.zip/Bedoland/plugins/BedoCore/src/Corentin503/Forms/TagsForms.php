<?php

namespace Corentin503\Forms;

use Corentin503\API\MoneyAPI;
use TheStepKla\FormAPI\CustomForm;
use TheStepKla\FormAPI\SimpleForm;
use TheStepKla\FormAPI\Form;
use TheStepKla\FormAPI\ModalForm;
use TheStepKla\FormAPI\FormAPI;
use pocketmine\block\Anvil;
use pocketmine\item\Item;
use pocketmine\item\Tool;
use pocketmine\item\Armor;
use pocketmine\item\ItemFactory;
use pocketmine\item\VanillaItems;
use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\lang\Language;
use pocketmine\utils\TextFormat;
use _64FF00\PureChat\PureChat;

class TagsForms
{
    public static function BoxUi($sender)
    {
        $form = new SimpleForm(function (Player $sender, $data){
            $item = ItemFactory::getInstance()->get(VanillaItems::RABBIT_FOOT()->getId(), 0, 1);
            if ($data === null) {
                return null;
            }
            switch ($data) {
                case 0:
                    if ($sender->getInventory()->contains($item)) {
                        $lots = mt_rand(1, 101);
                        if ($lots >= 1 && $lots < 6) {
                            $cmd = 'setuperm ';
                            $sender->sendMessage("§6§l»§r§f Vous avez reçu le tag #§920CPS§f !");
							Server::getInstance()->dispatchCommand(new ConsoleCommandSender(Server::getInstance(), new Language("eng")), 'setuperm ' . $sender->getName() . ' tags.20cps');
                            $sender->getInventory()->removeItem(ItemFactory::getInstance()->get(VanillaItems::RABBIT_FOOT()->getId(), 0, 1));
                        }
                        if ($lots >= 6 && $lots < 11) {
                            $sender->sendMessage("§6§l»§r§f Vous avez reçu le tag #§5Free§1Kill§f !");
                            Server::getInstance()->dispatchCommand(new ConsoleCommandSender(Server::getInstance(), new Language("eng")), 'setuperm ' . $sender->getName() . ' tags.freekill');
                            $sender->getInventory()->removeItem(ItemFactory::getInstance()->get(VanillaItems::RABBIT_FOOT()->getId(), 0, 1));
                        }
                        if ($lots >= 11 && $lots < 21) {
                            $sender->sendMessage("§6§l»§r§f Vous avez reçu le tag #§8Cheateur§f !");
							Server::getInstance()->dispatchCommand(new ConsoleCommandSender(Server::getInstance(), new Language("eng")), 'setuperm ' . $sender->getName() . ' tags.cheateur');
                            $sender->getInventory()->removeItem(ItemFactory::getInstance()->get(VanillaItems::RABBIT_FOOT()->getId(), 0, 1));
                        }
                        if ($lots >= 21 && $lots < 31) {
                            $sender->sendMessage("§6§l»§r§f Vous avez reçu le tag #§2Bedo§3Land§f !");
							Server::getInstance()->dispatchCommand(new ConsoleCommandSender(Server::getInstance(), new Language("eng")), 'setuperm ' . $sender->getName() . ' tags.bedoland');
                            $sender->getInventory()->removeItem(ItemFactory::getInstance()->get(VanillaItems::RABBIT_FOOT()->getId(), 0, 1));
                        }
                        if ($lots >= 31 && $lots < 41) {
                            $sender->sendMessage("§6§l»§r§f Vous avez reçu le tag #§6NO§aLIFE§f !");
							Server::getInstance()->dispatchCommand(new ConsoleCommandSender(Server::getInstance(), new Language("eng")), 'setuperm ' . $sender->getName() . ' tags.nolife');
                            $sender->getInventory()->removeItem(ItemFactory::getInstance()->get(VanillaItems::RABBIT_FOOT()->getId(), 0, 1));
                        }
                        if ($lots >= 41 && $lots < 51) {
                            $sender->sendMessage("§6§l»§r§f Vous avez reçu le tag #§aP§7V§aP§f !");
							Server::getInstance()->dispatchCommand(new ConsoleCommandSender(Server::getInstance(), new Language("eng")), 'setuperm ' . $sender->getName() . ' tags.pvp');
                            $sender->getInventory()->removeItem(ItemFactory::getInstance()->get(VanillaItems::RABBIT_FOOT()->getId(), 0, 1));
                        }
                        if ($lots >= 51 && $lots < 61) {
                            $sender->sendMessage("§6§l»§r§f Vous avez reçu le tag #§3Fr§fan§4ce§f !");
							Server::getInstance()->dispatchCommand(new ConsoleCommandSender(Server::getInstance(), new Language("eng")), 'setuperm ' . $sender->getName() . ' tags.france');
                            $sender->getInventory()->removeItem(ItemFactory::getInstance()->get(VanillaItems::RABBIT_FOOT()->getId(), 0, 1));
                        }
                        if ($lots >= 61 && $lots < 71) {
                            $sender->sendMessage("§6§l»§r§f Vous avez reçu le tag #§6N§cOO§6B§f !");
							Server::getInstance()->dispatchCommand(new ConsoleCommandSender(Server::getInstance(), new Language("eng")), 'setuperm ' . $sender->getName() . ' tags.noob');
                            $sender->getInventory()->removeItem(ItemFactory::getInstance()->get(VanillaItems::RABBIT_FOOT()->getId(), 0, 1));
                        }
                        if ($lots >= 71 && $lots < 81) {
                            $sender->sendMessage("§6§l»§r§f Vous avez reçu le tag #§9EZ§f !");
							Server::getInstance()->dispatchCommand(new ConsoleCommandSender(Server::getInstance(), new Language("eng")), 'setuperm ' . $sender->getName() . ' tags.ez');
                            $sender->getInventory()->removeItem(ItemFactory::getInstance()->get(VanillaItems::RABBIT_FOOT()->getId(), 0, 1));
                        }
                        if ($lots >= 81 && $lots < 91) {
                            $sender->sendMessage("§6§l»§r§f Vous avez reçu le tag #§4Karma§f !");
							Server::getInstance()->dispatchCommand(new ConsoleCommandSender(Server::getInstance(), new Language("eng")), 'setuperm ' . $sender->getName() . ' tags.karma');
                            $sender->getInventory()->removeItem(ItemFactory::getInstance()->get(VanillaItems::RABBIT_FOOT()->getId(), 0, 1));
                        }
                        if ($lots >= 91 && $lots < 101) {
                            $sender->sendMessage("§6§l»§r§f Vous avez reçu le tag #§6TRY§eHARD§f !");
							Server::getInstance()->dispatchCommand(new ConsoleCommandSender(Server::getInstance(), new Language("eng")), 'setuperm ' . $sender->getName() . ' tags.tryhard');
                            $sender->getInventory()->removeItem(ItemFactory::getInstance()->get(VanillaItems::RABBIT_FOOT()->getId(), 0, 1));
                        }
                    } else {
                        $sender->sendMessage("§e§l»§r§f Vous n'avez pas de §6Clé Tag§f !");
                        self::BoxUi($sender);
                    }
                    break;
                case 1:
                    break;
            }
        });
        $c = 0;
        $id = 414;
        $meta = 0;
        foreach ($sender->getInventory()->getContents() as $item) {
            if ($item instanceof Item && $item->getId() == $id && $item->getMeta() == $meta) $c += $item->getCount();
        }
        $name = $sender->getName();
        $form->setTitle("§e- §fBox Tag §e-");
        $form->setContent("§6§l»§r§f Vous avez §6$c clé(s) tag§f dans votre inventaire !\n\nVoici les différents tags :\n§r- #§920CPS\n§r- #§5Free§1Kill\n§r- #§8Cheateur\n§r- #§2Bedo§3Land\n§r- #§4NO§2LIFE\n§r- #§aP§7V§aP\n§r- #§3Fr§fan§4ce\n§r- #§6N§cOO§6B\n§r- #§9EZ\n§r- #§4Karma\n§r- #§6TRY§eHARD §f\n\nVoulez vous ouvrir une box tag ?");
        $form->addButton("§aOuvrir");
        $form->addButton("§cFermer");
        $form->sendToPlayer($sender);
    }
    
      public static function tagsForm(Player $player) {
    
    	
        $form = new SimpleForm(function (Player $player, $data){
            if ($data === null) {
                return;
            }
            switch ($data) {
                case 0: // Second button (to second page)

                            if (!$player->hasPermission("tags.notag")) {
                                $player->sendMessage("Ce tag est verrouillé !");
                                return true;
                            }else{
        
								/*Tag Activatded*/
        
                                $ppchat = $player->getServer()->getPluginManager()->getPlugin("PureChat");
                                $ppchat->setSuffix((""), $player);
								$player->sendMessage("Votre tag a été retiré !");
						}
                            return true;                
                case 1: // Second button (to second page)

                            if (!$player->hasPermission("tags.20cps")) {
                                $player->sendMessage("Ce tag est verrouillé !");
                                return true;
                            }else{
        
								/*Tag Activatded*/
        
                                $ppchat = $player->getServer()->getPluginManager()->getPlugin("PureChat");
                                $ppchat->setSuffix(("#§920CPS§r"), $player);
								$player->sendMessage("Tag #§920CPS §réquipé !");
						}
                            return true;
                case 2: // Second button (to second page)
                            if (!$player->hasPermission("tags.freekill")) {
                                $player->sendMessage("Ce tag est verrouillé !");
                                return true;
                            }else{
        
								/*Tag Activatded*/
        
                                $ppchat = $player->getServer()->getPluginManager()->getPlugin("PureChat");
                                $ppchat->setSuffix(("#§5Free§1Kill§r"), $player);
								$player->sendMessage("Tag #§5Free§1Kill §réquipé !");
						}
                            return true;
                case 3: // Second button (to second page)

                            if (!$player->hasPermission("tags.cheateur")) {
                                $player->sendMessage("Ce tag est verrouillé !");
                                return true;
                            }else{
        
								/*Tag Activatded*/
        
                                $ppchat = $player->getServer()->getPluginManager()->getPlugin("PureChat");
                                $ppchat->setSuffix(("#§8Cheateur§r"), $player);
								$player->sendMessage("Tag #§8Cheateur §réquipé !");
						}
                            return true;
                case 4: // Second button (to second page)
                            if (!$player->hasPermission("tags.bedoland")) {
                                $player->sendMessage("Ce tag est verrouillé !");
                                return true;
                            }else{
        
								/*Tag Activatded*/
        
                                $ppchat = $player->getServer()->getPluginManager()->getPlugin("PureChat");
                                $ppchat->setSuffix(("#§2Bedo§3Land§r"), $player);
								$player->sendMessage("Tag #§2Bedo§3Land §réquipé !");
						}
                            return true;
                case 5: // Second button (to second page)

                            if (!$player->hasPermission("tags.nolife")) {
                                $player->sendMessage("Ce tag est verrouillé !");
                                return true;
                            }else{
        
								/*Tag Activatded*/
        
                                $ppchat = $player->getServer()->getPluginManager()->getPlugin("PureChat");
                                $ppchat->setSuffix(("#§6NO§aLIFE§r"), $player);
								$player->sendMessage("Tag #§6NO§aLIFE §réquipé !");
						}
                            return true;
                case 6: // Second button (to second page)

                            if (!$player->hasPermission("tags.pvp")) {
                                $player->sendMessage("Ce tag est verrouillé !");
                                return true;
                            }else{
        
								/*Tag Activatded*/
        
                                $ppchat = $player->getServer()->getPluginManager()->getPlugin("PureChat");
                                $ppchat->setSuffix(("#§aP§7V§aP§r"), $player);
								$player->sendMessage("Tag #§aP§7V§aP §réquipé !");
						}
                            return true;
                case 7: // Second button (to second page)

                            if (!$player->hasPermission("tags.france")) {
                                $player->sendMessage("Ce tag est verrouillé !");
                                return true;
                            }else{
        
								/*Tag Activatded*/
        
                                $ppchat = $player->getServer()->getPluginManager()->getPlugin("PureChat");
                                $ppchat->setSuffix(("#§3Fr§fan§4ce§r"), $player);
								$player->sendMessage("Tag #§3Fr§fan§4ce §réquipé !");
						}
                            return true;
                case 8: // Second button (to second page)

                            if (!$player->hasPermission("tags.noob")) {
                                $player->sendMessage("Ce tag est verrouillé !");
                                return true;
                            }else{
        
								/*Tag Activatded*/
        
                                $ppchat = $player->getServer()->getPluginManager()->getPlugin("PureChat");
                                $ppchat->setSuffix(("#§6N§cOO§6B§r"), $player);
								$player->sendMessage("Tag #§6N§cOO§6B §réquipé !");
						}
                            return true;
                case 9: // Second button (to second page)

                            if (!$player->hasPermission("tags.ez")) {
                                $player->sendMessage("Ce tag est verrouillé !");
                                return true;
                            }else{
        
								/*Tag Activatded*/
        
                                $ppchat = $player->getServer()->getPluginManager()->getPlugin("PureChat");
                                $ppchat->setSuffix(("#§9EZ§r"), $player);
								$player->sendMessage("Tag #§9EZ §réquipé !");
						}
                            return true; 
                case 10: // Second button (to second page)

                            if (!$player->hasPermission("tags.karma")) {
                                $player->sendMessage("Ce tag est verrouillé !");
                                return true;
                            }else{
        
								/*Tag Activatded*/
        
                                $ppchat = $player->getServer()->getPluginManager()->getPlugin("PureChat");
                                $ppchat->setSuffix(("#§4Karma§r"), $player);
								$player->sendMessage("Tag #§4Karma §réquipé !");
						}
                            return true;
                case 11: // Second button (to second page)

                            if (!$player->hasPermission("tags.tryhard")) {
                                $player->sendMessage("Ce tag est verrouillé !");
                                return true;
                            }else{
        
								/*Tag Activatded*/
        
                                $ppchat = $player->getServer()->getPluginManager()->getPlugin("PureChat");
                                $ppchat->setSuffix(("#§6TRY§eHARD§r"), $player);
								$player->sendMessage("Tag #§6TRY§eHARD §réquipé !");
						}
                            return true;                                                                                                                                                                                                   
      
            }
            }
        );
        $form->setTitle("§b§lTags");
        $form->setContent("§7Choisissez un tag :");

        $form->addButton($player->hasPermission("tags.notag") === true ? "§l§cRetirer le tag" : "§l§cRetirer le tag");
		
        $form->addButton($player->hasPermission("tags.20cps") === true ? "#§920CPS§r\n§a§lDébloqué" : "#§920CPS§r\n§c§lBloqué");
		
		$form->addButton($player->hasPermission("tags.freekill") === true ? "#§5Free§1Kill§r\n§a§lDébloqué" : "#§5Free§1Kill§r\n§c§lBloqué");
		
        $form->addButton($player->hasPermission("tags.cheateur") === true ? "#§8Cheateur§r\n§a§lDébloqué" : "#§8Cheateur§r\n§c§lBloqué");
		
		$form->addButton($player->hasPermission("tags.bedoland") === true ? "#§2Bedo§3Land§r\n§a§lDébloqué" : "#§2Bedo§3Land§r\n§c§lBloqué"); 
		
        $form->addButton($player->hasPermission("tags.nolife") === true ? "#§6NO§aLIFE§r\n§a§lDébloqué" : "#§6NO§aLIFE§r\n§c§lBloqué");
		
        $form->addButton($player->hasPermission("tags.pvp") === true ? "#§aP§7V§aP§r\n§a§lDébloqué" : "#§aP§7V§aP§r\n§c§lBloqué");
		
        $form->addButton($player->hasPermission("tags.france") === true ? "#§3Fr§fan§4ce§r\n§a§lDébloqué" : "#§3Fr§fan§4ce§r\n§c§lBloqué");
		
        $form->addButton($player->hasPermission("tags.noob") === true ? "#§6N§cOO§6B§r\n§a§lDébloqué" : "#§6N§cOO§6B§r\n§c§lBloqué");

        $form->addButton($player->hasPermission("tags.ez") === true ? "#§9EZ§r\n§a§lDébloqué" : "#§9EZ§r\n§c§lBloqué");
		
		$form->addButton($player->hasPermission("tags.karma") === true ? "#§4Karma§r\n§a§lDébloqué" : "#§4Karma§r\n§c§lBloqué");
		
		$form->addButton($player->hasPermission("tags.tryhard") === true ? "#§6TRY§eHARD§r\n§a§lDébloqué" : "#§6TRY§eHARD§r\n§c§lBloqué");
        
        $form->addButton("§c§lRETOUR");
        $form->sendToPlayer($player);
    }
  
}