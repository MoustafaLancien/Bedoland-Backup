<?php

namespace Corentin503\Commands\Gamemode;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\player\GameMode;

class Gm1 extends Command
{
    public function __construct()
    {
        parent::__construct("gm1", "§a»§f Se mettre en créatif", "/gm1");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player) {
            if ((Server::getInstance()->isOp($sender->getName())) or ($sender->hasPermission("gamemode1.command"))) {
                    $sender->setGamemode(GameMode::CREATIVE());
                    $sender->sendMessage("§6Mode de jeu défini en créatif");
                } else {
                    $sender->sendMessage("Vous n'avez pas le droit d'utiliser cette commande");
                }
        }
    }
}