<?php

namespace Corentin503\Commands\Gamemode;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\player\GameMode;
use pocketmine\Server;

class gm0 extends Command
{
    public function __construct()
    {
        parent::__construct("gm0", "§a»§f Se mettre en créatif", "/gm0");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player) {
             if ((Server::getInstance()->isOp($sender->getName())) or ($sender->hasPermission("gamemode0.command"))) {
                    $sender->setGamemode(GameMode::SURVIVAL());
                    $sender->sendMessage("§6Mode de jeu défini en survie");
                } else {
                    $sender->sendMessage("Vous n'avez pas le droit d'utiliser cette commande");
                }
        }
    }
}