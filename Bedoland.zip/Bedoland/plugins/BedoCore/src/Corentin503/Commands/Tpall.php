<?php

namespace Corentin503\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;

class Tpall extends Command
{
    public function __construct()
    {
        parent::__construct("tpall", "Permet de téléporter tous les tous du serveur !", "/tpall");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ((Server::getInstance()->isOp($sender->getName())) or ($sender->hasPermission("tpall.cmd"))) {
             foreach (Server::getInstance()->getOnlinePlayers() as $tpPlayer) {
            $name = $sender->getName();
        	$tpPlayer->sendMessage("§l[§a!!!§f] §r§9Toutes les personnes du serveur ont été téléporté vers §f$name");
       		$tpPlayer->teleport($sender->getPosition());
			} return true;
        }
    }
}