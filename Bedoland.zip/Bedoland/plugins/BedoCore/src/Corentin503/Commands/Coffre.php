<?php

namespace Corentin503\Commands;

use tedo0627\inventoryui\CustomInventory;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Location;
use pocketmine\player\Player;
use pocketmine\Server;

class Coffre extends Command
{

    public function __construct() {
        parent::__construct("coffre", "§a»§f Permet d'acceder au coffre", "/coffre");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {

        if($sender instanceof Player){
            $sender->setCurrentWindow(new CustomInventory(1000, "coffre", 6));
        }

    }
}