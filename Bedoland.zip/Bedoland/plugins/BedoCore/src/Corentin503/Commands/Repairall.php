<?php

namespace Corentin503\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\Durable;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use pocketmine\Server;
use Corentin503\API\CooldownAPI;

class Repairall extends Command
{
    public function __construct()
    {
        parent::__construct("repairall", "§a»§f Permet de réparer tous les items de votre inventaire !", "/repairall");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if(!$sender instanceof Player){
            return true;
        }
        if ((Server::getInstance()->isOp($sender->getName())) or ($sender->hasPermission("repairall.use"))) {
            if (!isset(CooldownAPI::$cooldown_repairall[$sender->getName()]) || CooldownAPI::$cooldown_repairall[$sender->getName()] - time() <= 0) {
                CooldownAPI::$cooldown_repairall[$sender->getName()] = time() + 15*60;
                foreach ($sender->getInventory()->getContents() as $index => $item) {
                    if ($item instanceof Durable) {
                        $sender->getInventory()->setItem($index, $item->setDamage(0));
                    }
                }
                $sender->sendMessage(TextFormat::GREEN . "Tous les items de votre inventaire ont été réparé !");
            } else {
                $time = CooldownAPI::$cooldown_repairall[$sender->getName()] - time();
                $minutes = $time/60;
                $arrondi= round($minutes);
                $sender->sendMessage("§cVous devez encore attendre §6{$arrondi} minutes§c pour repair all !");
            }
        } else $sender->sendMessage(TextFormat::RED."Tu n'as pas la permission de faire cela !");
    }
}