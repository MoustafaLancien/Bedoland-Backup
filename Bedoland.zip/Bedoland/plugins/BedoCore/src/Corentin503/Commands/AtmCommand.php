<?php

namespace Corentin503\Commands;

use Corentin503\API\AtmAPI;
use Corentin503\API\MoneyAPI;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use TheStepKla\FormAPI\SimpleForm;
use onebone\economyapi\EconomyAPI;

class AtmCommand extends Command
{
    public function __construct()
    {
        parent::__construct("atm", "§a§l»§r§f Permet d'afficher l'interface d'atm", "/atm");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player) {
            if (AtmAPI::getDataFile()->exists($sender->getName())) {
                $form = new SimpleForm(function (Player $player, int $data = null) {
                    if ($data === null) return;

                    switch ($data) {
                        default:
                            $money = AtmAPI::getDataFile()->get($player->getName());
                            EconomyAPI::getInstance()->addMoney($player, $money);
                            $player->sendMessage("§9Vous avez reçu §f{$money}$ §9de votre ATM");
                            AtmAPI::getDataFile()->set($player->getName(), 0);
                            break;
                    }
                });
                $money = AtmAPI::getDataFile()->get($sender->getName());
                $form->setTitle("§9[§fATM§9]§f");
                $form->setContent("§9Vous pouvez récuperer §f{$money}$ §9!");
                $form->addButton("§aRécuper");
                $sender->sendForm($form);
            } else $sender->sendMessage("§cVous n'avez pas asser jouer");
        }
    }
}