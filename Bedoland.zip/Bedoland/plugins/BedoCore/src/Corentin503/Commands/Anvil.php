<?php

namespace Corentin503\Commands;

use Corentin503\Forms\AnvilForms;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class Anvil extends Command
{
    public function __construct()
    {
        parent::__construct("anvil", "§a»§f Permet d'acceder à l'enclume", "/anvil");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player) {
            AnvilForms::openForm($sender);
        }
    }
}