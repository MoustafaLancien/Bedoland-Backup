<?php

namespace Corentin503\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\Durable;
use pocketmine\player\Player;
use pocketmine\Server;

class DuraDefaut extends Command
{
    public function __construct()
    {
        parent::__construct("dura", "§a§l»§r§f Permet d'avoir la dura par défaut", "/dura");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (Server::getInstance()->isOp($sender->getName())) {
            if ($sender instanceof Player) {
                $item = $sender->getInventory()->getItemInHand();
                if ($item instanceof Durable) {
                    $sender->sendMessage("{$item->getCustomName()} à {$item->getMaxDurability()} de dura max");
                }
            }
        }
    }
}