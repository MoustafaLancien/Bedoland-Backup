<?php

namespace Corentin503\Commands;

use Corentin503\Entitys\Chicha;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\ItemFactory;
use pocketmine\Server;

class Chichaspawn extends Command
{
    public function __construct()
    {
        parent::__construct("chichaspawn", "§a§l»§r§f Permet de se spawn une chicha", "/chichaspawn");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player) {
            if (Server::getInstance()->isOp($sender->getName())) {
                $chicha = new Chicha($sender->getLocation());
                $chicha->spawnToAll();
            } else $sender->sendMessage("§cVous n'avez pas la permission !");   
        }
    }
}