<?php

namespace Corentin503\Commands;

use Corentin503\API\MoneyAPI;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\ItemFactory;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class Keyall extends Command
{
    public function __construct()
    {
        parent::__construct("keyall", "§a§l»§r§f Permet de give une key à tout les joueurs", "/key");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player) {
      if ((Server::getInstance()->isOp($sender->getName())) or ($sender->hasPermission("key.give"))) {
         if(count($args) < 2) {
            $sender->sendMessage(TextFormat::RED . "Usage: /keyall <box> <nombre>");
            return true;
        }
            if (!isset($args[0])) {
                $sender->sendMessage("§cMerci d'indiquer une key");
                return;
            }

            if (!is_numeric($args[1])) {
                $sender->sendMessage("§cMerci d'indiquer un montant");
            } else $count = (int)$args[1];

            foreach (Server::getInstance()->getOnlinePlayers() as $player){
            if ($player instanceof Player) {
			if ($args[0] == "tag") {
            $item = ItemFactory::getInstance()->get(414, 0, $count);
            $player->getInventory()->addItem($item);
            }
           else {
            $item = ItemFactory::getInstance()->get(399, 0, $count)->setLore(["Box {$args[0]}"]);
            $player->getInventory()->addItem($item);
          		 }
              }
            }     
        } else $sender->sendMessage("Tu n'as pas la perm");
      } else {
                 if(count($args) < 2) {
            $sender->sendMessage(TextFormat::RED . "Usage: /keyall <box> <nombre>");
            return true;
        }
            if (!isset($args[0])) {
                $sender->sendMessage("§cMerci d'indiquer une key");
                return;
            }

            if (!is_numeric($args[1])) {
                $sender->sendMessage("§cMerci d'indiquer un montant");
            } else $count = (int)$args[1];

            foreach (Server::getInstance()->getOnlinePlayers() as $player){
            if ($player instanceof Player) {
                
            			if ($args[0] == "tag") {
            $item = ItemFactory::getInstance()->get(414, 0, $count);
            $player->getInventory()->addItem($item);
            }
           else {
            $item = ItemFactory::getInstance()->get(399, 0, $count)->setLore(["Box {$args[0]}"]);
            $player->getInventory()->addItem($item);
           }
              }
            } 
       } 
    }
}