<?php

namespace Corentin503\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Location;
use pocketmine\player\Player;
use pocketmine\Server;

class Spawn extends Command
{

    public function __construct() {
        parent::__construct("spawn", "§a»§f Permet de se tp au spawn", "/spawn", ["hub", "lobby"]);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {

        if($sender instanceof Player){
            Server::getInstance()->getWorldManager()->loadWorld("airlobby");
            $sender->teleport(new Location(0, 153, 0, $sender->getServer()->getWorldManager()->getWorldByName("bedoland"), 0, 0));
            $sender->sendMessage("§aVous avez bien été télporté au spawn !");
        }

    }
}