<?php

namespace Corentin503\Commands;

use Corentin503\API\MoneyAPI;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\ItemFactory;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class Key extends Command
{
    public function __construct()
    {
        parent::__construct("key", "§a§l»§r§f Permet de give une key", "/key");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
     if ($sender instanceof Player) {
       if (Server::getInstance()->isOp($sender->getName())) {
         if(count($args) < 3) {
            $sender->sendMessage(TextFormat::RED . "Usage: /key <pseudo> <box> <nombre>");
            return true;
        }
            if (!isset($args[0])) {
                $sender->sendMessage("§cMerci d'indiquer un joueur");
                return;
            }
            if (!isset($args[1])) {
                $sender->sendMessage("§cMerci d'indiquer une key");
                return;
            }

            if (!is_numeric($args[2])) {
                $sender->sendMessage("§cMerci d'indiquer un montant");
            } else $count = (int)$args[2];

            $player = Server::getInstance()->getPlayerByPrefix($args[0]);
            if (is_null($player)) {
                $sender->sendMessage("§cMerci d'indiquer un joueur connecté");
                return;
            }
			if ($args[1] == "tag") {
            $item = ItemFactory::getInstance()->get(414, 0, $count);
            $player->getInventory()->addItem($item);
            }
           else {
            $item = ItemFactory::getInstance()->get(399, 0, $count)->setLore(["Box {$args[1]}"]);
            $player->getInventory()->addItem($item);
           }
        } else $sender->sendMessage("§cTu n'as pas la permission");
      } else {
          if(count($args) < 3) {
            $sender->sendMessage(TextFormat::RED . "Usage: /key <pseudo> <box> <nombre>");
            return true;
        }
            if (!isset($args[0])) {
                $sender->sendMessage("§cMerci d'indiquer un joueur");
                return;
            }
            if (!isset($args[1])) {
                $sender->sendMessage("§cMerci d'indiquer une key");
                return;
            }

            if (!is_numeric($args[2])) {
                $sender->sendMessage("§cMerci d'indiquer un montant");
            } else $count = (int)$args[2];

            $player = Server::getInstance()->getPlayerByPrefix($args[0]);
            if (is_null($player)) {
                $sender->sendMessage("§cMerci d'indiquer un joueur connecté");
                return;
            }
			if ($args[1] == "tag") {
            $item = ItemFactory::getInstance()->get(414, 0, $count);
            $player->getInventory()->addItem($item);
            }
           else {
            $item = ItemFactory::getInstance()->get(399, 0, $count)->setLore(["Box {$args[1]}"]);
            $player->getInventory()->addItem($item);
           }
       } 
    }
}