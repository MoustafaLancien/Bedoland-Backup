<?php

namespace Corentin503\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class Id extends Command
{
    public function __construct()
    {
        parent::__construct("id", "§a§l»§r§f Permet d'obtenir l'id d'un item", "/id");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player) {
            $id = $sender->getInventory()->getItemInHand()->getId();
            $meta = $sender->getInventory()->getItemInHand()->getMeta();

            $sender->sendMessage("§9Item en main §f{$id}:{$meta} §9!");
        }
    }
}