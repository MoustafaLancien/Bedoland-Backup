<?php

namespace Corentin503\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;

class GiveAll extends Command
{
    public function __construct()
    {
        parent::__construct("giveall", "Permet de give a tout les joueurs du serveur l'item dans la main", "/giveall");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender->hasPermission("givall.use") || Server::getInstance()->isOp($sender->getName())) {
            if ($sender instanceof Player) {
                $item = $sender->getInventory()->getItemInHand();

                foreach (Server::getInstance()->getOnlinePlayers() as $players) {
                    if ($players->getInventory()->canAddItem($item)) {
                        $players->getInventory()->addItem($item);
                    } else $players->getWorld()->dropItem($players->getPosition()->asVector3(), $item);
                    $players->sendToastNotification("Giveall:", "Vous avez reçu: {$item->getCount()}x {$item->getCustomName()}");
                }
            }
        }
    }
}