<?php

namespace Corentin503\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;

class Nv extends Command
{
    public function __construct()
    {
        parent::__construct("nv", "§a»§f Permet d'avoir vision nocturne", "/nv");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player) {
            $eff = new EffectInstance(VanillaEffects::NIGHT_VISION(), 9999*99, 1, false);
            $sender->getEffects()->add($eff);
            $sender->sendMessage("§9Vous avez reçu un effet de vison nocturne !");
        }
    }
}