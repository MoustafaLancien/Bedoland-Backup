<?php

namespace Corentin503\Commands\Money;

use Corentin503\API\MoneyAPI;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class PayMoney extends Command
{
    public function __construct()
    {
        parent::__construct("pay", "Permet de payer de la money à un joueur", "/pay", ["paymoney"]);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!isset($args[0])) {
            $sender->sendMessage("§cMerci d'indiquer un joueur");
            return;
        }
        if (!is_numeric($args[1])) {
            $sender->sendMessage("§cMerci d'indiquer un montant");
        }

        $montant = (int)$args[1];

        if ($montant > 0) {
            $sender->sendMessage("§cMerci d'indiquer un montant");
        }

        if (MoneyAPI::getMoney($sender->getName()) >= $montant) {
            MoneyAPI::removeMoney($sender->getName(), $montant);
            MoneyAPI::addMoney($args[0], $montant);
            $sender->sendMessage("§aVous avez bien payé {$montant} à {$args[0]}");
        } else $sender->sendMessage("§cVous n'avez pas {$montant}");
    }
}