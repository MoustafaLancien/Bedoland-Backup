<?php

namespace Corentin503\Commands\Money;

use Corentin503\API\MoneyAPI;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class RemoveMoney extends Command
{
    public function __construct()
    {
        parent::__construct("removemoney", "Permet de retirer de la money à un joueur", "/removemoney");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ((Server::getInstance()->isOp($sender->getName())) or ($sender->hasPermission("money.remove"))) {
            if (!isset($args[0])) {
                $sender->sendMessage("§cMerci d'indiquer un joueur");
                return;
            }
            if (!is_numeric($args[1])) {
                $sender->sendMessage("§cMerci d'indiquer un montant");
            }

            $montant = (int)$args[1];

            if ($montant > 0) {
                $sender->sendMessage("§cMerci d'indiquer un montant");
            }

            MoneyAPI::removeMoney($args[0], $montant);
            $sender->sendMessage("§aVous avez bien retirer {$montant} à {$args[0]}");
        } else $sender->sendMessage("§cVous n'avez pas la permission");
    }
}