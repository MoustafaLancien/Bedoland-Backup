<?php

namespace Corentin503\Commands\Money;

use Corentin503\API\MoneyAPI;
use Corentin503\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class MyMoney extends Command
{
    public function __construct()
    {
        parent::__construct("mymoney", "Permet de voir sa money ou celle d'un autre joueur", "/mymoney", ["money", "balance"]);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player) {
            if (!isset($args[0])) {
                $money = MoneyAPI::getMoney($sender->getName());
                $sender->sendMessage("§aVous avez {$money}");
            } else {
                $money = MoneyAPI::getMoney($args[0]);
                $sender->sendMessage("§a{$args[0]} a {$money}");
            }
        }
    }
}