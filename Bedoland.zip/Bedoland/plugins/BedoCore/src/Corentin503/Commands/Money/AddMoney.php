<?php

namespace Corentin503\Commands\Money;

use Corentin503\API\MoneyAPI;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class AddMoney extends Command
{
    public function __construct()
    {
        parent::__construct("addmoney", "Permet d'ajouter de la money à un joueur", "/addmoney");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ((Server::getInstance()->isOp($sender->getName())) or ($sender->hasPermission("money.give"))) {
            if (!isset($args[0])) {
                $sender->sendMessage("§cMerci d'indiquer un joueur");
                return;
            }
            if (!is_numeric($args[1])) {
                $sender->sendMessage("§cMerci d'indiquer un montant");
                return;
            }

            $montant = (int)$args[1];

            if ($montant > 0) {
                $sender->sendMessage("§cMerci d'indiquer un montant");
            }

            MoneyAPI::addMoney($args[0], $montant);
            $sender->sendMessage("§aVous avez bien ajouté {$montant} à {$args[0]}");
        } else $sender->sendMessage("§cVous n'avez pas la permission");
    }
}