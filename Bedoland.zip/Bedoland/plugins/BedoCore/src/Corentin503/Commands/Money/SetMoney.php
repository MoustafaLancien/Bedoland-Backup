<?php

namespace Corentin503\Commands\Money;

use Corentin503\API\MoneyAPI;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class SetMoney extends Command
{
    public function __construct()
    {
        parent::__construct("setmoney", "Permet de définir de la money à un joueur", "/setmoney");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ((Server::getInstance()->isOp($sender->getName())) or ($sender->hasPermission("money.set"))) {
            if (!isset($args[0])) {
                $sender->sendMessage("§cMerci d'indiquer un joueur");
                return;
            }
            if (!is_numeric($args[1])) {
                $sender->sendMessage("§cMerci d'indiquer un montant");
                return;
            }

            $montant = (int)$args[1];

            if ($montant > 0) {
                $sender->sendMessage("§cMerci d'indiquer un montant");
            }

            MoneyAPI::setMoney($args[0], $montant);
            $sender->sendMessage("§aVous avez bien défini {$montant} à {$args[0]}");
        } else $sender->sendMessage("§cVous n'avez pas la permission");
    }
}