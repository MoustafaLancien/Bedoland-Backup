<?php

namespace Corentin503\Commands;



use Corentin503\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\inventory\Inventory;
use pocketmine\utils\TextFormat as TF;
use pocketmine\Server;

class StaffMode extends Command
{

    private $plugin;
    private $orgInv = [];
    private $helmet;
    private $chestplate;
    private $leggings;
    private $boots;   

   public function setOrgInv() : array {
   return $this->orgInv;
    }
    public function getOrgInv(array $orgInv) {
        $this->orgInv = $orgInv;
    }
    
    function __construct(Main $plugin){
        $this->plugin = $plugin;
        parent::__construct("staffmod", "§a»§f se mettre en staffmode", "/staffmod ou /sm", ["sm"]);
    }


    function execute(CommandSender $sender, string $commandLabel, array $args){
        if($sender instanceof Player){
            if ((Server::getInstance()->isOp($sender->getName())) or ($sender->hasPermission("staffmod.perm"))) {
                if(!in_array($sender->getName(), $this->plugin->staffMod)){

				   
                    $this->getOrgInv($sender->getInventory()->getContents());
                    $this->helmet = $sender->getArmorInventory()->getHelmet();
     			    $this->chestplate = $sender->getArmorInventory()->getChestplate();
    			    $this->leggings = $sender->getArmorInventory()->getLeggings();
   			        $this->boots = $sender->getArmorInventory()->getBoots();
                    $sender->getInventory()->clearAll();
                    $sender->getArmorInventory()->clearAll();

                    array_push($this->plugin->staffMod, $sender->getName());
                    

                    $item = ItemFactory::getInstance()->get(351, 10, 1);
                    $item->setCustomName(TF::BOLD . TF::GREEN . "Activer le Vanish");
                    $sender->getInventory()->addItem($item);

                    $item = ItemFactory::getInstance()->get(381, 0, 1);
                    $item->setCustomName(TF::BOLD . TF::GOLD . "TP Joueur Random");
                    $sender->getInventory()->addItem($item);

                    $item = ItemFactory::getInstance()->get(280);
                    $item->setCustomName(TF::BOLD . TF::AQUA . "Freeze\nTapez le joueur !");
                    $sender->getInventory()->addItem($item);

                    $item = ItemFactory::getInstance()->get(54);
                    $item->setCustomName(TF::BOLD . TF::DARK_PURPLE . "Voir l'inventaire\nTapez le joueur !");
                    $sender->getInventory()->addItem($item);

                    $item = ItemFactory::getInstance()->get(130);
                    $item->setCustomName(TF::BOLD . TF::BLACK . "Voir son EnderChest\nTapez le joueur !");
                    $sender->getInventory()->addItem($item);

                    $item = ItemFactory::getInstance()->get(339);
                    $item->setCustomName(TF::BOLD . TF::GOLD . "Gamemode 0");
                    $sender->getInventory()->addItem($item);

                    $item = ItemFactory::getInstance()->get(339);
                    $item->setCustomName(TF::BOLD . TF::GOLD . "Gamemode 1");
                    $sender->getInventory()->addItem($item);

                    $item = ItemFactory::getInstance()->get(339);
                    $item->setCustomName(TF::BOLD . TF::GOLD . "Gamemode 3");
                    $sender->getInventory()->addItem($item);

            }else{
                $sender->sendMessage(TF::RED . "Vous quittez le staffmod");
                $key = array_search($sender->getName(), $this->plugin->staffMod);
        	    unset($this->plugin->staffMod[$key]);  
                $sender->getInventory()->clearAll();
                $sender->getArmorInventory()->clearAll();     
                $sender->getInventory()->setContents($this->setOrgInv());    
                $sender->getArmorInventory()->setHelmet($this->helmet);
                $sender->getArmorInventory()->setChestplate($this->chestplate);
                $sender->getArmorInventory()->setLeggings($this->leggings);
                $sender->getArmorInventory()->setBoots($this->boots);     
            }
        }
    }
 }
}