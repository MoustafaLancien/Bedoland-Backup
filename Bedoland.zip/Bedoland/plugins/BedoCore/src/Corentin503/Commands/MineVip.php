<?php

namespace Corentin503\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\world\Position;
use pocketmine\player\Player;
use pocketmine\Server;

class MineVip extends Command
{

    public function __construct() {
        parent::__construct("minevip", "§a»§f Permet de se tp à la minevip !", "/minevip", ["minagevip"]);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {

        if($sender instanceof Player){
            if ((Server::getInstance()->isOp($sender->getName())) or ($sender->hasPermission("minevip.use"))) {
            Server::getInstance()->getWorldManager()->loadWorld("minage");
            $sender->teleport(new Position(170.3, 61, 178, $sender->getServer()->getWorldManager()->getWorldByName("minage"), 0, 0));
            $sender->sendMessage("§aVous avez bien été télporté au minage !");
        } else {
                $sender->sendMessage("§cVous n'avez pas la permission !");
            }
      }
    }
}