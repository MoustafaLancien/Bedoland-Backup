<?php

namespace Corentin503\Commands;

use Corentin503\Entitys\Box\BoxBedo;
use Corentin503\Entitys\Box\BoxEctasy;
use Corentin503\Entitys\Box\BoxLSD;
use Corentin503\Entitys\Box\BoxStick;
use Corentin503\Entitys\Box\BoxTag;
use Corentin503\Entitys\Box\BoxVote;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;

class BoxCommand extends Command
{
    public function __construct()
    {
        parent::__construct("box", "§a§l»§r§f Permet de faire spawn une box", "/box");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player) {
            if (Server::getInstance()->isOp($sender->getName())) {
                if ((empty($args[0])) or (is_null($args[0]))) {
                    $sender->sendMessage("§aMerci d'indiquer un argument");
                } else {
                    switch ($args[0]) {
                        case "ectasy":
                            $entity = new BoxEctasy($sender->getLocation());
                            $entity->spawnToAll();
                            break;
                        case "lsd":
                            $entity = new BoxLSD($sender->getLocation());
                            $entity->spawnToAll();
                            break;
                        case "stick":
                            $entity = new BoxStick($sender->getLocation());
                            $entity->spawnToAll();
                            break;
                        case "tag":
                            $entity = new BoxTag($sender->getLocation());
                            $entity->spawnToAll();
                            break;
                        case "vote":
                            $entity = new BoxVote($sender->getLocation());
                            $entity->spawnToAll();
                            break;
                        case "bedo":
                            $entity = new BoxBedo($sender->getLocation());
                            $entity->spawnToAll();
                            break;
                    }
                }
            }
        }
    }
}