<?php

namespace Corentin503\Commands;

use pocketmine\entity\Entity;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\player\Player;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\utils\TextFormat;


class Fly extends Command 
{
    public function __construct()
    {
        parent::__construct("fly", "§a§l»§r§f Permet de voler", "/fly");
    }
  #  public function onCommand(CommandSender $sender, Command $command, String $label, Array $args): bool 
    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
	{
			if(!$sender instanceof Player){
				$sender->sendMessage("§cUse this command in-game");
				return false;
			}
			if(!$sender->hasPermission("blazinfly.command")){
				$sender->sendMessage("§cYou do not have permission to use this command");
				return false;
			}
			if(empty($args[0])){
				if(!$sender->isCreative()){
					
					$sender->sendMessage($sender->getAllowFlight() === false ? "§l§aVol activé !" : "§l§cVol désactivé !");
					$sender->setAllowFlight($sender->getAllowFlight() === false ? true : false);
					if($sender->getAllowFlight() === false && $sender->isFlying()) $sender->setFlying(false);
				}else{
					$sender->sendMessage("§c You can only use this command in survival mode");
					return false;
				}
				return false;
			}
			if(!$sender->hasPermission("blazinfly.other")){
				$sender->sendMessage("§cYou do not have permission to enable flight for others");
				return false;
			}
			if($this->getServer()->getPlayerByPrefix($args[0])){
				$player = $this->getServer()->getPlayerByPrefix($args[0]);
				if(!$player->isCreative()){
					if($this->multiWorldCheck($player) === false) return false;
					$player->sendMessage($player->getAllowFlight() === false ? "§l§aVol activé !" : "§l§cVol désactivé !");
					$sender->sendMessage($player->getAllowFlight() === false ? "§aVous autorisé le fly à " . $player->getName() : "§cVous désactivé le fly à " . $player->getName());
					$player->setAllowFlight($player->getAllowFlight() === false ? true : false);
					if($sender->getAllowFlight() === false && $sender->isFlying()) $sender->setFlying(false);
				}else{
					$sender->sendMessage(" is in creative mode");
					return false;
				}
			}else{
				$sender->sendMessage("§cPlayer not found");
				return false;
			}
		return true;  
	}
  }
}    