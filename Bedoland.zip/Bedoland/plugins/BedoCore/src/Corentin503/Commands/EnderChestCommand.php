<?php

namespace Corentin503\Commands;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use muqsit\invmenu\type\InvMenuTypeIds;
use muqsit\invmenu\InvMenuHandler;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class EnderChestCommand extends Command
{
    public function __construct()
    {
        parent::__construct("enderchest", "Permet d'ouvrir son enderchest", "/enderchest", ["ec"]);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player) {
            if ($sender->hasPermission("cmd.ec")) {
                $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
                $menu->setName("EnderChest");
                $menu->getInventory()->setContents($sender->getEnderInventory()->getContents());
                $menu->setListener(function (InvMenuTransaction $transaction) use ($sender): InvMenuTransactionResult {
                    $sender->getEnderInventory()->setItem($transaction->getAction()->getSlot(), $transaction->getIn());
                    return $transaction->continue();
                });
                $menu->send($sender);
            }
        }
    }
}