<?php

namespace Corentin503\Commands;

use pocketmine\world\Position;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use TheStepKla\FormAPI\SimpleForm;
use onebone\economyapi\EconomyAPI;

class Event extends Command
{
    public function __construct()
    {
        parent::__construct("event", "§a§l»§r§f Permet de se tp à un event", "/event");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player) {
                $form = new SimpleForm(function (Player $player, int $data = null) {
                    if ($data === null) return;

                    switch ($data) {
                        case 0:
							$player->teleport(new Position(98, 147, -142, $player->getServer()->getWorldManager()->getWorldByName("bedoland")));
                            $player->sendMessage("§a> §fVous avez été téléporté à la purif");
                            break;
                        case 1:
							$player->teleport(new Position(-138, 145, -120, $player->getServer()->getWorldManager()->getWorldByName("bedoland")));
                            $player->sendMessage("§a> §fVous avez été téléporté au koth");
                            break;
                        case 2:
							$player->teleport(new Position(144, 143, 125, $player->getServer()->getWorldManager()->getWorldByName("bedoland")));
                            $player->sendMessage("§a> §fVous avez été téléporté au Totem");
                            break;
                        case 3:
							$player->teleport(new Position(43, 148, 159, $player->getServer()->getWorldManager()->getWorldByName("bedoland")));
                            $player->sendMessage("§a> §fVous avez été téléporté au Nexus");
                            break;    
                         case 4:
							$player->teleport(new Position(1340, 8, -45, $player->getServer()->getWorldManager()->getWorldByName("Arena")));
                            $player->sendMessage("§a> §fVous avez été téléporté au Boss");
                            break;       
                    }
                });
                $form->setTitle("§9[§fEVENT§9]§f");
                $form->setContent("§9Séléctionner §fun event §9!");
                $form->addButton("§aPurif");
                $form->addButton("§aKoth");
                $form->addButton("§aTotem");
           	    $form->addButton("§aNexus");
           	    $form->addButton("§aBoss");
                $sender->sendForm($form);
        }
    }
}