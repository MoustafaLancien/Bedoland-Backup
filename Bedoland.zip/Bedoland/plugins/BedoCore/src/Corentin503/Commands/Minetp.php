<?php

namespace Corentin503\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\world\Position;
use pocketmine\player\Player;
use pocketmine\Server;

class Minetp extends Command
{

    public function __construct() {
        parent::__construct("minetp", "§a»§f Permet de se tp à la mine !", "/minetp", ["minage"]);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {

        if($sender instanceof Player){
            Server::getInstance()->getWorldManager()->loadWorld("minage");
            $sender->teleport(new Position(144, 69, 200, $sender->getServer()->getWorldManager()->getWorldByName("minage"), 0, 0));
            $sender->sendMessage("§aVous avez bien été télporté au minage !");
        }

    }
}