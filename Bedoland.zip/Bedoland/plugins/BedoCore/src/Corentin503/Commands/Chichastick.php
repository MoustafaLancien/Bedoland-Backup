<?php

namespace Corentin503\Commands;

use Corentin503\Entitys\Chicha;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\ItemFactory;
use pocketmine\Server;

class Chichastick extends Command
{
    public function __construct()
    {
        parent::__construct("chichastick", "§a§l»§r§f Permet de se give la chica", "/chichastick");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player) {
            if (Server::getInstance()->isOp($sender->getName())) {
            $sender->getInventory()->addItem(ItemFactory::getInstance()->get(280, 0, 1)->setLore(["chicha"]));
            } else $sender->sendMessage("§cVous n'avez pas la permission !");   
        }
    }
}