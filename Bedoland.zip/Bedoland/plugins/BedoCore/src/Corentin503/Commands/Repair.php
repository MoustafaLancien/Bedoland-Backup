<?php

namespace Corentin503\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\Durable;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use pocketmine\Server;
use Corentin503\API\CooldownAPI;

class Repair extends Command
{
    public function __construct()
    {
        parent::__construct("repair", "§a»§f Permet de réparer vos items", "/repair");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if(!$sender instanceof Player){
            return true;
        }
                if ((Server::getInstance()->isOp($sender->getName())) or ($sender->hasPermission("repair.use"))) {
                    if (!isset(CooldownAPI::$cooldown_repair[$sender->getName()]) || CooldownAPI::$cooldown_repair[$sender->getName()] - time() <= 0) {
                    $index = $sender->getInventory()->getHeldItemIndex();
                    $item = $sender->getInventory()->getItem($index);
                    if ($item instanceof Durable) {
                        $sender->getInventory()->setItem($index, $item->setDamage(0));
                        $sender->sendMessage("§aL'item dans votre main a bien été réparé !");
                        CooldownAPI::$cooldown_repair[$sender->getName()] = time() + 3*60;
                    } else $sender->sendMessage("§cL'item n'est pas réparable !");
                    } else {
                $time = CooldownAPI::$cooldown_repair[$sender->getName()] - time();    
                $sender->sendMessage("§cVous devez encore attendre §6{$time} secondes§c !");
            }    
                } else $sender->sendMessage(TextFormat::RED."Tu n'as pas la permission de faire cela !");
        }
    }