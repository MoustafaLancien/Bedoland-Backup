<?php

namespace Corentin503\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\Armor;
use pocketmine\player\Player;
use pocketmine\Server;

class ProtectionDefaut extends Command
{
    public function __construct()
    {
        parent::__construct("protection", "Permet d'avoir la protection par défaut", "/protection");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (Server::getInstance()->isOp($sender->getName())) {
            if ($sender instanceof Player) {
                $item = $sender->getInventory()->getItemInHand();
                if ($item instanceof Armor) {
                    $sender->sendMessage("{$item->getCustomName()} à {$item->getDefensePoints()} de protection");
                }
            }
        }
    }
}