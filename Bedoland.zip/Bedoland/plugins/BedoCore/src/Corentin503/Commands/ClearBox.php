<?php

namespace Corentin503\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Location;
use pocketmine\player\Player;
use pocketmine\Server;
use Corentin503\Entitys\Box\BoxTag;
use Corentin503\Entitys\Box\BoxVote;
use Corentin503\Entitys\Box\BoxStick;
use Corentin503\Entitys\Box\BoxBedo;
use Corentin503\Entitys\Box\BoxEctasy;
use Corentin503\Entitys\Box\BoxLSD;

class ClearBox extends Command
{

    public function __construct() {
        parent::__construct("clearbox", "§a»§f Permet de clear les boxs");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {

        if($sender instanceof Player){
            if (Server::getInstance()->isOp($sender->getName())) {
        	if(count($args) < 1) {
            $sender->sendMessage(TextFormat::RED . "indiquez le nom de la box");
            return true;
        	}
                   switch($args[0]){
            		case "bedo":
            		  foreach (Server::getInstance()->getWorldManager()->getWorlds() as $worlds) {
                		foreach ($worlds->getEntities() as $entities) {
                    		if ($entities instanceof BoxBedo) { 
                        		$entities->flagForDespawn();
                    			}
                			}
           				 }
                   		break;
            			case "lsd":
                      foreach (Server::getInstance()->getWorldManager()->getWorlds() as $worlds) {
                		foreach ($worlds->getEntities() as $entities) {
                    		if ($entities instanceof BoxLSD) { 
                        		$entities->flagForDespawn();
                    			}
                			}
           				 }
                       break;
                       case "ecstasy":
                      foreach (Server::getInstance()->getWorldManager()->getWorlds() as $worlds) {
                		foreach ($worlds->getEntities() as $entities) {
                    		if ($entities instanceof BoxEctasy) { 
                        		$entities->flagForDespawn();
                    			}
                			}
           				 } 
                       break;
                       case "stick":
                      foreach (Server::getInstance()->getWorldManager()->getWorlds() as $worlds) {
                		foreach ($worlds->getEntities() as $entities) {
                    		if ($entities instanceof BoxStick) { 
                        		$entities->flagForDespawn();
                    			}
                			}
           				 }    
                       break;
                       case "vote":
                      foreach (Server::getInstance()->getWorldManager()->getWorlds() as $worlds) {
                		foreach ($worlds->getEntities() as $entities) {
                    		if ($entities instanceof BoxVote) { 
                        		$entities->flagForDespawn();
                    			}
                			}
           				 }    
                      break;
                       case "tag":
                      foreach (Server::getInstance()->getWorldManager()->getWorlds() as $worlds) {
                		foreach ($worlds->getEntities() as $entities) {
                    		if ($entities instanceof BoxTag) { 
                        		$entities->flagForDespawn();
                    			}
                			}
           				 }         
                           
           			 }
                   return true;
        		}
            return true;
   			 }
        return true;
 		}
	}  