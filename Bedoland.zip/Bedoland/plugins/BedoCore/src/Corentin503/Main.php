<?php

namespace Corentin503;

use Corentin503\Commands\GiveAll;
use DaPigGuy\PiggyFactions\PiggyFactions;
use DaPigGuy\PiggyFactions\utils\Roles;
use tedo0627\inventoryui\InventoryUI;
use Ayzrix\SimpleFaction\API\FactionsAPI;
use Corentin503\API\AtmAPI;
use Corentin503\API\MoneyAPI;
use Corentin503\Commands\AddPermission;
use Corentin503\Commands\AddRank;
use Corentin503\Commands\AtmCommand;
use Corentin503\Commands\BoxCommand;
use Corentin503\Commands\Chichaspawn;
use Corentin503\Commands\DuraDefaut;
use Corentin503\Commands\EnderChestCommand;
use Corentin503\Commands\Id;
use Corentin503\Commands\Event;
use Corentin503\Commands\Key;
use Corentin503\Commands\Keyall;
use Corentin503\Commands\ListRanks;
use Corentin503\Commands\Money\AddMoney;
use Corentin503\Commands\Money\MyMoney;
use Corentin503\Commands\Money\PayMoney;
use Corentin503\Commands\Money\RemoveMoney;
use Corentin503\Commands\Money\SetMoney;
use Corentin503\Commands\ProtectionDefaut;
use Corentin503\Commands\RemovePermission;
use Corentin503\Commands\RemoveRank;
use Corentin503\Commands\SetRank;
use Corentin503\Commands\Fly;
use Corentin503\Commands\Coffre;
use Corentin503\Commands\Spawn;
use Corentin503\Commands\Gamemode\gm0;
use Corentin503\Commands\Gamemode\gm1;
use Corentin503\Commands\Gamemode\gm3;
use Corentin503\Commands\Anvil;
use Corentin503\Commands\Repair;
use Corentin503\Commands\Repairall;
use Corentin503\Commands\Eshop;
use Corentin503\Commands\Nv;
use Corentin503\Commands\Presentation;
use Corentin503\Commands\Tags;
use Corentin503\Commands\Tpall;
use Corentin503\Commands\Minetp;
use Corentin503\Commands\MineVip;
use Corentin503\Commands\StaffMode;
use Corentin503\Commands\VanishCommand;
use Corentin503\Commands\ClearBox;
use Corentin503\Entitys\Boss;
use Corentin503\Entitys\Box\BoxBedo;
use Corentin503\Entitys\Box\BoxEctasy;
use Corentin503\Entitys\Box\BoxLSD;
use Corentin503\Entitys\Box\BoxStick;
use Corentin503\Entitys\Box\BoxTag;
use Corentin503\Entitys\Box\BoxVote;
use Corentin503\Entitys\Chicha;
use Corentin503\Events\EntityEvents;
use Corentin503\Events\PlayerEvents;
use Corentin503\Events\BlockEvents;
use Corentin503\Events\DuraLore;
use Corentin503\Events\CraftPermission;
use Corentin503\Events\StaffmodeEvents;
use Corentin503\Events\CpsEvent;
use Corentin503\Tasks\ClearLagTask;
use Corentin503\Tasks\PurificationTask;
use Corentin503\Tasks\DayTask;
use Corentin503\Tasks\BroadcastTask;
use Corentin503\Tasks\ShuffleWord;
use customiesdevs\customies\entity\CustomiesEntityFactory;
use Corentin503\Items\EnderPearl as EnderPearlItem;
use Corentin503\Items\ProjectileEnderPearl as EnderPearlProjectile;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\SingletonTrait;
use pocketmine\world\World;
use pocketmine\data\bedrock\EntityLegacyIds;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\item\ItemFactory;
use pocketmine\nbt\tag\CompoundTag;
use muqsit\invmenu\InvMenuHandler;

class Main extends PluginBase
{
    use SingletonTrait;
	
        /** @var string $word */
    public static $word = "";
    
    public static Config $rank_data;

    public static string $faction;

    public static Config $data;
    
    public $vanish = [];
    public $staffMod = [];
    public $freeze = [];

    protected function onEnable(): void
    {
        self::setInstance($this);

        $events = [new EntityEvents(), new PlayerEvents(), new DuraLore(), new BlockEvents(), new StaffModeEvents($this), new CraftPermission()];
        
        $commands = [new EnderChestCommand(), new Spawn(), new Id(), new BoxCommand(), new Fly(), new Key(), new AtmCommand(), new Chichaspawn(), new DuraDefaut(), new ProtectionDefaut(), new Anvil(), new Eshop(), new Nv(), new gm0(), new gm1(), new gm3(), new Tpall(), new Minetp(), new MineVip(), new StaffMode($this), new VanishCommand($this), new Tags(), new Repair(), new Repairall(), new Presentation(), new ClearBox(), new Keyall(), new Coffre(), new Event(), new GiveAll()];

        foreach ($events as $event) {
            $this->getServer()->getPluginManager()->registerEvents($event, $this);
        }

        $this->getServer()->getCommandMap()->registerAll("", $commands);
        
		InventoryUI::setup($this);
        

        
        Server::getInstance()->getWorldManager()->loadWorld("bedoland");
        Server::getInstance()->getWorldManager()->loadWorld("tuto");
        Server::getInstance()->getWorldManager()->loadWorld("minage");
        Server::getInstance()->getWorldManager()->loadWorld("Arena");
        
        CustomiesEntityFactory::getInstance()->registerEntity(Boss::class, "minecraft:boss");
        CustomiesEntityFactory::getInstance()->registerEntity(Chicha::class, "minecraft:chicha");
        CustomiesEntityFactory::getInstance()->registerEntity(BoxEctasy::class, "minecraft:boxectasy");
        CustomiesEntityFactory::getInstance()->registerEntity(BoxLSD::class, "minecraft:boxlsd");
        CustomiesEntityFactory::getInstance()->registerEntity(BoxStick::class, "minecraft:boxstick");
        CustomiesEntityFactory::getInstance()->registerEntity(BoxVote::class, "minecraft:boxvote");
        CustomiesEntityFactory::getInstance()->registerEntity(BoxTag::class, "minecraft:boxtag");
        CustomiesEntityFactory::getInstance()->registerEntity(BoxBedo::class, "minecraft:boxbedo");

        $this->getScheduler()->scheduleRepeatingTask(new PurificationTask(), 20);
        $this->getScheduler()->scheduleRepeatingTask(new ClearLagTask(), 20);
        $this->getScheduler()->scheduleRepeatingTask(new DayTask(), 100);
        $this->getScheduler()->scheduleRepeatingTask(new BroadcastTask(), 6000);
        $this->getScheduler()->scheduleRepeatingTask(new ShuffleWord(), 20*300);
        
        
        $this->saveDefaultConfig();
        
        $this->getServer()->getNetwork()->setName(" §r§2Bedo§aland ");
        
        AtmAPI::setDataFile();
        
        EntityFactory::getInstance()->register(EnderPearlProjectile::class, function(World $world, CompoundTag $nbt) : EnderPearlProjectile{
       return new EnderPearlProjectile(EntityDataHelper::parseLocation($nbt, $world), null, $nbt);
        }, ['ThrownEnderpearl', 'minecraft:ender_pearl'], EntityLegacyIds::ENDER_PEARL);


        $faction = $this->getConfigValue("faction_plugin");
        self::$faction = $faction;
        if ($this->getServer()->getPluginManager()->getPlugin($faction) === null) {
            
            self::$faction = "";
        }
        
        $this->saveResource($this->getDataFolder() . "money.yml");
        MoneyAPI::$data = new Config($this->getDataFolder() . "money.yml", Config::YAML);
    }


    public function getConfigValue(string $path, bool $nested = false): mixed
    {
        if ($nested) {
            return $this->getConfig()->getNested($path);
        } else return $this->getConfig()->get($path);
    }


    public function getPlayerName($player): string
    {
        if ($player instanceof Player) return $player->getName(); else return $player;
    }

    public function existPlayer($player): bool
    {
        return self::$data->exists($this->getPlayerName($player));
    }
    
        protected function onLoad(): void
    {
        ItemFactory::getInstance()->register(new EnderPearlItem(), true);
    }

    public function getFaction(Player $player): string
    {
        if (self::$faction === "SimpleFaction") {
            if (FactionsAPI::isInFaction($player->getName())) {
                return FactionsAPI::getFaction($player->getName());
            }
        } elseif (self::$faction === "PiggyFactions") {
            $member = Server::getInstance()->getPluginManager()->getPlugin("PiggyFactions")->getPlayerManager()->getPlayer($player);
            $faction = $member?->getFaction();
            if ($faction === null) return "";
            return $faction->getName();
        }
        return "";
    }
}   
