<?php 

namespace Corentin503\Events;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\item\Item;

class CraftPermission implements Listener{

  public function onCraft(CraftItemEvent $event){
    $player = $event->getPlayer();
    foreach ($event->getOutputs() as $item){
        if($item->getId() === 314){
            if(!$player->hasPermission("casquelsd")){
          		$event->cancel();
          		$player->sendMessage("§cVous n'avez pas débloqué ce craft");
        }
      } elseif ($item->getId() === 315){
            if(!$player->hasPermission("plastronlsd")){
          		$event->cancel();
          		$player->sendMessage("§cVous n'avez pas débloqué ce craft");
        }
      } elseif ($item->getId() === 316){
            if(!$player->hasPermission("jambiereslsd")){
          		$event->cancel();
          		$player->sendMessage("§cVous n'avez pas débloqué ce craft");
        }
      } elseif ($item->getId() === 317){
            if(!$player->hasPermission("botteslsd")){
          		$event->cancel();
          		$player->sendMessage("§cVous n'avez pas débloqué ce craft");
        }
      } elseif ($item->getId() === 283){
            if(!$player->hasPermission("epeelsd")){
          		$event->cancel();
          		$player->sendMessage("§cVous n'avez pas débloqué ce craft");
        }
      }   
    }
  }
}