<?php

namespace Corentin503\Events;

use Ayzrix\SimpleFaction\API\FactionsAPI;
use DaPigGuy\PiggyFactions\claims\ClaimsListener;
use DaPigGuy\PiggyFactions\claims\ClaimsManager;
use DaPigGuy\PiggyFactions\PiggyFactions;
use DaPigGuy\PiggyFactions\addons\hrkchat\TagManager;
use Corentin503\API\CooldownAPI;
use DaPigGuy\PiggyFactions\players\PlayerManager;
use onebone\economyapi\EconomyAPI;
use Corentin503\API\MoneyAPI;
use Corentin503\API\UtilsAPI;
use Corentin503\Forms\CrochetageForms;
use Corentin503\Forms\EnchantsForms;
use Corentin503\Forms\AnvilForms;
use Corentin503\Main;
use Corentin503\Tasks\AtmTask;
use Corentin503\Events\MyEffectInstance;
use pocketmine\block\WallSign;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerExhaustEvent;
use pocketmine\block\BlockLegacyIds;
use pocketmine\entity\Location;
use pocketmine\world\Position;
use pocketmine\block\Door;
use pocketmine\block\FenceGate;
use pocketmine\block\Trapdoor;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\item\VanillaItems;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\player\PlayerJumpEvent;
use pocketmine\event\player\PlayerToggleSneakEvent;
use pocketmine\item\ItemIds;
use pocketmine\item\ItemFactory;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\Server;
use Corentin503\Entitys\Chicha;
use pocketmine\world\format\Chunk;
use pocketmine\world\sound\BlazeShootSound;
use pocketmine\world\sound\ItemBreakSound;
use Corentin503\API\ElevatorAPI;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;

class PlayerEvents implements Listener
{
    private static array $near;

    public function onChat(PlayerChatEvent $event)
    {
        $player = $event->getPlayer();
        $message = $event->getMessage();

        if (Main::$word !== "") {
            if ($message === Main::$word) {
                $broadcast = Main::getInstance()->getConfig()->get("broadcast_win");
                $broadcast = str_replace(["{player}", "{word}"], [$player->getName(), Main::$word], $broadcast);
                Server::getInstance()->broadcastMessage($broadcast);
                $money = "15";
                EconomyAPI::getInstance()->addMoney($player, $money);

                Main::$word = "";
            }
        }
        if (!isset(CooldownAPI::$cooldown_chat[$player->getName()]) || CooldownAPI::$cooldown_chat[$player->getName()] - time() <= 0){
            CooldownAPI::$cooldown_chat[$player->getName()] = time() + 4;
            $name = $event->getPlayer()->getName();
        } else {
            if (!Server::getInstance()->isOp($player->getName())) {
                $event->cancel();
                $time = CooldownAPI::$cooldown_chat[$player->getName()] - time();
                $player->sendMessage("§cVous devez encore attendre {$time} secondes !");
            }
        }
    }

    public function onJoin(PlayerJoinEvent $event)
    {
        $name = $event->getPlayer()->getName();
        $player = $event->getPlayer();
        $event->setJoinMessage("");
        Server::getInstance()->broadcastMessage("§f[§a+§f] {$name}");
        Server::getInstance()->getWorldManager()->loadWorld("tuto");

        if (!$event->getPlayer()->hasPlayedBefore()) {
            EconomyAPI::getInstance()->setMoney($event->getPlayer(), 0);
            $player->teleport(new Location(652, 137, 225, $player->getServer()->getWorldManager()->getWorldByName("tuto"), 0, 0));
        } else { $player->teleport(new Location(0, 153, 0, $player->getServer()->getWorldManager()->getWorldByName("bedoland"), 0, 0));
        }

        $player->getEffects()->remove(VanillaEffects::LEVITATION());

        Main::getInstance()->getScheduler()->scheduleRepeatingTask(new AtmTask($event->getPlayer(), 1), 20 * 60);
    }

    public function onQuit(PlayerQuitEvent $event)
    {
        $player = $event->getPlayer();
        $name = $event->getPlayer()->getName();

        $player->getEffects()->clear();
        $event->setQuitMessage("");
        Server::getInstance()->broadcastMessage("§f[§c-§f] {$name}");

    }

    public function onUse(PlayerItemUseEvent $event)
    {
        $player = $event->getPlayer();
        $item = $event->getItem();


        if (in_array($player->getName(), UtilsAPI::$players_chicha_itemcancel)) $event->cancel();


        if ($player->getInventory()->getItemInHand()->getId() === VanillaItems::COMPASS()->getId()) {
            $boundingBox = $player->getBoundingBox();
            $count = 0;
            $playerMessage = "";
            $pos = $player->getPosition();
            $time = time() + 60;
            if (!isset(self::$near[$player->getName()]) or self::$near[$player->getName()] - time() <= 0) {
                foreach ($player->getWorld()->getNearbyEntities($boundingBox->expandedCopy(100, 100, 100), $player) as $entity) {
                    if ($entity instanceof Player) {
                        $count++;
                        $playerMessage .= "\n" . "§9" . $entity->getName() . " --> " . "§9" . (int)($pos->distance($entity->getPosition())) . " block(s)§f.";
                    }
                }
                if ($count === 0) {
                    $player->sendMessage("[§9!!!§f] §fIl n'y a aucun joueurs autour dans un rayon de 100 blocks !");
                    return;
                }
                $player->sendMessage("Il y a {$count} joueur(s) autour de vous !");
                $player->sendPopup($playerMessage);
                self::$near[$player->getName()] = $time;
            } else {
                $timer = intval(self::$near[$player->getName()] - time());
                $minutes = intval(abs($timer / 60));
                $secondes = intval(abs($timer - $minutes * 60));
                if ($minutes > 0) {
                    $TempRestant = "§9{$minutes} minute(s)";
                } else {
                    $TempRestant = "§9{$secondes} seconde(s)";
                }
                $player->sendTip("[§9!!!§f] §6Vous devez attendre {$TempRestant} §f");
                $pos = $player->getPosition();
                $player->getNetworkSession()->sendDataPacket(PlaySoundPacket::create(
                    "note.bass",
                    $pos->x, $pos->y, $pos->z,
                    1.0, 1.0
                ));
            }
        }
        elseif ($item->getId() === ItemIds::BLAZE_POWDER) { //BUMP
            if (!isset(CooldownAPI::$cooldown_bump[$player->getName()]) || CooldownAPI::$cooldown_bump[$player->getName()] - time() <= 0) {
                CooldownAPI::$cooldown_bump[$player->getName()] = time() + 3;
                $direction = $player->getDirectionPlane()->normalize()->multiply(4);
                $player->setMotion(new Vector3($direction->getX(), 1, $direction->getY()));
                $player->getInventory()->removeItem(ItemFactory::getInstance()->get(377, 0, 1));
                $world= $player->getWorld();
                $world->addSound($player->getPosition(), new BlazeShootSound(), [$player]);
                $player->sendPopup("§a- §fPlume de saut utilisé §a-");
            } else {
                $time = CooldownAPI::$cooldown_bump[$player->getName()] - time();
                $player->sendPopup("§cVous devez encore attendre {$time} secondes !");
            }
        } elseif (($item->getId() === ItemIds::WOODEN_SWORD) or ($item->getId() === 267)) { //DASH BEDO & KETA
            if (!isset(CooldownAPI::$cooldown_dash[$player->getName()]) || CooldownAPI::$cooldown_dash[$player->getName()] - time() <= 0){
                CooldownAPI::$cooldown_dash[$player->getName()] = time() + 60;
                $motion = $player->getDirectionVector()->multiply(3.6);
                $motion->y = 0.6;
                $player->setMotion($motion);
            } else {
                $time = CooldownAPI::$cooldown_dash[$player->getName()] - time();
                $player->sendPopup("§cVous devez encore attendre {$time} secondes !");
            }
        } elseif ($item->getId() === 405) { //Stick regen
            if (!isset(CooldownAPI::$cooldown_regeneration[$player->getName()]) || CooldownAPI::$cooldown_regeneration[$player->getName()] - time() <= 0) {
                CooldownAPI::$cooldown_regeneration[$player->getName()] = time() + 60;
                $eff = new EffectInstance(VanillaEffects::REGENERATION(), 10*20, 2);
                $player->getEffects()->add($eff);
                $player->sendPopup("§a- §fStick de régènération utilisé §a-");
            } else {
                $time = CooldownAPI::$cooldown_regeneration[$player->getName()] - time();
                $player->sendPopup("§cVous devez encore attendre {$time} secondes !");
            }
        } elseif ($item->getId() === 336) { //Stick jump
            if (!isset(CooldownAPI::$cooldown_jump[$player->getName()]) || CooldownAPI::$cooldown_jump[$player->getName()] - time() <= 0) {
                CooldownAPI::$cooldown_jump[$player->getName()] = time() + 60;
                $eff = new EffectInstance(VanillaEffects::JUMP_BOOST(), 10*20, 1);
                $player->getEffects()->add($eff);
                $player->sendPopup("§a- §fStick de jump utilisé §a-");
            } else {
                $time = CooldownAPI::$cooldown_jump[$player->getName()] - time();
                $player->sendPopup("§cVous devez encore attendre {$time} secondes !");
            }
        } elseif ($item->getId() === 370) { //Stick bedo
            if (!isset(CooldownAPI::$cooldown_bedo[$player->getName()]) || CooldownAPI::$cooldown_bedo[$player->getName()] - time() <= 0) {
                CooldownAPI::$cooldown_bedo[$player->getName()] = time() + 180;
                $eff = [new EffectInstance(VanillaEffects::JUMP_BOOST(), 10*20, 1), new EffectInstance(VanillaEffects::REGENERATION(), 10*20, 0), new EffectInstance(VanillaEffects::SPEED(), 10*20, 1), new EffectInstance(VanillaEffects::STRENGTH(), 10*20, 1)];

                foreach ($eff as $effs) {
                    $player->getEffects()->add($effs);
                }
                $player->sendPopup("§a- §fStick bedo utilisé §a-");
            } else {
                $time = CooldownAPI::$cooldown_bedo[$player->getName()] - time();
                $player->sendPopup("§cVous devez encore attendre {$time} secondes !");
            }
        } elseif ($item->getId() === 369) { //Stick force
            if (!isset(CooldownAPI::$cooldown_force[$player->getName()]) || CooldownAPI::$cooldown_force[$player->getName()] - time() <= 0) {
                CooldownAPI::$cooldown_force[$player->getName()] = time() + 60;
                $eff = new EffectInstance(VanillaEffects::STRENGTH(), 10*20, 1);
                $player->getEffects()->add($eff);
                $player->sendPopup("§a- §fStick de force utilisé §a-");
            } else {
                $time = CooldownAPI::$cooldown_force[$player->getName()] - time();
                $player->sendPopup("§cVous devez encore attendre {$time} secondes !");
            }
        } elseif ($item->getId() === 353) { //Stick Speed
            if (!isset(CooldownAPI::$cooldown_speed[$player->getName()]) || CooldownAPI::$cooldown_speed[$player->getName()] - time() <= 0) {
                CooldownAPI::$cooldown_speed[$player->getName()] = time() + 60;
                $eff = new EffectInstance(VanillaEffects::SPEED(), 10*20, 1);
                $player->getEffects()->add($eff);
                $player->sendPopup("§a- §fStick de speed utilisé §a-");
            }else {
                $time = CooldownAPI::$cooldown_speed[$player->getName()] - time();
                $player->sendPopup("§cVous devez encore attendre {$time} secondes !");
            }
        } elseif ($item->getId() === 368) { //perle cooldwon
            if (!isset(CooldownAPI::$cooldown_perle[$player->getName()]) || CooldownAPI::$cooldown_perle[$player->getName()] - time() <= 0) {
                CooldownAPI::$cooldown_perle[$player->getName()] = time() + 20;
            } else {
                $event->cancel();
                $time = CooldownAPI::$cooldown_perle[$player->getName()] - time();
                $player->sendPopup("§cVous devez encore attendre {$time} secondes !");
            }
        } elseif ($item->getId() === 288) { //Redbull
            $eff = new EffectInstance(VanillaEffects::HASTE(), 30*20, 1);
            $player->getEffects()->add($eff);
            $player->getInventory()->removeItem(ItemFactory::getInstance()->get(288, 0, 1));
        } elseif ($item->getId() === 351) { #soupe
            if ($player->getHealth() < $player->getMaxHealth()) {
                $heal = $player->getMaxHealth() - $player->getHealth();
                $heal = (int)$heal;
                $removed = $heal / 4;
                if ($removed < 1) $removed = 1;
                $player->setHealth($player->getMaxHealth());
                $player->sendPopup("§a( §d+ {$heal} §a)");
                $player->getInventory()->removeItem(ItemFactory::getInstance()->get(351, 0, $removed));
            }
        } elseif ($item->getId() === 360) {
            if (!isset(CooldownAPI::$cooldown_joint[$player->getName()]) || CooldownAPI::$cooldown_joint[$player->getName()] - time() <= 0) {
                $player->getHungerManager()->setFood(19.9);
            }else{
                $event->cancel();
                $time = CooldownAPI::$cooldown_joint[$player->getName()] - time();
                $player->sendPopup("§cVous devez encore attendre {$time} secondes !");
            }
        }
    }

    public function onItemConsumed(PlayerItemConsumeEvent $event){
        $player = $event->getPlayer();
        $item = $event->getItem();
        if ($item->getId() === 353) { //VerredeLean
            if (!isset(CooldownAPI::$cooldown_lean[$player->getName()]) || CooldownAPI::$cooldown_lean[$player->getName()] - time() <= 0) {
                CooldownAPI::$cooldown_lean[$player->getName()] = time() + 40;
                $nausea = new EffectInstance(VanillaEffects::NAUSEA(), 10*20, 1);
                $levitation = new EffectInstance(VanillaEffects::LEVITATION(), 10*20, 1);
                $player->getEffects()->add($nausea);
                $player->getEffects()->add($levitation);
                $player->sendPopup("§a- §fVerre de lean utilisé §a-");
            } else {
                $event->cancel();
                $time = CooldownAPI::$cooldown_lean[$player->getName()] - time();
                $player->sendPopup("§cVous devez encore attendre {$time} secondes !");
            }
        }   elseif ($item->getId() === 360) { //joint
            if (!isset(CooldownAPI::$cooldown_joint[$player->getName()]) || CooldownAPI::$cooldown_joint[$player->getName()] - time() <= 0) {
                CooldownAPI::$cooldown_joint[$player->getName()] = time() + 25;
                $nausea = new EffectInstance(VanillaEffects::NAUSEA(), 10*20, 1);
                $force = new EffectInstance(VanillaEffects::STRENGTH(), 10*20, 1);
                $player->getEffects()->add($nausea);
                $player->getEffects()->add($force);
                $player->sendPopup("§a- §fJoint utilisé §a-");
            } else {
                $event->cancel();
                $time = CooldownAPI::$cooldown_joint[$player->getName()] - time();
                $player->sendPopup("§cVous devez encore attendre {$time} secondes !");
            }
        }
    }

    public function onmove(PlayerMoveEvent $event){
        $player = $event->getPlayer();
        $level = $player->getWorld();
        $inventory = $player->getInventory();
        if($inventory->contains(ItemFactory::getInstance()->get(351, 0, 65))) {
            $player->getInventory()->removeItem(ItemFactory::getInstance()->get(351, 0, 2500));
            $player->getInventory()->addItem(ItemFactory::getInstance()->get(351, 0, 64));
            $player->sendMessage("§a>> §fVous êtes autorisé qu'à un seul stack de soup !");
        }
        if ($player->getWorld()->getFolderName() === "minage") {
            if ($level->getBlock($player->getPosition()->subtract(0, 1, 0))->getId() == 173 ){
                $player->teleport(new Location(0, 153, 0, $player->getServer()->getWorldManager()->getWorldByName("bedoland"), 0, 0));
            }
            else if ($level->getBlock($player->getPosition()->subtract(0, 1, 0))->getId() == 112 or $level->getBlock($player->getPosition()->subtract(0, 1, 0))->getId() == 87 ){
                if ((Server::getInstance()->isOp($player->getName())) or ($player->hasPermission("minevip.use"))) {
                    $a = "b";
                } else {
                    $player->teleport(new Position(170.3, 61, 178, $player->getServer()->getWorldManager()->getWorldByName("minage")));
                    $player->sendMessage("§cVous n'avez pas la permission d'entrer en minevip !");
                }
            }
        } else if ($player->getWorld()->getFolderName() === "tuto" ){
            if ($level->getBlock($player->getPosition()->subtract(0,1,0))->getId() == 49){
                $player->teleport(new Location(0, 153, 0, $player->getServer()->getWorldManager()->getWorldByName("bedoland"), 0, 0));
            }
        }
    }

    public function onHunger(PlayerExhaustEvent $ev){
        $ev->cancel();
    }

    public function AscenseurJump(PlayerJumpEvent $event): bool {
        $player = $event->getPlayer();
        $level = $player->getWorld();

        if ($level->getBlock($player->getPosition()->subtract(0, 1, 0))->getId() !== 152 ) return false;
        $x = (int)floor($player->getPosition()->getX());
        $y = (int)floor($player->getPosition()->getY());
        $z = (int)floor($player->getPosition()->getZ());
        $elevator = $level->getBlockAt($x, $y, $z);
        $maxY = 255;
        $found = false;
        $y++;
        for (; $y <= $maxY; $y++) {
            if ($found = (ElevatorAPI::isElevatorBlock($x, $y, $z, $level) !== null)) {
                break;
            }
        }
        if ($found) {
            if ($player->getPosition()->distance(new Vector3($x + 0.5, $y + 1, $z + 0.5)) <= 50) {
                $player->teleport(new Vector3($x + 0.5, $y + 1, $z + 0.5));
            } else $player->sendMessage("§6[§fBedoElevator§6] §cUn ascenseur a été trouvé, mais il est trop loin");
        } else $player->sendMessage("§6[§fBedoElevator§6] §cAucun ascenseur n'a été trouvé");
        return true;
    }

    public function PlayerToggleSneak(PlayerToggleSneakEvent $event): bool{
        $player = $event->getPlayer();
        $level = $player->getWorld();
        if (!$event->isSneaking()) return false;
        if ($level->getBlock($player->getPosition()->subtract(0, 1, 0))->getId() !== 152 ) return false;
        $x = (int)floor($player->getPosition()->getX());
        $y = (int)floor($player->getPosition()->getY()) - 2;
        $z = (int)floor($player->getPosition()->getZ());
        $found = false;
        $y--;
        for (; $y >= 0; $y--) {
            if ($found = (ElevatorAPI::isElevatorBlock($x, $y, $z, $level) !== null)) {
                break;
            }
        }
        if ($found) {
            if ($player->getPosition()->distance(new Vector3($x + 0.5, $y + 1, $z + 0.5)) <= 50) {
                $player->teleport(new Vector3($x + 0.5, $y + 1, $z + 0.5));
            } else $player->sendMessage("§6[§fBedoElevator§6] §cUn ascenseur a été trouvé, mais il est trop loin");
        } else $player->sendMessage("§6[§fBedoElevator§6] §cAucun ascenseur n'a été trouvé");
        return true;
    }

    public function itemHeld(PlayerItemHeldEvent $event)
    {
        $player = $event->getPlayer();
        $item = $event->getItem();
        $playereffect = $player->getEffects();
        if ($item->getId() === ItemIds::SLIMEBALL) {
            $levitation = new MyEffectInstance(VanillaEffects::LEVITATION(), 100 * 99999, -3, false);
            $player->getEffects()->add($levitation);
        } else{
            $player->getEffects()->remove(VanillaEffects::LEVITATION());
        }
    }


    public function onInteract(PlayerInteractEvent $event)
    {
        $item = $event->getItem();
        $player = $event->getPlayer();
        $block = $event->getBlock();

        if ($item->getId() === 280 and $item->getLore() === ["chicha"]) {
            if (ClaimsManager::getInstance()->getClaimByPosition($player->getPosition()->asPosition())->getFaction()->getName() === PlayerManager::getInstance()->getPlayerByName($player->getName())->getFaction()->getName()) {
                $chicha = new Chicha($player->getLocation());
                $chicha->spawnToAll();
                $player->getInventory()->removeItem(ItemFactory::getInstance()->get(280, 0, 1));
            } else $player->sendMessage("§cVous pouvez poser la chicha seulement dans votre claim");
            return;
        }

        if ($item->getId() === 351) { #soupe
            if ($player->getHealth() < $player->getMaxHealth()) {
                $heal = $player->getMaxHealth() - $player->getHealth();
                $heal = (int)$heal;
                $removed = $heal / 4;
                if ($removed < 1) $removed = 1;
                $player->setHealth($player->getMaxHealth());
                $player->sendPopup("§a( §d+ {$heal} §a)");
                $player->getInventory()->removeItem(ItemFactory::getInstance()->get(351, 0, $removed));
            }
        }

        if ($block instanceof WallSign) {
            if ($block->getText()->getLine(0) == "[ATM]") {
                Server::getInstance()->dispatchCommand($player, "atm");
            }
            return;
        }

        if ($item->getId() === ItemIds::WOODEN_HOE) {

            $index = $player->getInventory()->getHeldItemIndex();
            $item = $player->getInventory()->getItem($index);

            if ($player->getInventory()->getItemInHand()->getDamage() > 10 ){
                $player->getInventory()->setItem($index, $item->setDamage(0));
            }



            if ($item->getDamage() == 10){
                $player->getInventory()->removeItem(ItemFactory::getInstance()->get(290, 10, 1));
                $world= $player->getWorld();
                $world->addSound($player->getPosition(), new ItemBreakSound(), [$player]);
                $player->sendMessage("§6> §7Vous avez cassé votre kit de crochetage !");
            } elseif (($block instanceof Door) or ($block instanceof Trapdoor) or ($block instanceof FenceGate)) {
                CrochetageForms::test1($player, $block);
                return;
            }
        }


        if ($block->getId() === BlockLegacyIds::ENCHANTING_TABLE) {
            $event->cancel();
            EnchantsForms::formP($player);
            return;
        }
        if ($block->getId() === BlockLegacyIds::ANVIL) {
            $event->cancel();
            AnvilForms::openForm($player);
            return;
        }
    }

    public function commandProcess(PlayerCommandPreprocessEvent $event)
    {
        $message = $event->getMessage();
        $msg = explode(' ', trim($message));
        $m = substr("$message", 0, 1);
        $whitespace_check = substr($message, 1, 1);
        $slash_check = substr($msg[0], -1, 1);
        $quote_mark_check = substr($message, 1, 1) . substr($message, -1, 1);
        if ($m == '/') {
            if ($whitespace_check === ' ' or $whitespace_check === '\\' or $slash_check === '\\' or $quote_mark_check === '""') {
                $event->cancel();
            }
        }

    }

    public function onDeath(PlayerDeathEvent $event)
    {
        $player = $event->getPlayer();
        $damage = $player->getLastDamageCause();

        if ($damage instanceof EntityDamageByEntityEvent) {
            $damager = $damage->getDamager();

            if ($damager instanceof Player) {
                EconomyAPI::getInstance()->addMoney($damager, 10);
                $damager->sendPopup("+ 10 ");
            }
        }
    }
}