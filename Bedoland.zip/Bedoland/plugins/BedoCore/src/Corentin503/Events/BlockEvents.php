<?php

namespace Corentin503\Events;

use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\Listener;
use pocketmine\item\ItemFactory;
use pocketmine\block\VanillaBlocks;
use pocketmine\block\BlockLegacyIds;
use pocketmine\block\BlockFactory;
use pocketmine\block\Bedrock;
use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\item\ItemIds;
use pocketmine\item\StringToItemParser;
use Corentin503\Main;
use pocketmine\world\Position;
use pocketmine\Server;
use pocketmine\scheduler\ClosureTask;

class BlockEvents implements Listener
{
    private $Wg;
    
    public function onBreak(BlockBreakEvent $event)
    {
        $block = $event->getBlock();
        $player = $event->getPlayer();
        $item = $event->getItem();
        
        ####### ----- SYTEME AUTOSMELT	------ #####
        
		$ores = [
                        ItemIds::COAL_ORE => StringToItemParser::getInstance()->parse("coal"),
                        ItemIds::IRON_ORE => StringToItemParser::getInstance()->parse("iron_ingot"),
                        ItemIds::GOLD_ORE => StringToItemParser::getInstance()->parse("gold_ingot"),
                        ItemIds::REDSTONE_ORE => StringToItemParser::getInstance()->parse("redstone"),
                        ItemIds::LIT_REDSTONE_ORE => StringToItemParser::getInstance()->parse("redstone"),
                        ItemIds::DIAMOND_ORE => StringToItemParser::getInstance()->parse("diamond"),
                        ItemIds::EMERALD_ORE => StringToItemParser::getInstance()->parse("emerald"),
                        ItemIds::QUARTZ_ORE => StringToItemParser::getInstance()->parse("quartz")
                  ];
                        $event->setDrops(array_map(function ($item) use ($ores) {
                        return in_array($item->getId(), array_keys($ores)) ? $ores[$item->getId()] : $item;
                        }, $event->getDrops()));
        

        ####### ----- SYTEME RANDOM ORE	------ #####
        
        
        if ($player->getWorld()->getFolderName() === "minage") {
            if ($block->getId() === 21 and $block->getMeta() === 0 ) {
                $event->setDrops([ItemFactory::getInstance()->get(0, 0, 1)]); 
                $random = mt_rand(1, 1000); // Génère un nombre aléatoire entre 1 et 100
                if ($random <= 180) { // 18% de chance de drop de redstone
                    $player->sendPopup("§4Redstone");
                    $event->setDrops([ItemFactory::getInstance()->get(331, 0, 4)]);
                } elseif ($random <= 360) { // 18% de chance de drop de charbon
                    $player->sendPopup("§0Charbon");
                    $event->setDrops([ItemFactory::getInstance()->get(263, 0, 1)]);                        
                } elseif ($random <= 510) { // 15% de chance de drop de fer
                    $player->sendPopup("§fFer");
                    $event->setDrops([ItemFactory::getInstance()->get(265, 0, 1)]);     
                } elseif ($random <= 660) { // 15% de chance de drop d'or
                    $player->sendPopup("§eOr");
                    $event->setDrops([ItemFactory::getInstance()->get(266, 0, 1)]);     
                } elseif ($random <= 770) { // 11% de chance de drop d'émeraude
                    $player->sendPopup("§aEmeraude");
                    $event->setDrops([ItemFactory::getInstance()->get(388, 0, 1)]);     
                } elseif ($random <= 880) { // 11% de chance de drop d'ecstasy
                    $player->sendPopup("§5Ecstasy");
                    $event->setDrops([ItemFactory::getInstance()->get(351, 11, 1)]);     
                } elseif ($random <= 960) { // 8% de chance de drop de keta
                    $player->sendPopup("§cPoudre de Kétamine");
                    $event->setDrops([ItemFactory::getInstance()->get(351, 17, 1)]);     
                } else { // 4% de chance de drop de lsd
                    $player->sendPopup("§ePoudre de LSD");
                    $event->setDrops([ItemFactory::getInstance()->get(351, 12, 1)]);         
                }
            }
            
            ####### ----- SYTEME DE RESET DES MINERAIS	------ #####
            if ($block->getId() === 14 or $block->getId() === 15 or $block->getId() === 16 or $block->getId() === 21 or $block->getId() === 74 or $block->getId() === 129 or $block->getId() === 56){
                
				Main::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(
                function() use ($block){
                      
                $posX = $block->getPosition()->getX();
                $posY = $block->getPosition()->getY();
                $posZ = $block->getPosition()->getZ();
                $bedrock = BlockFactory::getInstance()->get(7, 0);
                $block->getPosition()->getWorld()->setBlockAt($posX, $posY, $posZ ,$bedrock);
                	}
               	), 1);        
                Main::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(
                function() use ($event){
                $block = $event->getBlock();
        		$player = $event->getPlayer();      
                $posX = $block->getPosition()->getX();
                $posY = $block->getPosition()->getY();
                $posZ = $block->getPosition()->getZ();
                $test = $block->getPosition()->getWorld()->getBlockAt($posX, $posY, $posZ);  
                $idd = $test->getId();     
                if ($idd === 7){ ## si il y a tjrs de la bedrock 
                if ($player->hasPermission("minevip.use")){    
                $rdm = mt_rand(1, 90); 
                } else $rdm = mt_rand(1, 75);    
                if ($rdm <= 10) {    
                $id = BlockFactory::getInstance()->get(14, 0);    
                $block->getPosition()->getWorld()->setBlockAt($posX, $posY, $posZ ,$id);   
                } elseif ($rdm <= 20) {
                $id = BlockFactory::getInstance()->get(15, 0);    
                $block->getPosition()->getWorld()->setBlockAt($posX, $posY, $posZ ,$id);   
                } elseif ($rdm <= 30) {
                $id = BlockFactory::getInstance()->get(16, 0);    
                $block->getPosition()->getWorld()->setBlockAt($posX, $posY, $posZ ,$id);  
                } elseif ($rdm <= 40) {
                $id = BlockFactory::getInstance()->get(129, 0);    
                $block->getPosition()->getWorld()->setBlockAt($posX, $posY, $posZ ,$id); 
                }  elseif ($rdm <= 50) {
                $id = BlockFactory::getInstance()->get(73, 0);    
                $block->getPosition()->getWorld()->setBlockAt($posX, $posY, $posZ ,$id); 
                }  elseif ($rdm <= 60) {
                $id = BlockFactory::getInstance()->get(56, 0);    
                $block->getPosition()->getWorld()->setBlockAt($posX, $posY, $posZ ,$id);    
                } else {
                $id = BlockFactory::getInstance()->get(21, 0);    
                $block->getPosition()->getWorld()->setBlockAt($posX, $posY, $posZ ,$id);     
                		}
               		}
                }    
              ), 20 * 15);      
            }
        }
    }
    
    public function onPlayerInteract (PlayerInteractEvent $event): void{
        $player = $event->getPlayer ();
        $block = $event->getBlock ();
            if ($block->getId () === 199) {
                if (!Server::getInstance()->isOp($player->getName())) {
                    $event->cancel();
                    $player->sendMessage("§cTu ne peux pas prendre l'item petit voleur x)");
                }
            }
        }   
}