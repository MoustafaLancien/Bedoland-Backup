<?php

namespace Corentin503\Events;


use pocketmine\event\Listener;
use Corentin503\Main;
use pocketmine\player\Player;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\Server;
use pocketmine\inventory\Inventory;
use pocketmine\world\Position;
use pocketmine\utils\TextFormat as TF;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\player\GameMode;
use pocketmine\event\player\PlayerItemUseEvent;

class StaffModeEvents implements Listener{

    private $plugin;

    public function __construct(Main $plugin){
        $this->plugin = $plugin;
    }

    public function onJoin(PlayerJoinEvent $event): void{
        $player = $event->getPlayer();
        $this->plugin->vanish[$player->getName()] = false;
        if(in_array($player->getName(), $this->plugin->freeze)){
        	$player->setImmobile(true);
        	$player->sendMessage(TF::AQUA . "Vous avez été freeze par un staff pour être débloquer, contactez le staff sur discord !");
        }
    }

    public function onQuit(PlayerQuitEvent $event): void{
        $player = $event->getPlayer();
        $this->plugin->vanish[$player->getName()] = false;
   	 	if(in_array($event->getPlayer()->getName(), $this->plugin->staffMod)){
        	$key = array_search($player->getName(), $this->plugin->staffMod);
        	unset($this->plugin->staffMod[$key]);
   	 		$player->getInventory()->clearAll();
   	 	}        
    }

#    public function onInteract(PlayerInteractEvent $event): void{
    public function onuseiho(PlayerItemUseEvent $event){    
        $item = $event->getItem();
        $player = $event->getPlayer();
    	if($item->getCustomName() == TF::BOLD . TF::GREEN . "Activer le Vanish"){
                $this->plugin->getServer()->dispatchCommand($player, "vanishstaffmod");
                $player->getInventory()->remove(ItemFactory::getInstance()->get(351, 10, 1));
                $newitem = ItemFactory::getInstance()->get(351, 13, 1);
                $newitem->setCustomName(TF::BOLD . TF::RED . "Désactiver le Vanish");
                $player->getInventory()->addItem($newitem);
        }

        if($item->getCustomName() == TF::BOLD . TF::RED . "Désactiver le Vanish"){
                $this->plugin->getServer()->dispatchCommand($player, "vanishstaffmod");
                $player->getInventory()->remove(ItemFactory::getInstance()->get(351, 13, 1));
                $newitem2 = ItemFactory::getInstance()->get(351, 10, 1);
                $newitem2->setCustomName(TF::BOLD . TF::GREEN . "Activer le Vanish");
                $player->getInventory()->addItem($newitem2);
        }


        if($item->getCustomName() == TF::BOLD . TF::GOLD . "TP Joueur Random"){
        	$allonlinePlayer = $this->plugin->getServer()->getOnlinePlayers();

            	$playerTP = array_rand($allonlinePlayer);
            	$x = $allonlinePlayer[$playerTP]->getPosition()->x;
            	$y = $allonlinePlayer[$playerTP]->getPosition()->y;
            	$z = $allonlinePlayer[$playerTP]->getPosition()->z;
            	$world = $allonlinePlayer[$playerTP]->getWorld();
            	$player->teleport(new Position($x, $y, $z, $world) );
            	#$this->plugin->getServer()->dispatchCommand($player, "tp " . $allonlinePlayer[$playerTP]->getName());
            	$player->sendMessage(TF::GOLD . "Teleportation vers " . TF::RED . TF::BOLD . $allonlinePlayer[$playerTP]->getName());
            
         
        }


        if($item->getCustomName() == TF::BOLD . TF::GREEN . "Quitter le StaffMod"){
        	$player->getInventory()->clearAll();
        	$key = array_search($player->getName(), $this->plugin->staffMod);
        	unset($this->plugin->staffMod[$key]);
        }
		if($item->getCustomName() == TF::BOLD . TF::GOLD . "Gamemode 0"){
			$player->setGamemode(GameMode::SURVIVAL());
			$player->sendMessage("§6Mode de jeu défini en survie");
		}
		if($item->getCustomName() == TF::BOLD . TF::GOLD . "Gamemode 1"){
			$this->plugin->getServer()->dispatchCommand($player, "gamemode 1");
		}
		if($item->getCustomName() == TF::BOLD . TF::GOLD . "Gamemode 3"){
			$player->setGamemode(GameMode::SPECTATOR());
			$player->sendMessage("§6Mode de jeu défini en spéctateur");
		}

    }
        

    public function onDamage(EntityDamageByEntityEvent $event){
    		$victim = $event->getEntity();
    		$attacker = $event->getDamager();
        	
    		if($victim instanceof Player and $attacker instanceof Player){
				if ($attacker->hasPermission("staffmod.perm")){
    			if($attacker->getInventory()->getItemInHand()->getCustomName() == TF::BOLD . TF::AQUA . "Freeze\nTapez le joueur !"){
    				if(!$victim->isImmobile()){
                        $event->cancel();
                        $pos = new Position($victim->getPosition()->getX(), $victim->getPosition()->getY() + 5, $victim->getPosition()->getZ(), $victim->getWorld());
    					$victim->setImmobile(true);
                        $victim->teleport($pos);
    					$victim->sendMessage(TF::BOLD . TF::RED . "Vous avez été immobilisé par un staff !");
    					$attacker->sendMessage(TF::AQUA . "Vous avez immobilisé " . TF::RED . TF::BOLD . $victim->getName());
    					array_push($this->plugin->freeze, $victim->getName());
    				}else{
                        $event->cancel(true);
    					$victim->setImmobile(false);
    					$victim->sendMessage(TF::BOLD . TF::GREEN . "Vous pouvez a nouveau vous déplacer !");
    					$attacker->sendMessage(TF::RED . TF::BOLD . $victim->getName() . TF::RESET . TF::AQUA . " peut a nouveau se déplacer !");
    					$key = array_search($victim->getName(), $this->plugin->freeze);
        				unset($this->plugin->freeze[$key]);

    				}
    			}

    			if($attacker->getInventory()->getItemInHand()->getCustomName() == TF::BOLD . TF::DARK_PURPLE . "Voir l'inventaire\nTapez le joueur !") {
    				$this->plugin->getServer()->dispatchCommand($attacker, "invsee " . $victim->getName());
                        $event->cancel(true);
    			}

    			if($attacker->getInventory()->getItemInHand()->getCustomName() == TF::BOLD . TF::BLACK . "Voir son EnderChest\nTapez le joueur !") {
    				$this->plugin->getServer()->dispatchCommand($attacker, "enderinvsee " . $victim->getName());
                        $event->cancel(true);
                	}
    			}
    		}
    	}
    }
