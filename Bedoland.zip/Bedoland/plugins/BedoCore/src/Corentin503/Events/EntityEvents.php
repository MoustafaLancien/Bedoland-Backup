<?php

namespace Corentin503\Events;

use CortexPE\DiscordWebhookAPI\Message;
use CortexPE\DiscordWebhookAPI\Webhook;
use DaPigGuy\PiggyFactions\claims\ClaimsListener;
use DaPigGuy\PiggyFactions\claims\ClaimsManager;
use DaPigGuy\PiggyFactions\factions\FactionsManager;
use DaPigGuy\PiggyFactions\players\PlayerManager;
use Corentin503\API\CooldownAPI;
use Corentin503\API\UtilsAPI;
use Corentin503\Entitys\Chicha;
use Corentin503\Main;
use pocketmine\entity\projectile\Egg;
use pocketmine\event\entity\EntityDamageByChildEntityEvent;
use pocketmine\player\GameMode;
use pocketmine\world\Position;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityShootBowEvent;
use pocketmine\event\Listener;
use pocketmine\item\Durable;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\world\particle\SmokeParticle;
use pocketmine\scheduler\ClosureTask;
use pocketmine\world\sound\BowShootSound;
use pocketmine\world\sound\FizzSound;
use pocketmine\Server;

class EntityEvents implements Listener
{
    public function onEntityBowShoot(EntityShootBowEvent $event)
    {
        $player = $event->getEntity();
        $world = $player->getLocation()->getWorld();

        if($event->getBow()->getEnchantmentLevel(VanillaEnchantments::PUNCH()) >= 1) {
            $event->cancel();
            if(!isset(CooldownAPI::$cooldown_bow[$player->getName()]) || CooldownAPI::$cooldown_bow[$player->getName()] - time() <= 0) {
                CooldownAPI::$cooldown_bow[$player->getName()] = time() + 10;
                $motions = clone $player->getMotion();

                $motions->x += $player->getDirectionVector()->getX() *  2.3;
                $motions->y += $player->getEyeHeight() * 0.35;
                $motions->z += $player->getDirectionVector()->getZ() * 2.3;
                $world->addSound($player->getPosition(), new BowShootSound(), [$player]);
                $player->setMotion($motions);

            } else {
                $time = CooldownAPI::$cooldown_bow[$player->getName()] - time();
                $player->sendPopup("Veuillez attendre §c{$time} §fseconde(s) !");
            }
        }
    }

    public function onAttack(EntityDamageEvent $event): void{
        if ($event->getCause() === EntityDamageEvent::CAUSE_FALL) $event->cancel();
    	if($event instanceof EntityDamageByEntityEvent){
        $damager = $event->getDamager();
        $victim = $event->getEntity();

        if ($damager instanceof Player) {
            if ($damager->getGamemode()->id() !== GameMode::CREATIVE()->id()) {
                $distance = $damager->getPosition()->distance($victim->getPosition()->asVector3());
                if ($distance > 3.5) {
                    $webhook = new Webhook("https://discord.com/api/webhooks/1101525606228824074/YWwyl3Ee9mF8TTRU2KQI90pJT67j7L_ViDuo5whYESLCrdoBgsNDkK5NFLFZ_NeHZgPw");
                    $msg = new Message();
                    $msg->setContent("{$damager->getName()} est détecté comme suspect avec {$distance} de 'reach', ⚠️Un joueur est suspect seulement si la reach qui dépasse 3.5 est réguliere⚠️");
                    $webhook->send($msg);
                }
            }
        }

        if ($damager instanceof Player) {
            $uiddDamager = PlayerManager::getInstance()->getPlayer($damager);  
            $faction = $uiddDamager->getFaction();
            if ($victim instanceof Chicha) {
                	if ($faction !== null) {
                	$event->cancel();
                if ($damager->isSneaking()) {
                    if (ClaimsManager::getInstance()->getClaimByPosition($victim->getPosition()->asPosition())->getFaction()->getName() === PlayerManager::getInstance()->getPlayerByName($damager->getName())->getFaction()->getName()) {
                       $damager->sendMessage("§aVous avez récupéré la chicha");
                       $damager->getInventory()->addItem(ItemFactory::getInstance()->get(280, 0, 1)->setLore(["chicha"]));  
                       $victim->flagForDespawn(); 
                    } else  $damager->sendMessage("§cCe n'est pas votre chicha");      
                } else {
                
            	if (ClaimsManager::getInstance()->getClaimByPosition($victim->getPosition()->asPosition())->getFaction()->getName() === PlayerManager::getInstance()->getPlayerByName($damager->getName())->getFaction()->getName()) {
                    $faction = $uiddDamager->getFaction()->getName();
                    if(!isset(CooldownAPI::$cooldown_chicha[$faction]) || CooldownAPI::$cooldown_chicha[$faction] - time() <= 0) {
                        CooldownAPI::$cooldown_chicha[$faction] = time() + 60 * 60;
						$damager->sendTitle("§7Vous fumez la chicha !");
                        $damager->sendSubTitle("§cVous ne pouvez plus bouger ");
                        $damager->setImmobile(true);
                        UtilsAPI::$players_chicha_itemcancel[$faction] = time() + 5;
                        $world = $victim->getWorld();
       				    $world->addParticle($victim->getLocation(), new SmokeParticle());   
                        
                        Main::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(
                            function() use ($damager){
                                UtilsAPI::$players_chicha_itemcancel[$damager->getName()] = 0;
                                $damager->setHealth($damager->getHealth() + 19);
                                $damager->getInventory()->addItem(ItemFactory::getInstance()->get(351, 0, 64));
                                $damager->setImmobile(false);
                                $damager->sendTitle("§7Vous avez fini de fumer !");
                                $damager->sendSubTitle("§aVous pouvez désormais bouger ");
                                $damager->sendMessage("§6> Tous vos items ont été réparé !");
                                $damager->sendMessage("§6> Vous avez été heal !");                                  
                                $damager->sendMessage("§6> Vous avez été refill en soup !");   

                                foreach ($damager->getInventory()->getContents() as $slots => $items) {
                                    if ($items instanceof Durable) {
                                        $items->setDamage(0);
                                    }
                                }
                            }
                        ), 20 * 5);
                    } else {
                        $time = CooldownAPI::$cooldown_chicha[$faction] - time();
                        $minutes = $time/60;
                        $arrondi= round($minutes);
                        $damager->sendPopup("Veuillez attendre §c{$arrondi} §fminutes(s) !");
                        for ($i=0; $i<10; $i++) {
                        $world = $victim->getWorld();
       				    $world->addParticle($victim->getLocation(), new SmokeParticle());    
						} 
                    }
                } else $damager->sendMessage("§cVous n'avez pas accès à cette chicha !");
            }
        } else $damager->sendMessage("§6> Vous n'avez pas de faction !");   
      }
    }        
        
        if ($damager instanceof Player and $victim instanceof Player) {
            $item = $damager->getInventory()->getItemInHand();

            if ($item->getId() === 263 and $item->getMeta() === 1) {
                if (!isset(CooldownAPI::$cooldown_citrouille[$damager->getName()]) || CooldownAPI::$cooldown_citrouille[$damager->getName()] - time() <= 0) {
                    CooldownAPI::$cooldown_citrouille[$damager->getName()] = time() + 180;
                    $helmet = $victim->getArmorInventory()->getHelmet();
					Server::getInstance()->getLogger()->info("" . $damager->getName() . " a citrouille " . $victim->getName() . "");
                    $victim->getArmorInventory()->setHelmet(ItemFactory::getInstance()->get(ItemIds::CARVED_PUMPKIN));
                    Main::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(fn() =>  $victim->getArmorInventory()->setHelmet($helmet)), 8*20);
                } else {
                    $time = CooldownAPI::$cooldown_citrouille[$damager->getName()] - time();
                    $damager->sendPopup("§cVous devez encore attendre {$time} secondes !");
                }
            }
            
            if ($item->getId() === 409) { #inventory shuffle
                $player = $event->getEntity();
                $world = $player->getLocation()->getWorld();
                if (!isset(CooldownAPI::$cooldown_shuffle[$damager->getName()]) || CooldownAPI::$cooldown_shuffle[$damager->getName()] - time() <= 0) {
                          CooldownAPI::$cooldown_shuffle[$damager->getName()] = time() + 45;
                          $inv = $player->getInventory()->getContents();
                          shuffle($inv);
                          $player->getInventory()->setContents($inv);
                          $damager->sendPopup("§l§9»§r§f L'inventaire de §9" . $player->getName() . " §fa été mélanger !");
                          $player->sendPopup("§l§6»§r§f Votre inventaire a été mélanger par §6" . $damager->getName() . " ");
                    Server::getInstance()->getLogger()->info("" . $damager->getName() . " a inventory shuffle " . $victim->getName() . "");
                          $damager->getInventory()->removeItem(ItemFactory::getInstance()->get(409, 0, 1));
                          $world->addSound($player->getPosition(),new FizzSound(),[$player]); 
                          $world->addSound($damager->getPosition(),new FizzSound(),[$damager]); 
                        } else {
                    		$time = CooldownAPI::$cooldown_shuffle[$damager->getName()] - time();
                            $damager->sendPopup("§l§9»§r§f Vous devez attendre §9{$time} secondes§f");
                        }
                return;
            }

            if ($item->getId() === 318) {
                if (!isset(CooldownAPI::$cooldown_sticktp[$damager->getName()]) || CooldownAPI::$cooldown_sticktp[$damager->getName()] - time() <= 0) {
                    CooldownAPI::$cooldown_sticktp[$damager->getName()] = time() + 60;
                    $damager_pos = $damager->getPosition()->asVector3();
                    $victim_pos = $victim->getPosition()->asVector3();
                    Server::getInstance()->getLogger()->info("" . $damager->getName() . " a bâton de tp " . $victim->getName() . "");
                    $damager->teleport($victim_pos);
                    $victim->teleport($damager_pos);
                } else {
                    $time = CooldownAPI::$cooldown_sticktp[$damager->getName()] - time();
                    $damager->sendPopup("§l§9»§r§f Vous devez attendre §9{$time} secondes§f");
                }
            }
            
                if ($item->getId() === 415) { #loupe
                    $count = 0;
                if (!isset(CooldownAPI::$cooldown_loupe[$damager->getName()]) || CooldownAPI::$cooldown_loupe[$damager->getName()] - time() <= 0) {
                          CooldownAPI::$cooldown_loupe[$damager->getName()] = time() + 30;
                    	  $damager->sendMessage("§6-------------------------------------");
                    	  foreach ($victim->getInventory()->getContents() as $slot => $items) {
                              		if ($items->getId() === VanillaItems::INK_SAC()->getId()) {
                              		$count = $count + $items->getCount();
                                    $damager->sendMessage("§a" .$victim->getName(). " §fa§a " .$count." §fsoupes");
                                    } 
                              
                          }
                    		$armor1 = $victim->getArmorInventory();
                    		if ($armor1->getHelmet()->getId() !== 0) {
                				$helmet = $armor1->getHelmet();
               					if ($helmet instanceof Durable) {
                    			$duraHelmet = $helmet->getMaxDurability() - $helmet->getDamage();
                                $damager->sendMessage("§aSon casque§f est §fà §c$duraHelmet §f\ §c". $helmet->getMaxDurability(). " §fde durabilité §a!");    
                                }
                            }
                    		$armor2 = $victim->getArmorInventory();
                    		if ($armor2->getChestplate()->getId() !== 0) {
                				$chestplate = $armor2->getChestplate();
               					if ($chestplate instanceof Durable) {
                    			$duraChestplate = $chestplate->getMaxDurability() - $chestplate->getDamage();
                                $damager->sendMessage("§aSon plastron§f est §fà §c$duraChestplate §f\ §c". $chestplate->getMaxDurability(). " §fde durabilité §a!");
                                }
                            }
                    		$armor3 = $victim->getArmorInventory();
                    		if ($armor3->getLeggings()->getId() !== 0) {
                				$leggings = $armor3->getLeggings();
               					if ($leggings instanceof Durable) {
                    			$duraLeggings = $leggings->getMaxDurability() - $leggings->getDamage();
                                $damager->sendMessage("§aSes jambières§f sont §fà §c$duraLeggings §f\ §c". $leggings->getMaxDurability(). " §fde durabilité §a!");    
                                }
                            }
                    		$armor4 = $victim->getArmorInventory();
                    		if ($armor4->getBoots()->getId() !== 0) {
                				$boots = $armor4->getBoots();
               					if ($boots instanceof Durable) {
                    			$duraBoots = $boots->getMaxDurability() - $boots->getDamage();
                                    $damager->sendMessage("§aSes bottes §fsont à §fa §c$duraBoots §f\ §c". $boots->getMaxDurability(). " §fde durabilité §a!");
                                }
                            }
                    	$damager->sendMessage("§6-------------------------------------");
                        } else {
                    		$time = CooldownAPI::$cooldown_loupe[$damager->getName()] - time();
                            $damager->sendPopup("§l§9»§r§f Vous devez attendre §9{$time} secondes§f");
                        }
                    }    

            if (!isset(CooldownAPI::$combat[$damager->getName()]) || CooldownAPI::$combat[$damager->getName()] - time() <= 0) {
                CooldownAPI::$combat[$damager->getName()] = time() + 15;
                CooldownAPI::$combat[$victim->getName()] = time() + 15;
            } else {
                CooldownAPI::$combat[$damager->getName()] = time() + 15;
                CooldownAPI::$combat[$victim->getName()] = time() + 15;
            }
        }
    }
 }       
    
        public function EntityDamage(EntityDamageByChildEntityEvent $event){ #switchball
        $toucher = $event->getEntity();
        $player = $event->getChild()->getOwningEntity();
        if ($toucher instanceof Player and $player instanceof Player){
            if ($event->getChild() instanceof Egg){
                $x = $toucher->getPosition()->getX();
                $y = $toucher->getPosition()->getY();
                $z = $toucher->getPosition()->getZ();
                $x2 = $player->getPosition()->getX();
                $y2 = $player->getPosition()->getY();
                $z2 = $player->getPosition()->getZ();
                $player->teleport(new Position($x, $y, $z, $toucher->getWorld()));
                $toucher->teleport(new Position($x2, $y2, $z2, $player->getWorld()));
            }
        }
    }  
             
   

}