<?php

namespace Corentin503\Tasks;

use Corentin503\Main;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\world\World;

class DayTask extends Task{
    
    public function onRun() : void{
        foreach(Server::getInstance()->getWorldManager()->getWorlds() as $worlds) {
            $worlds->setTime(World::TIME_DAY);
            $worlds->stopTime();
        }
    }
}