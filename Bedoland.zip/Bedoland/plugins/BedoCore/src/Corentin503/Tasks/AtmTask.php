<?php

namespace Corentin503\Tasks;

use Corentin503\API\AtmAPI;
use pocketmine\scheduler\Task;
use pocketmine\player\Player;

class AtmTask extends Task
{
    private Player $player;

    private int $money;

    public function __construct(Player $player, int $money)
    {
        $this->player = $player;
        $this->money = $money;
    }

    public function onRun(): void
    {
        $player = $this->player;
        if ($player->isOnline()) {
            AtmAPI::getDataFile()->set($player->getName(), AtmAPI::getDataFile()->get($player->getName()) + $this->money);
            AtmAPI::getDataFile()->save();
        } else $this->getHandler()->cancel();
    }
}