<?php

namespace Corentin503\Tasks;

use Corentin503\Main;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class BroadcastTask extends Task{
    
    public function onRun() : void{
        Server::getInstance()->broadcastMessage("§fN'hésitez pas à rejoignez le discord -> §ahttps://discord.gg/5yUk67J3s8 !");
        }
    }
