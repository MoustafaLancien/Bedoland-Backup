<?php

namespace Corentin503\Tasks;

use TheNote\PMTrident\entity\projectile\ThrownTrident;
use Corentin503\API\CooldownAPI;
use pocketmine\entity\object\ItemEntity;
use rinegone\entities\type\Zombie;
use rinegone\entities\type\Spider;
use rinegone\entities\type\Skeleton;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use Corentin503\Entitys\Chicha;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;

class ClearLagTask extends Task
{
    public function onRun(): void
    {
        CooldownAPI::$time_clearlagg--;
        if (CooldownAPI::$time_clearlagg <= 0) {
            $count = 0;
            foreach (Server::getInstance()->getWorldManager()->getWorlds() as $worlds) {
                foreach ($worlds->getEntities() as $entities) {
                    if ($entities instanceof ItemEntity or $entities instanceof Zombie or $entities instanceof Skeleton or $entities instanceof Spider or $entities instanceof ThrownTrident) { 
                        $count++;
                        $entities->flagForDespawn();
                    }
                }
            }
            CooldownAPI::$time_clearlagg = 180;
            Server::getInstance()->broadcastMessage("[§a!!!§f] §aUn total de {$count} entités ont été supprimées !");
            Server::getInstance()->broadcastTip("[§a!!!§f] §aUn total de {$count} entités ont été supprimées !");
            foreach (Server::getInstance()->getOnlinePlayers() as $player) {
             $pos = $player->getPosition();
               $player->getNetworkSession()->sendDataPacket(PlaySoundPacket::create("random.orb",$pos->x, $pos->y, $pos->z,1.0, 1.0));
            }
        } else {
            if ((CooldownAPI::$time_clearlagg == 60) or (CooldownAPI::$time_clearlagg == 30) or (CooldownAPI::$time_clearlagg == 3) or (CooldownAPI::$time_clearlagg == 2) or (CooldownAPI::$time_clearlagg == 1)) {
                $time = CooldownAPI::$time_clearlagg;
                Server::getInstance()->broadcastTip("§f[§a!!!§f] §aClearLag dans {$time} secondes !");
                foreach (Server::getInstance()->getOnlinePlayers() as $player) {
                    $pos = $player->getPosition();
                    $player->getNetworkSession()->sendDataPacket(PlaySoundPacket::create("note.bass",$pos->x, $pos->y, $pos->z,1.0, 1.0));
                }
            }

        }
    }
}