<?php

namespace Corentin503\Tasks;

use onebone\economyapi\EconomyAPI;
use pocketmine\item\ItemFactory;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class PurificationTask extends Task {

    public static array $players = [];

    public function onRun(): void
    {
        if (empty(Server::getInstance()->getOnlinePlayers())) return;

        $minX = 99;
        $maxX = 103;
        $minY = 147;
        $maxY = 152;
        $minZ = -150;
        $maxZ = -154;

        foreach (Server::getInstance()->getOnlinePlayers() as $player){
            if ($player instanceof Player) {
                if (isset(self::$players[$player->getName()])) {
                    $pos = $player->getPosition();
                    if (($player->getPosition()->x >= min(99, 103)) and ($player->getPosition()->x <= max(99, 103)) and
                            ($player->getPosition()->y >= min(147, 152)) and ($player->getPosition()->y <= max(147, 152)) and
                            ($player->getPosition()->z >= min(-150, -154)) and ($player->getPosition()->z <= max(-150, -154))) {
                    } else {
                        unset(self::$players[$player->getName()]);
                        $player->sendMessage("§cVous avez quitté la zone de purification.");
                    }
                }
            }
        }
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            if ($player instanceof Player) {
                $pos = $player->getLocation();
                if (($player->getPosition()->x >= min(99, 103)) and ($player->getPosition()->x <= max(99, 103)) and
                            ($player->getPosition()->y >= min(147, 152)) and ($player->getPosition()->y <= max(147, 152)) and
                            ($player->getPosition()->z >= min(-150, -154)) and ($player->getPosition()->z <= max(-150, -154))) {
                    if ($player->isAlive()) {
                        if (isset(self::$players[$player->getName()])) {
                            $item = $player->getInventory()->getItemInHand();
                            if ($item->getId() === 351 and $item->getMeta() === 11) {
                                self::$players[$player->getName()]++;
                                if (self::$players[$player->getName()] === 15 ) {
                                    $player->getInventory()->removeItem(ItemFactory::getInstance()->get(351, 11, 1));
                                    EconomyAPI::getInstance()->addMoney($player, 3);
                                    self::$players[$player->getName()] = 0;
                                    $player->sendMessage("§aVous avez purifié votre §5Ecstasy.");
                                } else {
                                    $player->sendPopup(str_replace(["{actus}", "{max}"], [self::$players[$player->getName()], 15], "§e- §fPurification §7[{actus}/{max}] §e-"));
                                }
                            } else {
                                self::$players[$player->getName()] = 0;
                            }
                        } else {
                            $player->sendMessage("§aVous êtes entré dans la zone de purification.");
                            self::$players[$player->getName()] = 0;
                        }
                    } else {
                        if (isset(self::$players[$player->getName()])){
                            unset(self::$players[$player->getName()]);
                        }
                    }
                }
            }
        }
    }

}