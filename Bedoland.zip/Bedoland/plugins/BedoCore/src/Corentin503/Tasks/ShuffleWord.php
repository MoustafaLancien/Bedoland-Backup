<?php

namespace Corentin503\Tasks;

use Corentin503\Main;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class ShuffleWord extends Task  {

    public function onRun(): void {
        $words = Main::getInstance()->getConfig()->get("words");
        $word = $words[array_rand($words)];
        Main::$word = $word;
        $broadcast = Main::getInstance()->getConfig()->get("broadcast");
        $broadcast = str_replace(["{word}"], [$word], $broadcast);
        Server::getInstance()->broadcastMessage($broadcast);
    }
}