<?php 

namespace davidglitch04\libEco\Utils;

final class Utils {

    public function __construct()
    {
        //NOTHING
    }

	public const ECONOMYAPI = "EconomyAPI";
	
	public const BEDROCKECONOMYAPI = "BedrockEconomyAPI";
}