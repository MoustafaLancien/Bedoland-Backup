<?php

declare(strict_types=1);

namespace AndreasHGK\EasyKits\utils;

use pocketmine\plugin\PluginException;

class KitException extends PluginException {

}
