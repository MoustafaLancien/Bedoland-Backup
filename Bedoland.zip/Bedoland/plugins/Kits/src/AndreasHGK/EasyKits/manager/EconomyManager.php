<?php

declare(strict_types=1);

namespace AndreasHGK\EasyKits\manager;

use pocketmine\Server;

use onebone\economyapi\EconomyAPI;
use cooldogedev\BedrockEconomy\BedrockEconomy;

use AndreasHGK\EasyKits\EasyKits;

class EconomyManager{

    public static $instance;

    /**
     * @var null|EconomyAPI|BedrockEconomy
     */
    public static $economy = null;

    public static function loadEconomy() : void {
        $plugins = Server::getInstance()->getPluginManager();
        $economyAPI = $plugins->getPlugin("EconomyAPI");
        if($economyAPI instanceof EconomyAPI) {
            self::$economy = $economyAPI;
            EasyKits::get()->getLogger()->info("loaded EconomyAPI");
            return;
        }

        $bedrockEconomy = $plugins->getPlugin("BedrockEconomy");
        if($bedrockEconomy instanceof BedrockEconomy) {
            self::$economy = $bedrockEconomy;
            EasyKits::get()->getLogger()->info("loaded BedrockEconomy");
            return;
        }
    }

    public static function isEconomyLoaded() : bool {
        return self::getEconomy() !== null;
    }

    public static function getEconomy() {
        return self::$economy;
    }

    private function __construct() {
    }

}