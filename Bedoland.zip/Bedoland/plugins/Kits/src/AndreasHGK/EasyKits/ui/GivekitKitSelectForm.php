<?php

declare(strict_types=1);

namespace AndreasHGK\EasyKits\ui;

use AndreasHGK\EasyKits\EasyKits;
use AndreasHGK\EasyKits\manager\KitManager;
use AndreasHGK\EasyKits\utils\KitException;
use AndreasHGK\EasyKits\utils\LangUtils;
use AndreasHGK\EasyKits\utils\TryClaim;
use Vecnavium\FormsUI\SimpleForm;
use pocketmine\player\Player;

class GivekitKitSelectForm {

    public static function sendTo(Player $player, Player $target) : void {

        $ui = new SimpleForm(function (Player $player, $data) use ($target) {
            if($data === null) {
                $player->sendMessage(LangUtils::getMessage("givekit-cancelled"));
                return;
            }
            if(!KitManager::exists($data)) {
                $player->sendMessage(LangUtils::getMessage("givekit-kit-not-found"));
                return;
            }
            try {
                $kit = KitManager::get($data);
                TryClaim::ForceClaim($target, $kit);
                $player->sendMessage(LangUtils::getMessage("givekit-success", true, ["{KIT}" => $kit->getName(), "{PLAYER}" => $target->getName()]));
            } catch(KitException $e) {
                switch($e->getCode()) {
                    case 3:
                        $player->sendMessage(LangUtils::getMessage("givekit-insufficient-space"));
                        break;
                    default:
                        $player->sendMessage(LangUtils::getMessage("unknown-exception"));
                        break;
                }
            }
        });

        $ui->setTitle(LangUtils::getMessage("givekit-title"));
        $ui->setContent(LangUtils::getMessage("givekit-kitselect-text"));

        $give = EasyKits::get()->config->getNested("Form.image.givekit-kitselect-url");
        $giveURL = str_starts_with($give, "http://") || str_starts_with($give, "https://");

        foreach(KitManager::getAll() as $kit) {
            $ui->addButton(LangUtils::getMessage("givekit-kitselect-format", true, ["{NAME}" => $kit->getName()]), $giveURL ? 1:0, $give, $kit->getName());
        }


        $player->sendForm($ui);
    }

}
